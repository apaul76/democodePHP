<?php
session_start();
defined('BASEPATH') OR exit('No direct script access allowed');
require('send_mai.php');
error_reporting(0);
class Rechargehub extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct()
	{
		parent::__construct();
		$this->load->helper('url'); 
         $this->load->database();
         $this->load->model('Recharge_Model'); 

  }

	


	public function index()
	{
	$data['recordmenu']=$this->Recharge_Model->groupmenu();	
	$data['recordmenulest']=$this->Recharge_Model->recordmenulest();	
	$data['records']=$this->Recharge_Model->probannerdetails();
	$data['recordopt']=$this->Recharge_Model->operatordetailsprepaid();
	$data['recordoptr']=$this->Recharge_Model->operatordetailspostpaid();

	$this->load->view('index',$data);
		
	}



	public function login()
	{
		$this->load->view('login');
	}

	public function adminlogin()

	{
		$this->load->view('adminlogin');
	}


	public function siginmenu()
	{
		$email=$_SESSION['userid'];
		$query=$this->db->get_where("apiuser",array("email"=>$email));
		$data['records']=$query->result();
		$this->load->view('siginmenu',$data);
	}



	public function logout()
	{
		$loginhistorydata=array('accountid'=>$_SESSION['accountid']);
		$this->Recharge_Model->logoutmodel($loginhistorydata);
		$this->load->view('logout');
	}



	public function loginvalidate()

		{
			$email=$this->input->post('email');
			
			if(is_numeric($email))
			{

					$data = array('email'=>$this->input->post('email'),'pass'=>$this->input->post('pass'),'proxy'=>$this->input->post('proxy'));

					$query=$this->db->get_where("apiuser",array("phone"=>$data['email'],"pass"=>$data['pass']));
					$ret=$query->row();

					

 					if($query->num_rows()>0)
		     			{
		     				$openingdate=date('d/m/Y');
							$date_now = date("Y-m-d");
 							$date2    = date("Y-m-d",strtotime($ret->rdate));
					     	$_SESSION['userid']=$data['email'];
					     	$_SESSION['username']=$ret->fname;
					     	$_SESSION['accountid']=$ret->accountid;
					     	$_SESSION['usertype']=$ret->usertype;
					     	$_SESSION['rcdate']=$date2;
					     	$_SESSION['passst']=$ret->passst;
					     	$_SESSION['profilestatusx']=$ret->profilestatus;
					     	$_SESSION['validatemobile']=$ret->validatemobile;
					     	$_SESSION['phone']=$ret->phone;
					     	$_SESSION['profilestatus']=$ret->profilestatus;
					     	$_SESSION['status']=$ret->status;
					     	$_SESSION['logintime']=date('h:i:sa');

					     	if($_SESSION['status']==3)
					     	{
					     		echo "3";
					     	}

					     	else
					     	{

					     		$lastbalance=$this->db->get_where("apiwallet",array("accountid"=>$_SESSION['accountid']));
					     	//$lastblc=$lastbalance->row();

					     	//echo $lastbalance->balance;

						     	if($lastbalance->num_rows()==0)
							     	{
							     		$_SESSION['lastblc']=0;

							     		if($_SESSION['usertype']==1)
								     		{
								     			echo "API-User-true-phone";
								     		}

								     	elseif ($_SESSION['usertype']==2)
								     		 {
								     				
								     		 	echo "Distributor-true-phone";

								     			}


								     			elseif ($_SESSION['usertype']==3)
								     		 {
								     				
								     		 	echo "Admin-true-phone";

								     			}


							     			
							     	}

						     	else
								     	{
								     		$lastblc=$lastbalance->row();
								     		$_SESSION['lastblc']=$lastblc->balance;

								     		if($_SESSION['usertype']==1)
								     		{
								     			echo "API-User-true-phone";
								     		}

								     		elseif ($_SESSION['usertype']==2)
								     		 {
								     				
								     		 	echo "Distributor-true-phone";

								     			}


								     			elseif ($_SESSION['usertype']==3)
								     		 {
								     				
								     		 	echo "Admin-true-phone";

								     			}

										
								     	}

		     	
		     			}


		     			//$myip=$_SESSION['REMOTE_ADDR'];
		     			$myip='157.41.76.183';
		     				/*Get user ip address details with geoplugin.net*/
						$geopluginURL='http://www.geoplugin.net/php.gp?ip='.$myip;
						$addrDetailsArr = unserialize(file_get_contents($geopluginURL));
						/*Get City name by return array*/
						$city = $addrDetailsArr['geoplugin_city'];
						/*Get Country name by return array*/
						$country = $addrDetailsArr['geoplugin_countryName'];
						$state = $addrDetailsArr['geoplugin_region'];


		     			$datalogin_history=array('accountid' =>$_SESSION['accountid'], 'ipaddress'=>$myip,'logintime'=>date('h:i:s'),'logindate'=>date('d-M-Y'),'city'=>$city,'country'=>$country,'state'=>$state);

		     			$this->Recharge_Model->loginhistory($datalogin_history);
		     			
		     			

					     	}


					     	else
		     			{
		     				echo "Fail";
		     			}
					     	


 					
				
			}

			else
			{
				//echo "false";

				$data = array('email'=>$this->input->post('email'),'pass'=>$this->input->post('pass'),'proxy'=>$this->input->post('proxy'));

					$query=$this->db->get_where("apiuser",array("email"=>$data['email'],"pass"=>$data['pass']));
					$ret=$query->row();

					$openingdate=date('d/m/Y');

					if($query->num_rows()>0)
		     			{
					     	$_SESSION['userid']=$data['email'];
					     	$_SESSION['username']=$ret->fname;
					     	$_SESSION['accountid']=$ret->accountid;
					     	$_SESSION['usertype']=$ret->usertype;
					     	$_SESSION['passst']=$ret->passst;
					     	$_SESSION['phone']=$ret->phone;
					     	$_SESSION['profilestatus']=$ret->profilestatus;
					     	$_SESSION['status']=$ret->status;

					     	if($_SESSION['status']==3)
					     	{
					     		echo "3";
					     	}

					     	else
					     	{

					     		$lastbalance=$this->db->get_where("apiwallet",array("accountid"=>$_SESSION['accountid']));
					     	//$lastblc=$lastbalance->row();

					     	//echo $lastbalance->balance;

						     	if($lastbalance->num_rows()==0)
							     	{
							     		$_SESSION['lastblc']=0;

							     		if($_SESSION['usertype']==1)
								     		{
								     			echo "API-User-true-email";
								     		}

								     	elseif ($_SESSION['usertype']==2)
								     		 {
								     				
								     		 	echo "Distributor-true-email";

								     			}


								     			elseif ($_SESSION['usertype']==3)
								     		 {
								     				
								     		 	echo "Admin-true-email";

								     			}
							     	}

						     	else
								     	{
								     		$lastblc=$lastbalance->row();
								     		$_SESSION['lastblc']=$lastblc->balance;

								     		if($_SESSION['usertype']==1)
								     		{
								     			echo "API-User-true-email";
								     		}

								     	elseif ($_SESSION['usertype']==2)
								     		 {
								     				
								     		 	echo "Distributor-true-email";

								     			}


								     			elseif ($_SESSION['usertype']==3)
								     		 {
								     				
								     		 	echo "Admin-true-email";

								     			}
										
								     	}

					     	}

					     	

		     	
		     			}

		     				else
		     				{
		     					echo "Fail";
		     				}



			}
			
			
			
		}

		public function loginvalidateadmin()

		{
			//$this->load->model('Recharge_Model');
			$data = array('email'=>$this->input->post('email'),'pass'=>$this->input->post('pass'));
			$query=$this->db->get_where("masteradmin",array("email"=>$data['email'],"pass"=>$data['pass']));
				$query->result();
				if($query->num_rows()>0)

				{
					$_SESSION['userid']=$data['email'];
					//$_SESSION['username']=$ret->name;

					echo "success";
				}

				else
				{
					echo "fail";
				}
			
			
		}



		public function otpgenerate()

			{
				$this->load->model('Recharge_Model');
				$data = array('email' =>$this->input->post('email'));

				$query=$this->db->get_where("kyctable",array("phone"=>$data['email']));
				$query->result();
				if($query->num_rows()>0)

				{
					echo "duplicate";
				}

				else

				{	

				$x1=rand(1000,9999);
			 	$x2=rand(1000,$x1);
			 	$x3=rand($x2,9999);
			 	$otp=rand($x2,$x3);
			 	$timex=time();
			 	$status=0;
			 	$_SESSION['mobile_no']=$data['email'];


			 	$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$status);

				
			 	$this->Recharge_Model->otpinsert($otpdata);
			 	
			 	//send_email('avijitpaul03021992@gmail.com',"please verify your mobile with the given OTP ".$otp." thank you","OTP Verification",'avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com');

			 	if(true)

			 	{
			 		echo "success";

			 	}

			 	else
			 	{
			 		echo "fail";
			 	}

			 	//echo $otp;

			 }

			}



		public function otpvalid()

			{
				$timex_otp='';
				$this->load->model('Recharge_Model');
				$data=array('otp'=>$this->input->post('otp'),'timex'=>$this->input->post('timex'));
				$query=$this->db->get_where("otptable",array("otp"=>$data['otp'] ));
				
				if($query->num_rows()>0)
				{

				foreach ($query->result() as $row)

				 {
					$timex_otp=$row->timex;

				}


				$otp_id= $data['otp'];

				if($data['timex']<=($timex_otp+60))

				{
					$status=1;
					$this->Recharge_Model->otpupdate($otp_id);

					if (true)
					 {
					 	echo "success";
						//echo  $_SESSION['mobile_no'];
					}

					


				}


				if($data['timex']>($timex_otp+60))

				{
					echo "expired";
				}

				

			}

			else
			{
				echo 'invalid';
			}





			}


public  function kycform()

	{
		$this->load->helper('url');
		$this->load->view('kycform');
	}


	public function kycforminput()

		{
			
			$target_dir = "./upload/";
			$id=$_POST['phone'];
			$status=0;
			$pan_basename=basename($id."_pan_".$_FILES["cpan"]["name"]);
			$adhar_basename=basename($id."_adhar_".$_FILES["cadh"]["name"]);
			$photo_basename=basename($id."_photo_".$_FILES["cphoto"]["name"]);

			$target_file_pan = $target_dir . $pan_basename;
			$target_file_adhar = $target_dir . $adhar_basename;
			$target_file_photo = $target_dir . $photo_basename;
			
			move_uploaded_file($_FILES["cpan"]["tmp_name"], $target_file_pan);
			move_uploaded_file($_FILES["cadh"]["tmp_name"], $target_file_adhar);
			move_uploaded_file($_FILES["cphoto"]["tmp_name"], $target_file_photo);

			if(function_exists('date_default_timezone_set')) 
				{
    					date_default_timezone_set("Asia/Kolkata");
				}

				$date_app=date("d-m-Y");
				$time_app=date("H:i a");

				$applied=$date_app." &nbsp;".$time_app;

			$fname=$_POST['firstname'];
			$lname=$_POST['lastname'];
			$dob=$_POST['dob'];
			$address=$_POST['address'];
			$city=$_POST['city'];
			$state=$_POST['state'];
			$zipcode=$_POST['zipcode'];
			$bname=$_POST['bname'];
			$emailid=$_POST['emailid'];
			$adharnum=$_POST['adharnum'];
			$pannum=$_POST['pannum'];

			

			$data=array('fname'=>$fname,
				'lname'=>$lname,
				'birth'=>$dob,
				'sname'=>$bname,
				'address'=>$address,
				'state'=>$state,
				'pincode'=>$zipcode,
				'emailid'=>$emailid,
				'adhar'=>$adharnum,
				'pan'=>$pannum,
				'cadhar'=>$adhar_basename,
				'cpan'=>$pan_basename,
				'photo'=>$photo_basename,
				'status'=>$status,
				'phone'=>$id,
				'appdt'=>$applied


		);



			
					$this->Recharge_Model->kycinsert($data);


					if(true)
					{
						echo "success";
					}

					else
					{
						echo "failed";
					}
			

		}


	public function kyc_info()
		{
			$query=$this->db->get("kyctable");
			$data['records']=$query->result();
			$this->load->view('kycmok',$data);
		}


		public function updateinfo()

		{
			$target_dir = "./upload/";
			$id=$_POST['phone'];
			$status=0;
			$pan_basename=basename($id."_pan_updated_".$_FILES["cpan"]["name"]);
			$adhar_basename=basename($id."_adhar_updated_".$_FILES["cadhar"]["name"]);
			$photo_basename=basename($id."_photo_updated_".$_FILES["photo"]["name"]);

			$target_file_pan = $target_dir . $pan_basename;
			$target_file_adhar = $target_dir . $adhar_basename;
			$target_file_photo = $target_dir . $photo_basename;
			
			move_uploaded_file($_FILES["cpan"]["tmp_name"], $target_file_pan);
			move_uploaded_file($_FILES["cadhar"]["tmp_name"], $target_file_adhar);
			move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file_photo);

			$data=array('cpan'=>$pan_basename,'cadhar'=>$adhar_basename,'photo'=>$photo_basename,'phone'=>$id);

			$this->Recharge_Model->updatedoc($data);

			echo "<p><div class='alert alert-solid alert-success'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully. Please click Syn Table button for current update.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div></p>";

		}



			public function psaapply()
		{
			$id=$_POST['phone'];

			$query=$this->db->get_where("psatable",array("phone"=>$id));
				
				if($query->num_rows()>0)
				{

					
				echo "<p><div class='alert alert-solid alert-danger'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Already Applied for PSA. 
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div></p>";

				}

				else
				{

			if(function_exists('date_default_timezone_set')) 
				{
    					date_default_timezone_set("Asia/Kolkata");
				}

				$date_app=date("d-m-Y");
				$time_app=date("H:i a");

				$applied=$date_app." &nbsp;".$time_app;


			$couponamt=$_POST['couponselect'];
			$status=0;

			$data=array('phone'=>$id,'agentid'=>'N/A','timex'=>$applied,'couponamt'=>$couponamt,'status'=>$status);
			$this->Recharge_Model->psainsert($data);

			
			if(true)
			{
				echo "<p><div class='alert alert-solid alert-success'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;PSA has been added successfully. 
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div></p>";

			}

		}

	}







	public function psa_agent()
		{
			$this->db->select('*')
         			 ->from('psatable')
         			 ->order_by("id", "DESC")
         			 ->where("status",0);
              
			$query = $this->db->get();
			$data['records']=$query->result();
			$this->load->view('psa_agent',$data);
		}

	public function coupon_history()
		{
			$this->load->view('coupon_history');
		}


		public function adminindex()

	{
		$this->load->view('adminindex');
	}


	public function kycmanager()
	{
		$this->db->select('*')
         		 ->from('kyctable');
		$query = $this->db->get();
		$data['records']=$query->result();
		$this->load->view('kycmanager',$data);
	}

	public function kycedit()
	{
		$phone=$this->input->post('phone');
		$_SESSION['phone']=$phone;
		
		$query=$this->db->get_where("kyctable",array("phone"=>$phone));
		$data['records']=$query->result();
		$this->load->view('kycedit',$data);
	}



	public function kycupdate()

		{
			$fname=$_POST['firstname'];
			$lname=$_POST['lastname'];
			$dob=$_POST['dob'];
			$address=$_POST['address'];
			$city=$_POST['city'];
			$state=$_POST['state'];
			$zipcode=$_POST['zipcode'];
			$bname=$_POST['bname'];
			$emailid=$_POST['emailid'];
			$adharnum=$_POST['adharnum'];
			$pannum=$_POST['pannum'];
			$phone=$_POST['phone'];
			$status=$_POST['status'];
			$remarks=$_POST['remarks'];
			$appdt=$_POST['appdt'];

			$data=array('fname'=>$fname,
				'lname'=>$lname,
				'birth'=>$dob,
				'sname'=>$bname,
				'address'=>$address,
				'state'=>$state,
				'pincode'=>$zipcode,
				'emailid'=>$emailid,
				'adhar'=>$adharnum,
				'pan'=>$pannum,
				'status'=>$status,
				'phone'=>$phone,
				'appdt'=>$appdt,
				'remarks'=>$remarks


		);



			
					$this->Recharge_Model->kycupdate($data);


					if(true)
					{
						echo "success";
					}

					else
					{
						echo "failed";
					}
		}




		public function psaagentapproval()

			{
				$this->db->select('*')
         			 ->from('kyctable')
                     ->join('psatable', 'kyctable.phone = psatable.phone');
				$query = $this->db->get();
				$data['records']=$query->result();
				$this->load->view('psaagentapproval',$data);
			}



			public function psaagentedit()

			{
				$phone=$this->input->post('phone');
				$_SESSION['phone']=$phone;
				$this->db->select('*')
         			 ->from('kyctable')
                     ->join('psatable', 'kyctable.phone = psatable.phone')
                     ->where('kyctable.phone', $phone);
				$query = $this->db->get();
				$data['records']=$query->result();
				$this->load->view('psaagentedit',$data);
			}



			public function psaupdate()

			{
				$fname=$_POST['firstname'];
			$lname=$_POST['lastname'];
			$dob=$_POST['dob'];
			$address=$_POST['address'];
			$city=$_POST['city'];
			$state=$_POST['state'];
			$zipcode=$_POST['zipcode'];
			$bname=$_POST['bname'];
			$emailid=$_POST['emailid'];
			$adharnum=$_POST['adharnum'];
			$pannum=$_POST['pannum'];
			$phone=$_POST['phone'];
			$status=$_POST['status'];
			$remarks=$_POST['remarks'];
			$appdt=$_POST['appdt'];
			$agentid=$_POST['agentid'];
			$agentpass=$_POST['agentpass'];

			$data=array('fname'=>$fname,
				'lname'=>$lname,
				'birth'=>$dob,
				'sname'=>$bname,
				'address'=>$address,
				'state'=>$state,
				'pincode'=>$zipcode,
				'emailid'=>$emailid,
				'adhar'=>$adharnum,
				'pan'=>$pannum,
				'status'=>$status,
				'phone'=>$phone,
				'appdt'=>$appdt,
				'remarks'=>$remarks,
				'agentid'=>$agentid,
				'agentpass'=>$agentpass


		);


			$this->Recharge_Model->psaupdate($data);


					if(true)
					{
						echo "success";
					}

					else
					{
						echo "failed";
					}

			}



			public function adminlogout()
			{
				$this->load->view('adminlogout');
			}


			public function usersmanage()

			{
				$this->db->select('*')
         			 ->from('corporateprofile')
         			 ->where('profiletype',12);
				$query = $this->db->get();
				$data['records']=$query->result();
				
				$this->load->view('usersmanage',$data);
			}


			public function otpgenerateuser()
			{

				//$this->load->model('Recharge_Model');
				$data = array('email' =>$this->input->post('email'));

				$query=$this->db->get_where("apiuser",array("phone"=>$data['email']));
				$query->result();
				if($query->num_rows()>0)

				{
					echo "duplicate";
				}

				else

				{	

				$x1=rand(1000,9999);
			 	$x2=rand(1000,$x1);
			 	$x3=rand($x2,9999);
			 	$otp=rand($x2,$x3);
			 	$timex=time();
			 	$status=0;
			 	$_SESSION['mobile_no']=$data['email'];
			 	$user = '0eGkG5Ic5Ea50ArMMvBjIA';
				$senderid = 'WEBSMS';
				$channel = 'Trans';
				$DCS = '0';
				$flashsms = '0';
				$number = $_SESSION['mobile_no'];
				$message = urlencode('Dear User, Your Merchant Mobile Number Verification Code Is ');
				$route = '1';
			 	
			 	

			 	$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$status);

			 	//$ch=curl_init('http://sms.rechargehubs.com/api/mt/SendSMS?APIKEY='.$user.'&senderid='.$senderid.'&channel='.$channel.'&DCS='.$DCS.'&flashsms='.$flashsms.'&number=8274801323&text='.$message.'&route='.$route.'');
				//$data = curl_exec($ch);
				//print($data);

			 	//http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=EZYONE&channel=Trans&DCS=0&flashsms=0&number='.$number.'&text='.$message.$otp.'&route=32

			 	
				
			 	$this->Recharge_Model->otpinsert($otpdata);

			 	$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$number.'&text='.$message.$otp.'&senderid=EZYONE&route_id=2&Unicode=0');

			 	//echo $str;
			 	
			 	//send_email('avijitpaul03021992@gmail.com',"please verify your mobile with the given OTP ".$otp." thank you","OTP Verification",'avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com');

			 	if(true)

			 	{
			 		echo "success";

			 	}

			 	else
			 	{
			 		echo "fail";
			 	}

			 	//echo $otp;

			 }


			}


			public  function newuserform()

			{
			$this->load->helper('url');
			$data['recordstate']=$this->Recharge_Model->selectstate();
			$this->load->view('newuserform',$data);
			}





			public function userforminput()

			{

				$x1=rand(10000000,99999999);
				 $x2=rand(10000000,$x1);
				 $x3=rand($x2,99999999);	

				$fullname=$_POST['fullname'];
				$dob=$_POST['dob'];
				$address=$_POST['address'];
				$city=$_POST['city'];
				$email=$_POST['emailid'];
				$passwords=substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') , 0 , 6 );
				$accountid=rand($x1,$x2);
				$phone=$_POST['phone'];
				//$sname=$_POST['bname'];
				$zipcode=$_POST['zipcode'];
				$state=$_POST['state'];
				//$bstate=$_POST['bstate'];
				//$adhar=$_POST['adharnum'];
				$state=$_POST['state'];
				$status=0;
				$usertype=$_POST['usertype'];
				$cdate=date('d-m-Y');
				//$manager=$_POST['manager'];
				$gender=$_POST['gender'];
				//$rdate=date('d-m-Y', strtotime($duration));
				$profiletype='corporate';
				$pancard=$_POST['pancard'];
				$documentper=$_POST['documentper'];
				$docid=$_POST['docid'];
				$marital=$_POST['marital'];
				$study=$_POST['study'];
				$board=$_POST['board'];
				$docfile=$_POST['docfile'];
				$target_dir = "./empdata/";
				$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
					$id=rand($x3c,$x1c);
					$photo_basename=basename($id."_docfile_".$_FILES["docfile"]["name"]);
					$target_file_photo = $target_dir . $photo_basename;
					move_uploaded_file($_FILES["docfile"]["tmp_name"], $target_file_photo);

				$message=urlencode('Please Login www.ezyone.in User ID: '.$phone.' Password: '.$passwords.' Please change your Password for sequrity reason. Thank you for EZYONE.');
				
					

				if($usertype==4)
				{
					$bstate=$_POST['bstate'];
					$uidmass=explode('/', $bstate);
					$bstateid=$uidmass[0];
					$bstatename=$uidmass[1];
					//$userphone=$uidmass[2];
					//echo $bstate;
					$querybstate=$this->db->get_where("circlecode",array("circlecode"=>$bstateid));
					$retbstate=$querybstate->row();
					if($querybstate->num_rows()>0)
		     			{
		     				$pincodecirclecode=$retbstate->pincode;
		     			}
		     			//echo $pincodecirclecode;
				}

				if($usertype==5 || $usertype==6 || $usertype==7 || $usertype==8)
				{
					$bstateid=$_POST['bstateid'];
					$bstatename=$_POST['bstatename'];
					$ddistrict=$_POST['bdist'];
				    foreach( $ddistrict as $key => $n ) 
					{
						$pincodecirclecode=$ddistrict[$key].','.$pincodecirclecode;
					}
					$bstate=0;
				}

				if($usertype==13)
				{
					
				}

				$data=array('fullname'=>$fullname,
				//'lname'=>$lname,
				'birth'=>$dob,
				'address'=>$address,
				'city'=>$city,
				'email'=>$email,
				'pass'=>$passwords,
				'accountid'=>$accountid,
				'cdate'=>$cdate,
				//'rdate'=>$rdate,
				'phone'=>$phone,
				//'sname'=>$sname,
				'pincode'=>$zipcode,
				//'pan'=>$pan,
				//'adhar'=>$adhar,
				'state'=>$state,
				//'duration'=>$duration,
				'status'=>$status,
				'usertype'=>$usertype,
				'gender'=>$gender,
				'profiletype'=>'corporate',
				//'bstate'=>'0',
				//'dist'=>$datadistt
				'bpincode'=>$pincodecirclecode,
				'circlecode'=>$bstateid,
				'circlename'=>$bstatename,
				'pancard'=>$pancard,
				'documentper'=>$documentper,
				'docid'=>$docid,
				'marital'=>$marital,
				'study'=>$study,
				'board'=>$board,
				'docfile'=>$photo_basename,
				'target'=>$_POST['target'],
				'anpack'=>$_POST['annpack'],
				'monpack'=>$_POST['monpack']
				
				);
				$query=$this->db->get_where("member",array("phone"=>$phone));
				$ret=$query->row();

					

 					if($query->num_rows()>0)
		     			{
		     				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Account already exists.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
		     			}

		     			else
		     			{
		     				$this->Recharge_Model->addmember($data);
							$walletdata=array('accountid'=>$accountid,'balance'=>0);
							$this->Recharge_Model->apiwalletinst($walletdata);
							$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$phone.'&text='.$message.'&senderid=EZYONE&route_id=2&Unicode=0');
						

					if(true)
					{
						if($usertype==4)
							{
								$datamap=array('accountid'=>$accountid);
								$this->Recharge_Model->empdatamap($datamap);
							}


						if($usertype==5)
				{
					$datamap=array('accountid'=>$accountid,'bmid'=>$_POST['uppline']);
					$this->Recharge_Model->empdatamap($datamap);
				}

				if($usertype==6)
				{
					$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
					if($datarest->num_rows()>0)
							{
								$usermember=$datarest->row();
								$accdmid=$usermember->accountid;
								$bmid=$usermember->bmid;
					
							}
					$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid);
					$this->Recharge_Model->empdatamap($datamap);
				}

				if($usertype==11 || $usertype==7)
				{
					$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
					if($datarest->num_rows()>0)
							{
								$usermember=$datarest->row();
								$accdmid=$usermember->accdmid;
								$bmid=$usermember->bmid;
								$smid=$usermember->accountid;
								
							}
					$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid,'smid'=>$smid);
					$this->Recharge_Model->empdatamap($datamap);
				}

				

				if($usertype==8)
				{
					$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
					if($datarest->num_rows()>0)
							{
								$usermember=$datarest->row();
								$accdmid=$usermember->accdmid;
								$bmid=$usermember->bmid;
								$smid=$usermember->smid;
								$sicid=$usermember->accountid;
								
							}
					$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid,'smid'=>$smid,'sicid'=>$sicid);
					$this->Recharge_Model->empdatamap($datamap);
				}	

						echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been added successfully.
			                   <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                    </button>
			               </div>";
					}
				}
					if(false)
					{
						echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
	                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
	                     <span aria-hidden='true'>×</span>
	                     </button>
	                </div>";
					}	

			}






			public function usereditview()
			{
				//$phone=$this->input->post('phone');
				//$accounttype=$_POST['accounttype'];
				//$_SESSION['phone']=$phone;
				$accountid=$_POST['accountid'];

				$query=$this->db->get_where("apiuser",array("accountid"=>$accountid));
				$data['records']=$query->result();

				$this->load->view('usereditview',$data);


					
			
				
			}


			public function userupdate()
				{
			$fname=$_POST['firstname'];
			$lname=$_POST['lastname'];
			$phone=$_POST['phone'];
			$duration=$_POST['subscription'];
			//$cdate=$_POST['sddate'];
			$rdate=date('d-m-Y', strtotime($duration));
			$accountid=$_POST['accountid'];
			

			//echo $cdate;
			
			$data=array('accountid'=>$accountid,
				'fname'=>$fname,
				'lname'=>$lname,
				'phone'=>$phone,
				'birth'=>$_POST['dob'],
				'address'=>$_POST['address'],
				'city'=>$_POST['city'],
				'state'=>$_POST['state'],
				'pincode'=>$_POST['zipcode'],
				'sname'=>$_POST['bname'],
				'pan'=>$_POST['pannum'],
				'emailid'=>$_POST['emailid'],
				'phone'=>$_POST['phone'],
				'adhar'=>$_POST['adharnum'],
				'rdate'=>$rdate,
				'duration'=>$duration,
				'status'=>$_POST['status']);


				$this->Recharge_Model->apiuserupdate($data);


				if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been added successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}



			}



			public function debitcredit()

			{
				$data['records']=$this->Recharge_Model->creditdebit();
				$data['record']=$this->Recharge_Model->apiusermodel();

				$this->load->view('debitcredit.php',$data);
			}



			public function creditinsert()
			{

				$x1=rand(1000000000,9999999999);
				 $x2=rand(1000000000,$x1);
			 		$x3=rand($x2,9999999999);

				$utype=$_POST['creditusertype'];
				$uidmass=explode('|', $_POST['credituserid']);
				$userid=$uidmass[0];
				$username=$uidmass[1];
				$userphone=$uidmass[2];
				$dttrans=date('d-m-Y');
				$amount=$_POST['creditamt'];
				$pmode=$_POST['creditpmtmode'];
				$comment=$_POST['creditcmt'];
				$tansid=rand($x3,$x2);
				$status=0;

				$apiwallet=$this->Recharge_Model->apiwallet($userid);

				if($apiwallet->num_rows()>0)
				{
					$balance=$apiwallet->row();
					$closingblc=($balance->balance)+$amount;
					$walletdata=array('accountid'=>$userid,'balance'=>$closingblc);
					$this->Recharge_Model->apiwalletupdate($walletdata);	
				}

				else
				{
					$walletdata=array('accountid'=>$userid,'balance'=>$amount);
					$this->Recharge_Model->apiwalletinst($walletdata);	


				}

				$data=array('transctionid'=>$tansid,
					'accountid'=>$userid,
					'name'=>$username,
					'mobile'=>$userphone,
					'dttrans'=>$dttrans,
					'amount'=>$amount,
					'pmode'=>$pmode,
					'status'=>$status,
					'comment'=>$comment

						);

				$this->Recharge_Model->creditinst($data);

				if(true)
				{

					$walletsummary=array('accountid'=>$userid,'amount'=>$amount,'transtype'=>'Wallet Credit','transid'=>$tansid,'transc'=>'Credit','cblnc'=>$closingblc,'oblnc'=>$balance->balance);
					$this->walletsummary($walletsummary);

					echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Credit transaction successful. Please sync transaction table for updates.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
				}

				else
				{
					echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
				}

				//echo $utype.$userid.$username.$userphone;
			}





			public function debitinsert()
			{

				$x1=rand(1000000000,9999999999);
				 $x2=rand(1000000000,$x1);
			 		$x3=rand($x2,9999999999);

				$utype=$_POST['debitusertype'];
				$uidmass=explode('|', $_POST['debituserid']);
				$userid=$uidmass[0];
				$username=$uidmass[1];
				$userphone=$uidmass[2];
				$dttrans=date('d-m-Y');
				$amount=$_POST['debitamt'];
				$comment=$_POST['debitcmt'];
				$tansid=rand($x3,$x2);
				$status=1;
				
				$data=array('transctionid'=>$tansid,
					'accountid'=>$userid,
					'name'=>$username,
					'mobile'=>$userphone,
					'dttrans'=>$dttrans,
					'amount'=>$amount,
					'pmode'=>'N/A',
					'status'=>$status,
					'comment'=>$comment

						);

				$apiwallet=$this->Recharge_Model->apiwallet($userid);

				if($apiwallet->num_rows()>0)
				{


					$balance=$apiwallet->row();
					if($balance->balance<=$amount)
					{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Debit transaction fail due to insufficient balance.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
					}
					else
					{
					$closingblc=($balance->balance)-$amount;
					$walletdata=array('accountid'=>$userid,'balance'=>$closingblc);
					$this->Recharge_Model->apiwalletupdate($walletdata);

					$this->Recharge_Model->debitinst($data);

					$walletsummary=array('accountid'=>$userid,'amount'=>$amount,'transtype'=>'Wallet Debit','transid'=>$tansid,'transc'=>'Debit','oblnc'=>$balance->balance,'cblnc'=>$closingblc);
					$this->walletsummary($walletsummary);

					if(true)
				{

					//$walletsummary=array('accountid'=>$userid,'amount'=>$amount,'transtype'=>'Wallet Debit','transid'=>$transid,'transc'=>'Debit','oblnc'=>$balance->balance,'cblnc'=>$closingblc);
					//$this->walletsummary($walletsummary);


					echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Debit transaction successful. Please sync transaction table for updates.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
				}

				else
				{
					echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
				}

				}

				
				}

				else
				{
					echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Debit transaction fail due to insufficient balance.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
				}



				
				//echo $utype.$userid.$username.$userphone;
			}




			public function vendorrecords()
			{
				$data['records']=$this->Recharge_Model->vendorrecords();
				$this->load->view('vendorrecords.php',$data);
			}


			public function otpgeneratevend()
			{
				//$this->load->model('Recharge_Model');
				$data = array('email' =>$this->input->post('email'));

				$query=$this->db->get_where("vendormanger",array("phone"=>$data['email']));
				$query->result();
				if($query->num_rows()>0)

				{
					echo "duplicate";
				}

				else

				{	

				$x1=rand(1000,9999);
			 	$x2=rand(1000,$x1);
			 	$x3=rand($x2,9999);
			 	$otp=rand($x2,$x3);
			 	$timex=time();
			 	$status=0;
			 	$_SESSION['mobile_no']=$data['email'];


			 	$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$status);

				
			 	$this->Recharge_Model->otpinsert($otpdata);
			 	
			 	//send_email('avijitpaul03021992@gmail.com',"please verify your mobile with the given OTP ".$otp." thank you","OTP Verification",'avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com');

			 	if(true)

			 	{
			 		echo "success";

			 	}

			 	else
			 	{
			 		echo "fail";
			 	}

			 	//echo $otp;

			 }

			}


			public function newvendorform()
			{

				$this->load->view('newvendorform.php');
				
			}


			public function vendorforminput()
			{
				$x1=rand(10000000,99999999);
			 	$x2=rand(10000000,$x1);
			 	$x3=rand($x2,99999999);
			 	$otp=rand($x2,$x3);
				$target_dir = "./vendorupload/";
			$id=$_POST['phone'];
			$status=0;
			$pan_basename=basename($id."_pan_".$_FILES["cpan"]["name"]);
			$adhar_basename=basename($id."_adhar_".$_FILES["cadh"]["name"]);
			$photo_basename=basename($id."_photo_".$_FILES["cphoto"]["name"]);

			$target_file_pan = $target_dir . $pan_basename;
			$target_file_adhar = $target_dir . $adhar_basename;
			$target_file_photo = $target_dir . $photo_basename;
			
			move_uploaded_file($_FILES["cpan"]["tmp_name"], $target_file_pan);
			move_uploaded_file($_FILES["cadh"]["tmp_name"], $target_file_adhar);
			move_uploaded_file($_FILES["cphoto"]["tmp_name"], $target_file_photo);

			if(function_exists('date_default_timezone_set')) 
				{
    					date_default_timezone_set("Asia/Kolkata");
				}

				$date_app=date("d-m-Y");
				$time_app=date("H:i a");

				$applied=$date_app." &nbsp;".$time_app;

			$fname=$_POST['firstname'];
			$lname=$_POST['lastname'];
			$birth=$_POST['dob'];
			$email=$_POST['emailid'];
			$appdt=$applied;
			$address=$_POST['address'];
			$city=$_POST['city'];
			$state=$_POST['state'];
			$pincode=$_POST['zipcode'];
			$pan=$_POST['pannum'];
			$adhar=$_POST['adharnum'];
			$service=$_POST['service'];
			$phone=$id;
			$vendorid=rand($otp,99999999);
			

			$data=array('fname'=>$fname,
				'lname'=>$lname,
				'birth'=>$birth,
				'phone'=>$phone,
				'email'=>$email,
				'appdt'=>$appdt,
				'address'=>$address,
				'city'=>$city,
				'state'=>$state,
				'pincode'=>$pincode,
				'pan'=>$pan,
				'adhar'=>$adhar,
				'service'=>$service,
				'cpan'=>$pan_basename,
				'cadhar'=>$adhar_basename,
				'photo'=>$photo_basename,
				'vendorid'=>$vendorid

		);



			
					$this->Recharge_Model->vendornsert($data);


					if(true)
					{
						echo "success";
					}

					else
					{
						echo "failed";
					}
			
			}



		public function distadmin()
		{
			$this->load->view('distadmin.php');
		}




		public function apiuser()
		{
			$data['records']=$this->Recharge_Model->mediaload();
			$this->load->view('apiuser.php',$data);
		}


 
		public function psaagentview()
		{
			$accountid=$_SESSION['accountid'];
			$data['records']=$this->Recharge_Model->psaagentview($accountid);
			$this->load->view('psaagentview.php',$data);
		}


		public function otpgeneratepsa()

			{
				//$this->load->model('Recharge_Model');
				$data = array('email' =>$this->input->post('email'));

				$query=$this->db->get_where("psatable",array("phone"=>$data['email']));
				$query->result();
				if($query->num_rows()>0)

				{
					echo "duplicate";
				}

				else

				{	

				$x1=rand(1000,9999);
			 	$x2=rand(1000,$x1);
			 	$x3=rand($x2,9999);
			 	$otp=rand($x2,$x3);
			 	$timex=time();
			 	$status=0;
			 	$_SESSION['mobile_no']=$data['email'];


			 	$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$status);

				
			 	$this->Recharge_Model->otpinsert($otpdata);
			 	
			 	//send_email('avijitpaul03021992@gmail.com',"please verify your mobile with the given OTP ".$otp." thank you","OTP Verification",'avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com');

			 	if(true)

			 	{
			 		echo "success";

			 	}

			 	else
			 	{
			 		echo "fail";
			 	}

			 	//echo $otp;

			 }
			}


			public function newpsaform()
			{
				$this->load->view('newpsaform.php');
			}


			public function newpsaforminsert()
			{

			$fname=$_POST['firstname'];
			$accountid=$_POST['accountid'];
			$sname=$_POST['bname'];
			$address=$_POST['address'];
			//$city=$_POST['city'];
			$state=$_POST['state'];
			$phone=$_POST['phone'];
			$email=$_POST['emailid'];
			$appdt=date('d-m-Y h:i:sa');
			$pan=$_POST['pannum'];
			$adhar=$_POST['adharnum'];
			$zipcode=$_POST['zipcode'];
			$status=0;
			$data=array('fname'=>$fname,
				'accountid'=>$accountid,
				'sname'=>$sname,
				'address'=>$address,
				//'city'=>$city,
				'state'=>$state,
				'phone'=>$phone,
				'email'=>$email,
				'appdt'=>$appdt,
				'pan'=>$pan,
				'adhar'=>$adhar,
				'status'=>$status,
				'zipcode'=>$zipcode
				
				);


			$query_phone=$this->db->get_where("psatable",array('phone'=>$phone));
			//$ret=$query->row();	
			$query_email=$this->db->get_where("psatable",array('email'=>$email));	
			$query_pan=$this->db->get_where("psatable",array('pan'=>$pan));
			$query_adhar=$this->db->get_where("psatable",array('adhar'=>$adhar));

			$this->db->select('*')
         			 ->from('setcomission')
         			 ->where('accountid',$_SESSION['accountid'])
         			 ->order_by('id','DESC')
         			 ->limit(1);
				$queryc = $this->db->get();
			
				$datanorm= $queryc->row();

				$netcomission=$datanorm->comission;

				$total_amt=0;

				$wallblc=$this->walletblce();




 					if($query_phone->num_rows()>0)
		     			{

		     				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Mobile Number Exists.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
		     			}

		     		elseif($query_email->num_rows()>0)
		     		{
		     			echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Email Id Exists.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
		     		}	

		     		elseif($query_pan->num_rows()>0)
		     		{
		     			echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;PAN Number Exists.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
		     		}

		     		elseif($query_adhar->num_rows()>0)
		     		{
		     			echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Adhar Number Exists.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
		     		}

		     		elseif($wallblc<$total_amt)
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Insufficient Wallet Balance to buy atleast 5 PSA Coupon.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
						}

		     			else
		     			{
		     				$closingblc=$wallblc-$total_amt;
							$walletdata=array('accountid'=>$_SESSION['accountid'],'balance'=>$closingblc);
							$this->Recharge_Model->apiwalletupdate($walletdata);

							//$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$total_amt,'transtype'=>'5 Coupon Buy','transid'=>$orderid,'transc'=>'Debit','oblnc'=>$wallblc,'cblnc'=>$closingblc);
							//$this->walletsummary($walletsummary);



		     				$this->Recharge_Model->newpsaagent($data);

			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been added successfully. Please Click Manage button from PSA Agent list to procced further.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}


		     			}


			


			}



			public function psaeditview()
			{
				$phone=$this->input->post('phone');
				$email=$this->input->post('email');
				$_SESSION['phone']=$phone;
		
				$query=$this->db->get_where("psatable",array("phone"=>$phone,"email"=>$email));
				$data['records']=$query->result();
				$this->load->view('psaeditview',$data);
			}



			public function updatepsaforminsert()

			{

			$fname=urlencode($_POST['firstname']);
			$fnamex=$_POST['firstname'];

			//$accountid=$_POST['accountid'];
			$sname=urlencode($_POST['bname']);
			$snamex=$_POST['bname'];

			$address=urlencode($_POST['address']);
			//$city=$_POST['city'];
			$state=urlencode($_POST['state']);
			$phone=$_POST['phone'];
			$email=$_POST['emailid'];
			//$appdt=date('d-m-Y');
			$statex=$_POST['state'];
			$pan=$_POST['pannum'];
			$adhar=$_POST['adharnum'];
			$zipcode=urlencode($_POST['zipcode']);
			$message=urlencode('Dear '.$fnamex.', You PSA registration request has been recived. Your account will activate within 24 hrs. Thank you'); 

			$datec=date('d-m-Y h:i:sa');

			//$status=0;
			$agentid=$_POST['agentid'];

			$str = file_get_contents('https://partners.worthpaisa.com/api/pancard/create?token=kTjkpgkrjnnSCngST6gsghmzO6dqK0&vle_id='.$agentid.'&vle_name='.$sname.'&location='.$address.'&contact_person='.$fname.'&pincode='.$zipcode.'&state='.$state.'&email='.$email.'&mobile='.$phone.'');




			$json=json_decode($str,true);

			$statuscode=$json['statuscode']." ".$json['message']." ".$json['status'];
			//$json['statuscode']='TXN';
			$status=$json['statuscode'];

			if($status=='TXN')
			{
				

				$strv = file_get_contents('http://partners.worthpaisa.com/api/pancard/request?token=kTjkpgkrjnnSCngST6gsghmzO6dqK0&pantokens=5&vle_id='.$agentid.'');

			$jsonv=json_decode($strv,true);

				
			//$jsonv['statuscode']="TXN";

			if($jsonv['statuscode']=="TXN")
			{

				$this->db->select('*')
         			 ->from('setcomission')
         			 ->where('accountid',$_SESSION['accountid'])
         			 ->order_by('id','DESC')
         			 ->limit(1);

         			 


				$queryc = $this->db->get();
			
				$datanorm= $queryc->row();

				$netcomission=$datanorm->comission;

				$orderidcoupon=$this->couponorderid();

				$total_amt=(107-$netcomission)*5;

				//$txnid=12121;
				$emrp=107*5;
				$netprofit=11.5*5;
				$txnid=$jsonv['txnid'];
				$datac=array('agentid'=>$agentid,
						'agentname'=>$fnamex,
						'agentphone'=>$phone,
						'uty'=>5,
						'accountid'=>$_SESSION['accountid'],
						'mrp'=>$total_amt,
						'orderid'=>$orderidcoupon,
						'datex'=>$datec,
						'profit'=>$netprofit,
						'txnid'=>$txnid,
						'emrp'=>$emrp,
						'statuscode'=>"{"."statuscode:".$jsonv['statuscode'].", status:".$jsonv['status'].", message:".$jsonv['message']."}"
					);

			$this->Recharge_Model->utipancouponbuy($datac);



			$data=array('fname'=>$fnamex,
				//'accountid'=>$accountid,
				'sname'=>$snamex,
				'address'=>$address,
				//'city'=>$city,
				'state'=>$statex,
				'phone'=>$phone,
				'email'=>$email,
				'appdt'=>$datec,
				'pan'=>$pan,
				'adhar'=>$adhar,
				//'status'=>$status,
				'zipcode'=>$zipcode,
				'agentid'=>$agentid,
				'response'=>"{"."statuscode:".$json['statuscode'].", status:".$json['status'].", message:".$json['message']."}"
				
				);		
			
	$this->Recharge_Model->updatepsaagent($data);

	$str=file_get_contents('http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=UTIPSA&channel=Trans&DCS=0&flashsms=0&number='.$phone.'&text='.$message.'&route=32');


			//echo date("d-m-Y");
			if(true)
			{
				$walletblce=$this->walletblce();

				$oblnc=$walletblce+$total_amt;
				$closingblc=$walletblce;

				$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$total_amt,'transtype'=>'5 Coupon Buy','transc'=>'Debit','oblnc'=>$oblnc,'cblnc'=>$closingblc,'transid'=>$orderidcoupon);
							$this->walletsummary($walletsummary);	


				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been added successfully. Data will be availabe by 24 hours.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			

			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;".$statuscode."
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}


			


		}

	}


		public function dashboard()
		{
			$this->load->view('dashboard.php');
		}

		public function resetapipassword()
		{
			$accountid=$_POST['accountidx'];
			$phone=$_POST['phonex'];
			$name=$_POST['namex'];
			$passwords=substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') , 0 , 6 );
			$message=urlencode('Dear '.$name.', Your password has been reset successfully. Your new password '.$passwords.'  '); 

			


			$data=array('accountid'=>$accountid,
				//'accountid'=>$accountid,
				'pass'=>$passwords);

		$this->Recharge_Model->resetpassword($data);

		

		//http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=EZYONE&channel=Trans&DCS=0&flashsms=0&number='.$phone.'&text='.$message.'&route=32

		$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$phone.'&text='.$message.'&senderid=EZYONE&route_id=2&Unicode=0');

			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Password has been reset.Please check your registered mobile number for confirmation.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}




		}


		public function psaeditviewadmin()

			{
				$phone=$this->input->post('phone');
				$email=$this->input->post('email');
				$_SESSION['phone']=$phone;
		
				$query=$this->db->get_where("psatable",array("phone"=>$phone,'email'=>$email));
				$data['records']=$query->result();
				$this->load->view('psaeditviewadmin.php',$data);
			}


			public function psastatuscheck()
			{
				$agentid=$_POST['agentid'];
				$str = file_get_contents('http://partners.worthpaisa.com/api/pancard/status?token=kTjkpgkrjnnSCngST6gsghmzO6dqK0&vle_id='.$agentid.'');
				//echo $str;
				//echo $agentid;
				//http://partners.worthpaisa.com/api/pancard/status?token={token}&vle_id= IP23454 Response –

				$json=json_decode($str,true);

				$statuscode=$json['statuscode']." ".$json['message']." ".$json['status'];
				$status=$json['statuscode'];

				if($status=='TXN')
				{
					echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;".$json['message']."
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";

				}
				else
				{
					echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;".$statuscode."
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                	</div>";
				}

			}




			public function psaupdateadmin()
			{

				$fname=urlencode($_POST['firstname']);
				$fnamex=$_POST['firstname'];

			//$accountid=$_POST['accountid'];
				$sname=urlencode($_POST['bname']);
				$snamex=$_POST['bname'];
				$status=$_POST['status'];

				$address=urlencode($_POST['address']);
				//$city=$_POST['city'];
				$state=urlencode($_POST['state']);
				$statex=$_POST['state'];
				$phone=$_POST['phone'];
				$email=$_POST['emailid'];
				//$appdt=date('d-m-Y');
				$pan=$_POST['pannum'];
				$agentid=$_POST['agentid'];
				$adhar=$_POST['adharnum'];
				$zipcode=urlencode($_POST['zipcode']);
				$message=urlencode('Dear '.$fnamex.', your PSA has been activated .You Agent Id '.$agentid.' and Password '.$agentid.''); 


				$data=array('fname'=>$fnamex,
				//'accountid'=>$accountid,
				'sname'=>$snamex,
				'address'=>$address,
				//'city'=>$city,
				'state'=>$statex,
				'phone'=>$phone,
				'email'=>$email,
				//'appdt'=>$appdt,
				'pan'=>$pan,
				'adhar'=>$adhar,
				//'status'=>$status,
				'zipcode'=>$zipcode,
				'status'=>$status,
				'agentid'=>$agentid);

		



			$this->Recharge_Model->updatepsaagentadmin($data);

		$str=file_get_contents('http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=UTIPSA&channel=Trans&DCS=0&flashsms=0&number='.$phone.'&text='.$message.'&route=32');


			//echo date("d-m-Y");
			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;PSA details has been updated and agent has been activated.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}


}





	public function userprofileedit()
		{
			//$phone=$this->input->post('phone');
			//$_SESSION['phone']=$phone;
		
			$query=$this->db->get_where("personalprofile",array("accountid"=>$_SESSION['accountid']));
			$query_comission=$this->db->get_where("setcomission",array("accountid"=>$_SESSION['accountid']));
			$data['records']=$query->result();
			$data['recordc']=$query_comission->result();

			$this->load->view('userprofileedit',$data);
		}

		public function userprofileupdate()
		{
			$fname=$_POST['firstname'];
			$lname=$_POST['lastname'];
			$phone=$_POST['phone'];
			//$duration=$_POST['subscription'];
			///$cdate=$_POST['sddate'];
			//$rdate=date('d-m-Y', strtotime($duration));
			

			//echo $cdate;
			
			$data=array('fname'=>$fname,
				'lname'=>$lname,
				'phone'=>$phone,
				'birth'=>$_POST['dob'],
				'address'=>$_POST['address'],
				'city'=>$_POST['city'],
				'state'=>$_POST['state'],
				'pincode'=>$_POST['zipcode'],
				'sname'=>$_POST['bname'],
				'pan'=>$_POST['pannum'],
				'emailid'=>$_POST['emailid'],
				'phone'=>$_POST['phone'],
				'adhar'=>$_POST['adharnum'],
				'accountid'=>$_POST['accountid']
				);


				$this->Recharge_Model->profileuserupdate($data);


				if(true)
			{
				echo "success";
			}

			else
			{
				echo "fail";
			}


		}


		public function contactus()
		{
			$this->load->view('contactus.php');
		}

		public function aboutus()
		{
			$this->load->view('aboutus.php');
		}

		public function resetpassword()
		{
			$query=$this->db->get_where("apiuser",array("accountid"=>$_SESSION['accountid']));
			$data['records']=$query->result();
			$this->load->view('resetpassword.php',$data);
		}

		public function  resetapipasswords()
		{
			$accountid=$_POST['accountidx'];
			$phone=$_POST['phonex'];
			$name=$_POST['namex'];
			$passwords=$_POST['newpass'];
			$cpasswords=$_POST['cpass'];



			if($passwords==$cpasswords)
			{
				$message=urlencode('Dear '.$name.', Your password has been reset successfully. Your new password '.$passwords.'  '); 

			

			$data=array('accountid'=>$accountid,
				//'accountid'=>$accountid,
				'pass'=>$passwords);

		$this->Recharge_Model->resetpassword($data);
		$this->Recharge_Model->passstatus($data);


		

		http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=EZYONE&channel=Trans&DCS=0&flashsms=0&number='.$phone.'&text='.$message.'&route=32

		$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$phone.'&text='.$message.'&senderid=EZYONE&route_id=2&Unicode=0');

			if(true)
			{
				echo "success";
			}

			else
			{
				echo "fail";
			}

			}

			else
			{
				echo "";
			}

			


		}






		public function kycprofileupdate()

		{
			$firstname=$_POST['firstname'];
			$lastname=$_POST['lastname'];
			$dob=$_POST['dob'];
			$gender=$_POST['gender'];
			$city=$_POST['city'];
			$state=$_POST['state'];
			$address=$_POST['address'];
			$caddress=$_POST['caddress']; 
		}







		public function setcomission()
		{
			$this->load->view('setcomission');
		}


		public function utipancoupon()
		{
			$data['records']=$this->Recharge_Model->pancoupondetail();


			$this->load->view('utipancoupon',$data);
		}


		public function pancouponupdate()
		{
			$mrp=$_POST['mrp'];
			$cp=$_POST['cp'];
			$profit=$_POST['profit'];
			$vname=$_POST['vname'];

			$data=array('mrp'=>$mrp,'costprice'=>$cp,'profit'=>$profit,'vname'=>$vname);
			$this->Recharge_Model->pancouponupdate($data);

			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been added successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}
		}


		public function comissionpackage()
		{
			$data['records']=$this->Recharge_Model->pancoupondetail();
			$data['record_sc']=$this->Recharge_Model->schemedetail();

			$this->load->view('comissionpackage',$data);
			//$this->load->view('comissionpackage');
		}


		public function schemepackage()
		{
			$scname=$_POST['scname'];
			$scper=$_POST['scper'];
			$stcst=$_POST['stcst'];
			$duration=$_POST['duration'];
			$dist=$_POST['dist'];
			$data=array('scname'=>$scname,'scper'=>$scper,'stcst'=>$stcst,'duration'=>$duration,'discount'=>$dist);

			$this->Recharge_Model->schemepackage($data);

			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been added successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

		}

		public function schemepackageupdate()
		{
			$scname=$_POST['scnamex'];
			$scper=$_POST['scperx'];
			$pacid=$_POST['pacid'];
			$stcst=$_POST['stcst'];
			$distx=$_POST['distx'];
			$duration=$_POST['durationx_txt'];
			$status=$_POST['statusx_txt'];
			$data=array('scname'=>$scname,'scper'=>$scper,'id'=>$pacid,'stcst'=>$stcst,'duration'=>$duration,'distx'=>$distx,'status'=>$status);
			$this->Recharge_Model->schemepackageupdate($data);

			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

		}


		public function setcomissionapi()
		{
			
			$data['record_pack']=$this->Recharge_Model->comissionpackdetail();
			$data['records']=$this->Recharge_Model->pancoupondetail();
			$data['record_sc']=$this->Recharge_Model->schemedetail();
			$data['record_api']=$this->Recharge_Model->apiusermodel();
			$this->load->view('setcomissionapi',$data);
		}

		public function setapicomission()
		{
			$accountid=$_POST['accountid'];
			$scname=$_POST['scname'];
			$orderid=rand(100000,rand(999999,10000));
			$scid=$_POST['scid'];
			$duration=$_POST['duration'];
			$discount=$_POST['discount'];
			$mprice=$_POST['mprice'];
			$disamt=$_POST['disamt'];
			$gstamt=0.18*$disamt;
			$total_amt=$disamt+$gstamt;
			$datex=date('d-m-Y');
			$data=array('orderid'=>$orderid,'scname'=>$scname,'scid'=>$scid,'accountid'=>$accountid,'duration'=>$duration,'discount'=>$discount,'mprice'=>$mprice,'dprice'=>$total_amt,'datex'=>$datex,'comission'=>$_POST['comission']);
			$query_veriy=$this->Recharge_Model->setapicomissionstatus($_SESSION['accountid']);


			if($query_veriy->num_rows()>0)
			{
				$schemedetail=$query_veriy->row();
				$schemename=$schemedetail->scname;
				if($schemename!="Trial Pack")
		     			{
		     				echo "Service Already Active";
		     			}

		     			else
		     			{
		     				$wallblc=$this->walletblce();
		     				if($wallblc>$total_amt)
								{
									$closingblc=$wallblc-$total_amt;
									$walletdata=array('accountid'=>$_SESSION['accountid'],'balance'=>$closingblc);
									$this->Recharge_Model->apiwalletupdate($walletdata);

									$this->Recharge_Model->setapicomissioninst($data);

									$datapack=array('scname'=>'Trial Pack','accountid'=>$_SESSION['accountid']);

									$this->Recharge_Model->updateapicomissiontrialpack($datapack);

									$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$total_amt,'transtype'=>'UTI Service '.$scname,'transc'=>'Debit','transid'=>$orderid,'cblnc'=>$closingblc,'oblnc'=>$wallblc);

										if(true)
										{

											$this->walletsummary($walletsummary);
											echo "Service Has Been Confirm";
										}

										else
										{
											echo "Fail";
										}
								}

								else
								{
									echo "Insufficient Wallet Balance";
								}

		     			}

			}

			else
			{
					$wallblc=$this->walletblce();	
					if($wallblc>$total_amt)
					{
						$closingblc=$wallblc-$total_amt;
						$walletdata=array('accountid'=>$_SESSION['accountid'],'balance'=>$closingblc);
						$this->Recharge_Model->apiwalletupdate($walletdata);

						$this->Recharge_Model->setapicomissioninst($data);

						//$datapack=array('scname'=>'Trial Pack','accountid'=>$_SESSION['accountid']);

						//$this->Recharge_Model->updateapicomissiontrialpack($datapack);

						$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$total_amt,'transtype'=>'UTI Service '.$scname,'transc'=>'Debit','transid'=>$orderid,'cblnc'=>$closingblc,'oblnc'=>$wallblc);

							if(true)
							{

								$this->walletsummary($walletsummary);
								echo "Service Has Been Confirm";
							}

							else
							{
								echo "Fail";
							}

					}

					else
					{
						echo "Insufficient Wallet Balance";
					}
			}

			



		}


		public function setcomissionupdate()
		{
			


		}

		public function mycomission()
		{
			$data['records']=$this->Recharge_Model->pancoupondetail();
			$data['record_sc']=$this->Recharge_Model->schemedetail();
			$data['recordid']=$this->Recharge_Model->mycomission($_SESSION['accountid']);
			$this->load->view('mycomission',$data);
		} 


		public function utipancouponbuy()
		{
			
		}


		public function pancouponbuy()
		{
			$agentid=$_POST['agentid'];
			$agentmobile=$_POST['agentmobile'];
			$agentname=$_POST['agentname'];
			$uty=$_POST['uty'];
			$accountid=$_POST['accountid'];
			$mrp=$_POST['mrp'];
			$profit=$_POST['profit'];
			$netprofit=$profit*$uty;
			$orderid=$_POST['orderid']+1;
			$datext=date('d-m-Y');
			$timex=date('H:m:s');
			$emrp=$_POST['emrp'];
			$tdate=$datext." & ".$timex;

			$wallblc=$this->walletblce();

			if($mrp>$wallblc)
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Insufficient Balance for this transaction.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}


			else
			{
					
			$str = file_get_contents('http://partners.worthpaisa.com/api/pancard/request?token=kTjkpgkrjnnSCngST6gsghmzO6dqK0&pantokens='.$uty.'&vle_id='.$agentid.'');

			$json=json_decode($str,true);

				
			$json['statuscode']="TXN";

			if($json['statuscode']=="TXN")
			{

				
				$txnid=$json['txnid'];
				$data=array('agentid'=>$agentid,
						'agentname'=>$agentname,
						'agentphone'=>$agentmobile,
						'uty'=>$uty,
						'accountid'=>$accountid,
						'mrp'=>$mrp,
						'orderid'=>$orderid,
						'datex'=>$tdate,
						'profit'=>$netprofit,
						'txnid'=>$txnid,
						'emrp'=>$emrp,
						'statuscode'=>"{"."statuscode:".$json['statuscode'].", status:".$json['status'].", message:".$json['message']."}"
					);

			$this->Recharge_Model->utipancouponbuy($data);

			if(true)
			{
				$closingblc=$wallblc-$mrp;
				$walletdata=array('accountid'=>$_SESSION['accountid'],'balance'=>$closingblc);
				$this->Recharge_Model->apiwalletupdate($walletdata);

				$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$mrp,'transtype'=>$uty.' Coupon Buy','transid'=>$orderid,'transc'=>'Debit','oblnc'=>$wallblc,'cblnc'=>$closingblc);
				$this->walletsummary($walletsummary);

				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Coupon has been bought successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}


			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;".$json['message']."
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}


			}

		}
 

		public function manageemployee()
		{
			$data['records']=$this->Recharge_Model->empdetails();
			$this->load->view('manageemployee',$data);
		}

		public function addemployee()
		{
			$this->load->view('addemployee.php');
		}

		public function instemployee()
		{
			$empname=$_POST['empname'];
			$empid=rand(100000,rand(999999,10000));
			$mobile=$_POST['mobile'];
			$pemail=$_POST['pemail'];
			$oemail=$_POST['oemail'];
			$desig=$_POST['desig'];
			$ctc=$_POST['ctc'];
			$doj=$_POST['doj'];

			$data=array('empid'=>$empid,
						'empname'=>$empname,
						'mobile'=>$mobile,
						'ctc'=>$ctc,
						'designation'=>$desig,
						'doj'=>$doj,
						'pemail'=>$pemail,
						'oemail'=>$oemail);

			$this->Recharge_Model->instemp($data);

			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

		}


		public function payslips()
		{
			$empid=$_POST['empid'];
			$data['records']=$this->Recharge_Model->empdt($empid);
			$data['record_pay']=$this->Recharge_Model->paygmt($empid);
			$this->load->view('payslips',$data);
		}


		public function paymentemp()
		{
			$empid=$_POST['empid'];
			$refid=rand(100000,rand(999999,10000));
			$empname=$_POST['empname'];
			$desig=$_POST['desig'];
			$paym=$_POST['paym'];
			$payy=$_POST['payy'];
			$sd=$_POST['sd'];
			$bp=$_POST['bp'];
			$da=$_POST['da'];
			$adj=$_POST['adj'];
			$netpay=$_POST['netpay'];

			$data=array('refid'=>$refid,
						'empid'=>$empid,
						'empname'=>$empname,
						'designation'=>$desig,
						'paymonth'=>$paym,
						'payyear'=>$payy,
						'sdt'=>$sd,
						'ctc'=>$bp,
						'adj'=>$adj,
						'grosssal'=>$da,
						'netpay'=>$netpay	);

			$this->Recharge_Model->payslipinst($data);
			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}
		}

		public function payslips_generate()
		{
			$refid=$_POST['refid'];
			$data['records']=$this->Recharge_Model->payslipout($refid);
			$this->load->view('payslips_generate',$data);
		}


		public function editemp()
		{
			$empid=$_POST['empid'];
			$data['records']=$this->Recharge_Model->empdt($empid);
			$this->load->view('editemp',$data);
		}


		public function updateemployee()
		{
			$empname=$_POST['empname'];
			$empid=$_POST['empid'];
			$mobile=$_POST['mobile'];
			$pemail=$_POST['pemail'];
			$oemail=$_POST['oemail'];
			$desig=$_POST['desig'];
			$ctc=$_POST['ctc'];
			$doj=$_POST['doj'];

			$data=array('empid'=>$empid,
						'empname'=>$empname,
						'mobile'=>$mobile,
						'ctc'=>$ctc,
						'designation'=>$desig,
						'doj'=>$doj,
						'pemail'=>$pemail,
						'oemail'=>$oemail);



			$this->Recharge_Model->updateemployee($data);
			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}


		}


		public function marketing()
		{
			$data['records']=$this->Recharge_Model->medialoadx();
			$this->load->view('marketing',$data);
		}

		public function mediainst()
		{
			$target_dir = "./mediaupload/";
			$id=rand(9999,1000);
			//$status=0;
			$media_basename=basename($id."_mezyone_".$_FILES["marketingimg"]["name"]);
			$target_file_media = $target_dir . $media_basename;
			move_uploaded_file($_FILES["marketingimg"]["tmp_name"], $target_file_media);

			$addcoment=$_POST['addcoment'];
			$home=isset($_POST['home']);
			$mer=isset($_POST['mer']);

			if($mer==null)
			{
				$mer=0;
			}

			elseif($home==null)
			{
				$home=0;
			}

			if($_FILES["marketingimg"]["name"]==null)
			{
				$media_basename="0";
			}

			$data=array('img'=>$media_basename,'content'=>$addcoment,'home'=>$home,'mer'=>$mer);

			$this->Recharge_Model->mediainst($data);

			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}
		}


		public function mediadisplay()
		{
			$data['records']=$this->Recharge_Model->mediaload();
			$this->load->view('mediadisplay',$data);
		
		}


		public function updatemedia()
		{
			$idx=$_POST['id'];
			$addcoment=$_POST['addcoment'];
			$home=isset($_POST['home']);
			$mer=isset($_POST['mer']);

			if($mer==null)
			{
				$mer=0;
			}

			elseif($home==null)
			{
				$home=0;
			}

			if($_FILES["marketingimg"]["size"]==0)
			{

				$data=array("id"=>$idx,"content"=>$addcoment,"home"=>$home,"mer"=>$mer);
				$this->Recharge_Model->mediaupdate_u($data);

				if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}
			}
			else
			{
				$target_dir = "./mediaupload/";
				$id=rand(9999,1000);
				//$status=0;
				$media_basename=basename($id."_mezyone_".$_FILES["marketingimg"]["name"]);
				$target_file_media = $target_dir . $media_basename;
				move_uploaded_file($_FILES["marketingimg"]["tmp_name"], $target_file_media);

				$data=array("id"=>$idx,"content"=>$addcoment,"img"=>$media_basename,"home"=>$home,"mer"=>$mer);
				$this->Recharge_Model->mediaupdate_img($data);

				if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}



			}

			


		}



		public function deletemedia()
		{
			$id=$_POST['mediaid'];
			$this->Recharge_Model->deletemedia($id);

			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been deleted successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}
		}


		public function couponhistory()
		{
			$data['records']=$this->Recharge_Model->psatablecoupon();
			$data['record_coupon']=$this->Recharge_Model->pancoupondetail();
			$data['accountid']=$_SESSION['accountid'];
			$data['orderid']=$this->Recharge_Model->couponbuyordeid();
			$data['tablerecord']=$this->Recharge_Model->couponhistorytab($_SESSION['accountid']);

			$queryx=$this->db->get_where("setcomission",array("accountid"=>$_SESSION['accountid']));

         	if($queryx->num_rows()>0)
         	{
         		$data['pack_select']=$this->Recharge_Model->packcomission($_SESSION['accountid']);
         	}

         	else
         	{
         		$data['pack_select']=0;
         	}		 

			


			$this->load->view('couponhistory',$data);
		}

		public function coupondisputeraise()
		{
			$orderid=$_POST['orderid'];
			$disputetype=$_POST['disputetype'];

			$data=array('orderid'=>$orderid,'disputetype'=>$disputetype);
			$this->Recharge_Model->coupondisputeraise($data);

			if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Dispute has been raised for order id <b># <em>".$orderid."</em></b>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}
		}

		public function walletblce()
		{
			if(empty($_SESSION['accountid']))
			{
				return "";
			}

			else
			{
				$this->db->select('*')
         			 ->from('apiwallet')
         			 ->where('accountid',$_SESSION['accountid']);
				$query = $this->db->get();
			
				$data= $query->row();

				return $data->balance;
			}

		}



		public function manageuticoupon()
		{
			$data['records']=$this->Recharge_Model->utipancouponrecords();
			$this->load->view('manageuticoupon',$data);
		}

		public function autocall()
		{
			
				//$str=file_get_contents('http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=EZYONE&channel=Trans&DCS=0&flashsms=0&number=8274801323&text=Hello&route=32');

			//return "Hello World";

			//$query = $this->db->query("SELECT * FROM aTable");

			$query = $this->db->query("SELECT * FROM utipancouponbuy ");

			foreach($query->result_array() as $row)
			{
			    $str = file_get_contents('http://partners.worthpaisa.com/api/pancard/request/status?token=kTjkpgkrjnnSCngST6gsghmzO6dqK0&txnid='.$row['txnid'].'');

				$json=json_decode($str,true);

				if($json['statuscode']=='TXN')
				{
					$data=array('txnid'=>$row['txnid'],'status'=>'1','statuscode'=>$json);
					$this->Recharge_Model->couponstatus($data);
				}

				elseif($json['statuscode']=='ERR')
				{
					$data=array('txnid'=>$row['txnid'],'status'=>'2','statuscode'=>$json);
					$this->Recharge_Model->couponstatus($data);
				}

				elseif ($json['statuscode']=='IWB')
				{
					$data=array('txnid'=>$row['txnid'],'status'=>'3','statuscode'=>$json);
					$this->Recharge_Model->couponstatus($data);
				}

			}


			
		}


		public function approvepsaagent()
		{
			$this->db->select('*')
         			 ->from('psatable')
         			 ->order_by("id", "DESC")
         			 ->where("status",1);
              
			$query = $this->db->get();
			$data['records']=$query->result();
			$this->load->view('approvepsaagent',$data);
		}

		public function passwordnew()
		{
			$query=$this->db->get_where("apiuser",array("accountid"=>$_SESSION['accountid']));
			$data['records']=$query->result();
			//$this->load->view('resetpassword.php',$data);
			$this->load->view('passwordnew',$data);
		}

		public function personalprofile()
		{
			$query=$this->db->get_where("member",array("accountid"=>$_SESSION['accountid']));
			$data['records']=$query->result();
			$this->load->view('personalprofile',$data);
		}

		public function personalprofileinst()
		{
			$accountid=$_POST['paccountid'];
			$mobile=$_POST['pmobile'];
			$fname=$_POST['pfname'];
			$lname=$_POST['plname'];
			$dob=$_POST['pdob'];
			$address=$_POST['ppermanentadd'];
			$city=$_POST['pcity'];
			$gender=$_POST['gender'];
			$state=$_POST['pstate'];
			$zipcode=$_POST['pzipcode'];
			$email=$_POST['pemail'];
			$adharno=$_POST['padhar'];
			$panno=$_POST['ppan'];
			$profilestatus='personal';
			$data=array('accountid'=>$accountid,'phone'=>$mobile,'fname'=>$fname,'lname'=>$lname,'dob'=>$dob,
				'paddress'=>$address,'city'=>$city,'gender'=>$gender,'state'=>$state,'zipcode'=>$zipcode,'emailid'=>$email,'adharno'=>$adharno,'panno'=>$panno);


		     			$datax=array('accountid'=>$accountid,'profilestatus'=>$profilestatus,'email'=>$email);
						$this->Recharge_Model->personalprofileinst($data);
						$this->Recharge_Model->updateapiuser($datax);

							if (true)
							 {
								echo "success";
							 }

							else
							{
								echo "fail";
							}


		     		


			


		}

		public function corporateprofileinst()
		{
			$accountid=$_POST['caccountid'];
			$mobile=$_POST['cmobile'];
			$fname=$_POST['cfname'];
			$lname=$_POST['clname'];
			$dob=$_POST['cdob'];
			$email=$_POST['cemail'];
			$paddress=$_POST['cpermanentadd'];
			$city=$_POST['ccity'];
			$state=$_POST['cstate'];
			$zipcodes=$_POST['czipcodex'];
			$cmpname=$_POST['companyname'];
			$cmptype=$_POST['ctype'];
			$ncompany=$_POST['ncompany'];
			$billaddress=$_POST['billaddress'];
			$billstate=$_POST['billstate'];
			$gstinid=$_POST['gstinid'];
			$gstdt=$_POST['gstdt'];
			$cpanno=$_POST['cpanno'];
			$profilestatus='corporate';

			$data=array('accountid'=>$accountid,'phone'=>$mobile,'fname'=>$fname,
			'lname'=>$lname,'dob'=>$dob,'emailid'=>$email,'paddress'=>$paddress,
			'city'=>$city,'state'=>$state,'zipcodex'=>$zipcodes,'cmpname'=>$cmpname,
			'cmptype'=>$cmptype,'cmpnat'=>$ncompany,'baddress'=>$billaddress,
			'bstate'=>$billstate,'gstinid'=>$gstinid,'gstdt'=>$gstdt,'cpanno'=>$cpanno);

			$datae=array('phone'=>$mobile,'fname'=>$fname,
			'dob'=>$dob,'emailid'=>$email,'paddress'=>$paddress,
			'city'=>$city,'state'=>$state,'zipcodex'=>$zipcodes,'cmpname'=>$cmpname,
			'cmptype'=>$cmptype,'cmpnat'=>$ncompany,'baddress'=>$billaddress,
			'bstate'=>$billstate,'gstinid'=>$gstinid,'gstdt'=>$gstdt,'cpanno'=>$cpanno);




			$query_phone=$this->db->get_where("corporateprofile",array('phone'=>$mobile));
			//$ret=$query->row();	
			$query_email=$this->db->get_where("corporateprofile",array('emailid'=>$email));	
			$query_pan=$this->db->get_where("corporateprofile",array('cpanno'=>$cpanno));
			$query_adhar=$this->db->get_where("corporateprofile",array('gstinid'=>$gstinid));



 					if($query_phone->num_rows()>0)
		     			{

		     				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Mobile Number Exists.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
		     			}

		     		elseif($query_email->num_rows()>0)
		     		{
		     			echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Email Id Exists.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
		     		}	

		     		elseif($query_pan->num_rows()>0)
		     		{
		     			echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;PAN Number Exists.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
		     		}

		     		elseif($query_adhar->num_rows()>0)
		     		{
		     			echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Adhar Number Exists.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
		     		}

		     		else
		     		{

		     			//$this->Recharge_Model->corporateprofileinst($data);
		     			$this->Recharge_Model->corporateprofileupdatep($datae,$accountid);
			//$datax=array('accountid'=>$accountid,'profilestatus'=>$profilestatus,'email'=>$email);
			//$this->Recharge_Model->updateapiuser($datax);


			if (true)
			 {
				echo "success";
			 }

			else
			{
				echo "fail";
			}

		     		}


			

		}


		public function validatemobile()
		{
			$this->load->view('validatemobile');
		}



		public function otpgenerateuserd()
			{

				//$this->load->model('Recharge_Model');
				$data = array('email' =>$this->input->post('email'));
	

				$x1=rand(1000,9999);
			 	$x2=rand(1000,$x1);
			 	$x3=rand($x2,9999);
			 	$otp=rand($x2,$x3);
			 	$timex=time();
			 	$status=0;
			 	$_SESSION['mobile_no']=$data['email'];
			 	$user = '0eGkG5Ic5Ea50ArMMvBjIA';
				$senderid = 'WEBSMS';
				$channel = 'Trans';
				$DCS = '0';
				$flashsms = '0';
				$number = $_SESSION['mobile_no'];
				$message = urlencode('Dear User, Your Merchant Mobile Number Verification Code Is ');
				$route = '1';
			 	
			 	

			 	$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$status);

			 	//$ch=curl_init('http://sms.rechargehubs.com/api/mt/SendSMS?APIKEY='.$user.'&senderid='.$senderid.'&channel='.$channel.'&DCS='.$DCS.'&flashsms='.$flashsms.'&number=8274801323&text='.$message.'&route='.$route.'');
				//$data = curl_exec($ch);
				//print($data);

			 	http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile=6289145349&text=HI HOW ARE YOU&senderid=EZYONE&route_id=2&Unicode=0

			 	//http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=EZYONE&channel=Trans&DCS=0&flashsms=0&number='.$number.'&text='.$message.$otp.'&route=32
				
			 	$this->Recharge_Model->otpinsert($otpdata);

			 	$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$number.'&text='.$message.$otp.'&senderid=EZYONE&route_id=2&Unicode=0');

			 	//echo $str;
			 	
			 	//send_email('avijitpaul03021992@gmail.com',"please verify your mobile with the given OTP ".$otp." thank you","OTP Verification",'avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com');

			 	if(true)

			 	{
			 		echo "success";

			 	}

			 	else
			 	{
			 		echo "fail";
			 	}

			 	


			}


			public function otpvalidex()

			{
				$timex_otp='';
				$this->load->model('Recharge_Model');
				$data=array('otp'=>$this->input->post('otp'),'timex'=>$this->input->post('timex'));
				$query=$this->db->get_where("otptable",array("otp"=>$data['otp'] ));
				
				if($query->num_rows()>0)
				{

				foreach ($query->result() as $row)

				 {
					$timex_otp=$row->timex;

				}


				$otp_id= $data['otp'];

				if($data['timex']<=($timex_otp+60))

				{
					$status=1;
					$this->Recharge_Model->otpupdate($otp_id);
					$this->Recharge_Model->validatemobilestatus($_SESSION['accountid']);

					if (true)
					 {
					 	echo "success";
						//echo  $_SESSION['mobile_no'];
					}

					


				}


				if($data['timex']>($timex_otp+60))

				{
					echo "expired";
				}

				

			}

			else
			{
				echo 'invalid';
			}





			}


			public function personalprofileupdate()
			{
				$accountid=$_POST['paccountid'];
			$mobile=$_POST['pmobile'];
			$fname=$_POST['pfname'];
			$lname=$_POST['plname'];
			$dob=$_POST['pdob'];
			$address=$_POST['ppermanentadd'];
			$city=$_POST['pcity'];
			$gender=$_POST['gender'];
			$state=$_POST['pstate'];
			$zipcode=$_POST['pzipcode'];
			$email=$_POST['pemail'];
			$adharno=$_POST['padhar'];
			$panno=$_POST['ppan'];

			//$profilestatus='personal';
			$data=array('accountid'=>$accountid,'phone'=>$mobile,'fname'=>$fname,'lname'=>$lname,'dob'=>$dob,
				'paddress'=>$address,'city'=>$city,'gender'=>$gender,'state'=>$state,'zipcode'=>$zipcode,'emailid'=>$email,'adharno'=>$adharno,'panno'=>$panno,'profiletype'=>$_SESSION['usertype']);

			$this->Recharge_Model->personalprofileupdate($data);

				if(true)
				{
					echo "success";
				}
				else
				{
					echo "fail";
				}

			}



			public function corporateprofileedit()
			{
				$query=$this->db->get_where("corporateprofile",array("accountid"=>$_SESSION['accountid']));
				$data['records']=$query->result();
				$this->load->view('corporateprofileedit',$data);
			}



			public function corporateprofileupdate()
			{
				$accountid=$_POST['caccountid'];
			$mobile=$_POST['cmobile'];
			$fname=$_POST['cfname'];
			//$lname=$_POST['clname'];
			$dob=$_POST['cdob'];
			$email=$_POST['cemail'];
			$paddress=$_POST['cpermanentadd'];
			$city=$_POST['ccity'];
			$state=$_POST['cstate'];
			$zipcodes=$_POST['czipcodex'];
			$cmpname=$_POST['companyname'];
			$cmptype=$_POST['ctype'];
			$ncompany=$_POST['ncompany'];
			$billaddress=$_POST['billaddress'];
			$billstate=$_POST['billstate'];
			$gstinid=$_POST['gstinid'];
			$gstdt=$_POST['gstdt'];
			$cpanno=$_POST['cpanno'];
			$profilestatus='corporate';
			$_SESSION['phone']=$mobile;

			$data=array('accountid'=>$accountid,'phone'=>$mobile,'fname'=>$fname,
			'dob'=>$dob,'emailid'=>$email,'paddress'=>$paddress,'phone'=>$mobile,
			'city'=>$city,'state'=>$state,'zipcodex'=>$zipcodes,'cmpname'=>$cmpname,
			'cmptype'=>$cmptype,'cmpnat'=>$ncompany,'baddress'=>$billaddress,
			'bstate'=>$billstate,'gstinid'=>$gstinid,'gstdt'=>$gstdt,'cpanno'=>$cpanno,'profiletype'=>$_SESSION['usertype']);

			$this->Recharge_Model->corporateprofileupdate($data);

			if(true)
			{
				$this->Recharge_Model->profilestatus($_SESSION['accountid']);
				echo "success";
			} 

			else
			{
				echo "fail";
			}


			}

			public function adminprofileedit()
		{
			//$phone=$this->input->post('phone');
			//$_SESSION['phone']=$phone;
		
			$query=$this->db->get_where("apiuser",array("accountid"=>$_SESSION['accountid']));
			$data['records']=$query->result();
			$this->load->view('adminprofileedit',$data);
		}

		public function personalprofileupdatex()
		{

			$accountid=$_POST['paccountid'];
			$mobile=$_POST['pmobile'];
			$fname=$_POST['pfname'];
			$lname=$_POST['plname'];
			$dob=$_POST['pdob'];
			$address=$_POST['ppermanentadd'];
			$city=$_POST['pcity'];
			$gender=$_POST['gender'];
			$state=$_POST['pstate'];
			$zipcode=$_POST['pzipcode'];
			$email=$_POST['pemail'];
			$adharno=$_POST['padhar'];
			$panno=$_POST['ppan'];
			$cdate=$_POST['cdate'];
			$subscription=$_POST['subscription'];
			$statusx=$_POST['statusx'];
			if($subscription==0)
			{
				$rdate=$_POST['rdate'];
				$durationdata=array('accountid'=>$accountid,'cdate'=>$cdate,'rdate'=>$rdate,'duration'=>$subscription,'status'=>$statusx);
				$this->Recharge_Model->durationupdate($durationdata);
			}

			else
			{
				$rdate=date('d-m-Y', strtotime($subscription));
				$durationdata=array('accountid'=>$accountid,'cdate'=>$cdate,'rdate'=>$rdate,'duration'=>$subscription,'status'=>$statusx);
				$this->Recharge_Model->durationupdate($durationdata);
			}
			
			
			//$rewwdate=date('d-m-Y', strtotime($duration));
			//$profilestatus='personal';
			$data=array('accountid'=>$accountid,'phone'=>$mobile,'fname'=>$fname,'lname'=>$lname,'dob'=>$dob,
				'paddress'=>$address,'city'=>$city,'gender'=>$gender,'state'=>$state,'zipcode'=>$zipcode,'emailid'=>$email,'adharno'=>$adharno,'panno'=>$panno);

			$this->Recharge_Model->personalprofileupdate($data);




				if(true)
				{
					echo "success";
				}
				else
				{
					echo "fail";
				}

		}



		public function corporateprofileupdatex()
		{

			$accountid=$_POST['caccountid'];
			$mobile=$_POST['cmobile'];
			$fname=$_POST['cfname'];
			$lname=$_POST['clname'];
			$dob=$_POST['cdob'];
			$email=$_POST['cemail'];
			$paddress=$_POST['cpermanentadd'];
			$city=$_POST['ccity'];
			$state=$_POST['cstate'];
			$zipcodes=$_POST['czipcodex'];
			$cmpname=$_POST['companyname'];
			$cmptype=$_POST['ctype'];
			$ncompany=$_POST['ncompany'];
			$billaddress=$_POST['billaddress'];
			$billstate=$_POST['billstate'];
			$gstinid=$_POST['gstinid'];
			$gstdt=$_POST['gstdt'];
			$cpanno=$_POST['cpanno'];
			$profilestatus='corporate';
			$cdate=$_POST['cdate'];
			$subscription=$_POST['subscription'];
			$statusx=$_POST['statusx'];
			if($subscription==0)
			{
				$rdate=$_POST['rdate'];
				$durationdata=array('accountid'=>$accountid,'cdate'=>$cdate,'rdate'=>$rdate,'duration'=>$subscription,'status'=>$statusx);
				$this->Recharge_Model->durationupdate($durationdata);
			}

			else
			{
				$rdate=date('d-m-Y', strtotime($subscription));
				$durationdata=array('accountid'=>$accountid,'cdate'=>$cdate,'rdate'=>$rdate,'duration'=>$subscription,'status'=>$statusx);
				$this->Recharge_Model->durationupdate($durationdata);
			}

			$data=array('accountid'=>$accountid,'phone'=>$mobile,'fname'=>$fname,
			'lname'=>$lname,'dob'=>$dob,'emailid'=>$email,'paddress'=>$paddress,
			'city'=>$city,'state'=>$state,'zipcodex'=>$zipcodes,'cmpname'=>$cmpname,
			'cmptype'=>$cmptype,'cmpnat'=>$ncompany,'baddress'=>$billaddress,
			'bstate'=>$billstate,'gstinid'=>$gstinid,'gstdt'=>$gstdt,'cpanno'=>$cpanno


		);

			$this->Recharge_Model->corporateprofileupdate($data);

			if(true)
			{
				echo "success";
			} 

			else
			{
				echo "fail";
			}


		}


		public function registeruser()
		{
			$email=$_POST['emailreg'];
			$phone=$_POST['phonereg'];

				//$query=$this->db->get_where("apiuser",array("phone"=>$phone_));

				$this->db->select('*');
				$this->db->from('apiuser');
				$this->db->where('apiuser.phone', $phone);
				//$this->db->where('apiuser.email', $email);
				//$this->db->where('table.column3', $condition3);
				$query = $this->db->get();

				$query->result();
				if($query->num_rows()>0)

				{
					echo "duplicate";
				}

				$this->db->select('*');
				$this->db->from('apiuser');
				$this->db->where('apiuser.email', $email);
				$queryemail = $this->db->get();

				$queryemail->result();
				if($queryemail->num_rows()>0)
				{
					echo "duplicate";
				}

				elseif($queryemail->num_rows()<=0 && $query->num_rows()<=0)

				{	

					$x1=rand(1000,9999);
			 	$x2=rand(1000,$x1);
			 	$x3=rand($x2,9999);
			 	$otp=rand($x2,$x3);
			 	$timex=time();
			 	$status=0;
			 	$_SESSION['mobile_no']=$phone;
			 	$_SESSION['email']=$email;
			 	$user = '0eGkG5Ic5Ea50ArMMvBjIA';
				$senderid = 'WEBSMS';
				$channel = 'Trans';
				$DCS = '0';
				$flashsms = '0';
				$number = $_SESSION['mobile_no'];
				$emailid=$_SESSION['email'];
				$message = urlencode('Dear User, Your Merchant Mobile Number Verification Code Is ');
				$route = '1';
			 	
			 	

			 	$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$status);

			 	//$ch=curl_init('http://sms.rechargehubs.com/api/mt/SendSMS?APIKEY='.$user.'&senderid='.$senderid.'&channel='.$channel.'&DCS='.$DCS.'&flashsms='.$flashsms.'&number=8274801323&text='.$message.'&route='.$route.'');
				//$data = curl_exec($ch);
				//print($data);

				
			 	$this->Recharge_Model->otpinsert($otpdata);

			 	//$str=file_get_contents('http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=EZYONE&channel=Trans&DCS=0&flashsms=0&number='.$number.'&text='.$message.$otp.'&route=32');


			 	//$str=file_get_contents('http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=EZYONE&channel=Trans&DCS=0&flashsms=0&number='.$number.'&text='.$message.$otp.'&route=32');

			 	//echo $str;
			 	
			 	//send_email('avijitpaul03021992@gmail.com',"please verify your mobile with the given OTP ".$otp." thank you","OTP Verification",'avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com','avijitpaul03021992@gmail.com');

			 	if(true)

			 	{
			 		echo "success";

			 	}

			 	else
			 	{
			 		echo "fail";
			 	}


		}


	}

	public function otpvalidexc()

			{
				$timex_otp='';
				$this->load->model('Recharge_Model');
				$data=array('otp'=>$this->input->post('otp'),'timex'=>$this->input->post('timex'));
				$query=$this->db->get_where("otptable",array("otp"=>$data['otp'] ));
				
				if($query->num_rows()>0)
				{

				foreach ($query->result() as $row)

				 {
					$timex_otp=$row->timex;

				}


				$otp_id= $data['otp'];

				if($data['timex']<=($timex_otp+60))

				{
					$status=1;
					$this->Recharge_Model->otpupdate($otp_id);
					//$this->Recharge_Model->validatemobilestatus($_SESSION['accountid']);

					if (true)
					 {
					 	$x1=rand(10000000,99999999);
			 			$x2=rand(10000000,$x1);
			 			$x3=rand($x2,99999999);
					 	$usertype=4;
					 	$status=0;
					 	$phone=$_SESSION['mobile_no'];
					 	$emailid=$_SESSION['email'];
					 	$passwords=substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') , 0 , 6 );
						$accountid=rand($x1,$x2);
					 	$cdate=date('d-m-Y');
			//$rdate=date('d-m-Y', strtotime($duration));

			$message=urlencode('Please Login www.ezyone.in User ID: '.$phone.' Password: '.$passwords.' Please change your Password for sequrity reason. Thank you for EZYONE.');
			//$message1=urlencode(', Your password : ');


			$data=array(
				'email'=>$emailid,
				'pass'=>$passwords,
				'accountid'=>$accountid,
				'cdate'=>$cdate,
				//'rdate'=>$rdate,
				'phone'=>$phone,
				//'sname'=>$sname,
				//'pincode'=>$zipcode,
				//'pan'=>$pan,
				//'adhar'=>$adhar,
				//'state'=>$state,
				//'duration'=>$duration,
				'status'=>$status,
				'usertype'=>$usertype

				
				);
						$this->Recharge_Model->apiuser($data);
						$walletdata=array('accountid'=>$accountid,'balance'=>0);
						$this->Recharge_Model->apiwalletinst($walletdata);
			//$this->Recharge_Model->

					 	
						//echo  $_SESSION['mobile_no'];

						echo "success";
					}

					


				}


				

				

			}

				else
				{
					echo 'invalid';
				}





			}


			public function endwalletuser()
			{
				$this->load->view('user');
			}


			public function enduserprofileedit()
			{
				$query=$this->db->get_where("apiuser",array("accountid"=>$_SESSION['accountid']));
				$data['records']=$query->result();
				$this->load->view('enduserprofileedit',$data);
			}


			public function enderuserprofileupdate()

			{

			$accountid=$_POST['paccountid'];
			$mobile=$_POST['pmobile'];
			$fname=$_POST['pfname'];
			$lname=$_POST['plname'];
			$dob=$_POST['pdob'];
			$address=$_POST['ppermanentadd'];
			$city=$_POST['pcity'];
			//$gender=$_POST['gender'];
			$state=$_POST['pstate'];
			$zipcode=$_POST['pzipcode'];
			$email=$_POST['pemail'];
			$adharno=$_POST['padhar'];
			$panno=$_POST['ppan'];
			//$profilestatus='personal';
			$data=array('accountid'=>$accountid,'phone'=>$mobile,'fname'=>$fname,'lname'=>$lname,'birth'=>$dob,
				'address'=>$address,'city'=>$city,'state'=>$state,'pincode'=>$zipcode,'email'=>$email,'adhar'=>$adharno,'pan'=>$panno);

			$this->Recharge_Model->enderuserprofileupdate($data);

				if(true)
				{
					echo "success";
				}
				else
				{
					echo "fail";
				}

			}





			public function managesuppliers()
			{
				$data['records']=$this->Recharge_Model->pancoupondetail();
				$this->load->view('managesuppliers',$data);
			}



			public function utiplans()
			{
				$query=$this->db->get_where("schemepackages",array("status"=>1));
				$data['records']=$query->result();
				$data['recordsc']=$this->Recharge_Model->pancoupondetail();
				$this->load->view('utiplans',$data);
			}


			public function viewcoupon()
			{
				$txnid=$_POST['txnid'];
				$query=$this->db->get_where("utipancouponbuy",array("txnid"=>$txnid));
				$data['records']=$query->result();
				$this->load->view('viewcoupon',$data);

			}


			public function updatecoupon()
			{
				$txnid=$_POST['txnid'];
				$orderid=$_POST['orderid'];
				$statusx=$_POST['statusx'];
				$data=array('txnid'=>$txnid,'statusx'=>$statusx);

				$this->Recharge_Model->updatecoupon($data);

				if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}
			}


			public function AddMoney()
			{
				$datae=array('accountid'=>$_SESSION['accountid']);
				$data['records']=$this->Recharge_Model->walletevalue($datae);
				$this->load->view('AddMoney',$data);
			}


			public function instaddmoney()
			{
				$x1=rand(1000,9999);
			 	$x2=rand(1000,$x1);
			 	$x3=rand($x2,9999);
			 	$orderid=rand($x3,$x2);
			 	$amount=$_POST['amount'];
			 	$paydate=$_POST['paydate'];
			 	$bankname=$_POST['bankname'];
			 	$modepayment=$_POST['modepayment'];
			 	$refid=$_POST['refid'];
			 	$bankaccname=$_POST['bankaccname'];
			 	$accountid=$_SESSION['accountid'];

			 	$query=$this->db->get_where("wallettopup",array("refid"=>$refid ));
				
				if($query->num_rows()>0)
				{

					echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Reference ID Exists .
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";

				}

				else
				{
					//$orderidx=$query->row()->orderid;
					
					$query_update=$this->db->get_where("walletupdatesamt",array("refid"=>$refid,'creditamt'=>$amount));

					if($query_update->num_rows()>0)
						{
							$data_updatione=array("refid"=>$refid,'orderid'=>$orderid);
							$this->Recharge_Model->walletupdatesamtup($refid);
							$this->Recharge_Model->walletupdatesamtuporderid($data_updatione);

							$data=array('orderid'=>$orderid,'amount'=>$amount,'paydate'=>$paydate,'bankname'=>$bankname,'modepayment'=>$modepayment,
			 				'refid'=>$refid,'bankaccname'=>$bankaccname,'accountid'=>$accountid,'status'=>1);

							 	$this->Recharge_Model->instaddmoney($data);

							 	$userid=$_SESSION['accountid'];
										$apiwallet=$this->Recharge_Model->apiwallet($userid);

											if($apiwallet->num_rows()>0)
												{
													$balance=$apiwallet->row();
													$closingblc=($balance->balance)+$amount;
													$walletdata=array('accountid'=>$userid,'balance'=>$closingblc);
													$this->Recharge_Model->apiwalletupdate($walletdata);	
												}

											else
												{
													$walletdata=array('accountid'=>$userid,'balance'=>$amount);
													$this->Recharge_Model->apiwalletinst($walletdata);					

												}

								 	if(true)
										{
											$walletsummary=array('accountid'=>$userid,'amount'=>$amount,'transtype'=>'Wallet TopUp','transc'=>'Credit','oblnc'=>$balance->balance,'cblnc'=>$closingblc,'transid'=>$orderid);
											$this->walletsummary($walletsummary);
											echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
							                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
							                     <span aria-hidden='true'>×</span>
							                     </button>
							                </div>";
										}

								else
									{
										echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
						                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
						                     <span aria-hidden='true'>×</span>
						                     </button>
						                </div>";
									}
						}

						else
						{
							$query_update=$this->db->get_where("walletupdatesamt",array("refid"=>$refid));

							if($query_update->num_rows()>0)
								{
									echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Reference ID Exists. Please check amount entered
						                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
						                     <span aria-hidden='true'>×</span>
						                     </button>
						                </div>";
								}

								else
								{

									$data=array('orderid'=>$orderid,'amount'=>$amount,'paydate'=>$paydate,'bankname'=>$bankname,'modepayment'=>$modepayment,
			 				'refid'=>$refid,'bankaccname'=>$bankaccname,'accountid'=>$accountid	);

			 	$this->Recharge_Model->instaddmoney($data);


			 	$message = urlencode('Oder ID: '.$orderid.' With Rs. '.$amount.'/- Request By Account ID '.$accountid.'');
			 	$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile=9874050333&text='.$message.'&senderid=EZYONE&route_id=2&Unicode=0');	

				 	if(true)
						{
							$userid=$_SESSION['accountid'];
							$apiwallet=$this->Recharge_Model->apiwallet($userid);
							$balance=$apiwallet->row();
							$closingblc=($balance->balance)+$amount;
							//$walletsummary=array('accountid'=>$userid,'amount'=>$amount,'transtype'=>'Wallet TopUp','transc'=>'Credit','oblnc'=>$balance->balance,'cblnc'=>$closingblc,'transid'=>$orderid);
							//$this->walletsummary($walletsummary);

							echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

				else
					{
						echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
		                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
		                     <span aria-hidden='true'>×</span>
		                     </button>
		                </div>";
					}

								}
						}


				}

			 	
			}


			public function wallettopupupdate()
			{
				$orderid=$_POST['orderid'];
			 	$amount=$_POST['amount'];
			 	$paydate=$_POST['paydate'];
			 	$bankname=$_POST['bankname_txt'];
			 	$modepayment=$_POST['modepayment'];
			 	$refid=$_POST['refid'];
			 	$bankaccname=$_POST['bankaccname'];
			 	//$accountid=$_SESSION['accountid'];
			 	$data=array('orderid'=>$orderid,'amount'=>$amount,'paydate'=>$paydate,'bankname'=>$bankname,'modepayment'=>$modepayment,
			 				'refid'=>$refid,'bankaccname'=>$bankaccname);

			 	$this->Recharge_Model->wallettopupupdate($data);

			 	if(true)
			{
				echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}
			}

			public function walletupdates()
			{
				$data['records']=$this->Recharge_Model->walletrecord();
				$this->load->view('walletupdates',$data);
			}

			public function walletrecordinst()
			{
				$refid=$_POST['refid'];
				$narration=$_POST['narration'];
				$creditamt=$_POST['creditamt'];
				$date=date('d-M-Y H:i a');

				$data=array('narration'=>$narration,'refid'=>$refid,'creditamt'=>$creditamt,'datex'=>$date);

				$query=$this->db->get_where("wallettopup",array("refid"=>$refid,'amount'=>$creditamt));
				
				

				if($query->num_rows()<=0)
				{
					//$userid=$query->row()->accountid;
					
					$this->Recharge_Model->walletrecordinst($data);	
					//$this->Recharge_Model->updatemerchantwallet($refid);

					if(true)
						{
							//$message = urlencode('Dear Customer Your Request has been Approved With Rs.'.$creditamt.'/- Oder ID: '.$orderid.', Approved by EZYONE Billing Team');

							echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}
				}

				else
				{
					$orderid=$query->row()->orderid;
					$userid=$query->row()->accountid;
					$datae=array('narration'=>$narration,'orderid'=>$orderid,'refid'=>$refid,'creditamt'=>$creditamt,'datex'=>$date,'status'=>1);
					$this->Recharge_Model->walletrecordinst($datae);
					$this->Recharge_Model->updatemerchantwallet($refid);
					

					$apiwallet=$this->Recharge_Model->apiwallet($userid);
					
						if($apiwallet->num_rows()>0)
						{

							$balance=$apiwallet->row();
							$closingblc=($balance->balance)+$creditamt;
							$walletdata=array('accountid'=>$userid,'balance'=>$closingblc);
							$this->Recharge_Model->apiwalletupdate($walletdata);
							$walletsummary=array('accountid'=>$userid,'amount'=>$creditamt,'transtype'=>'Wallet TopUp','transc'=>'Credit','oblnc'=>$balance->balance,'cblnc'=>$closingblc,'transid'=>$orderid);
							$this->walletsummary($walletsummary);	
						}

						else
						{
								
							$walletdata=array('accountid'=>$userid,'balance'=>$creditamt);
							$this->Recharge_Model->apiwalletinst($walletdata);	

							$walletsummary=array('accountid'=>$userid,'amount'=>$creditamt,'transtype'=>'Wallet TopUp','transc'=>'Credit','oblnc'=>'0','cblnc'=>$creditamt,'transid'=>$orderid);
							$this->walletsummary($walletsummary);				

						}


					if(true)
						{


							$message = urlencode('Dear Customer Your Request has been Approved With Rs.'.$creditamt.'/- Oder ID: '.$orderid.', Approved by EZYONE Billing Team');

							$apirecord=$this->Recharge_Model->apiuserresult($userid);
							$apirecord_no=$apirecord->row();

							$phone=$apirecord_no->phone;

							$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$phone.'&text='.$message.'&senderid=EZYONE&route_id=2&Unicode=0');				


							echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}	
				}

			}


			public function AddMoneyreuest()
			{
				$data['records']=$this->Recharge_Model->walletevaluetotal();
				$this->load->view('AddMoneyreuest',$data);
			}


			public function allservices()
			{
				
				$data['records']=$this->Recharge_Model->allservices();
				$this->load->view('allservices',$data);
			}


			public function walletsummary($data)
			{
				$accountid=$data['accountid'];
				$datex=date('d M Y');
				$timex=date('H:i:s');
				$amount=$data['amount'];
				$transtype=$data['transtype'];
				$transid=$data['transid'];
				$transc=$data['transc'];
				$cblnc=$data['cblnc'];
				$oblnc=$data['oblnc'];
				$description=$data['description'];
				$mobile=$data['mobile'];
					$data=array('accountid'=>$accountid,'datex'=>$datex,'amount'=>$amount,'transtype'=>$transtype,'transid'=>$transid,'transc'=>$transc,'cblnc'=>$cblnc,'oblnc'=>$oblnc,'description'=>$description,'timex'=>$timex,'mobile'=>$mobile);


				$this->Recharge_Model->walletsummary($data);

			}

			public function Mywalletsummary()
			{
				$data['records']=$this->Recharge_Model->mywalletsummary($_SESSION['accountid']);
				$this->load->view('Mywalletsummary',$data);
			}


			public function merchantwalletsummary()
			{
				
				$accountid=$_POST['accountid'];
				$data['records']=$this->Recharge_Model->mywalletsummary($accountid);
				$this->load->view('merchantwalletsummary',$data);
			}

			public function checkcouponstatus()
			{
				$txnid=$_POST['txnid'];

				$str = file_get_contents('http://partners.worthpaisa.com/api/pancard/request/status?token=kTjkpgkrjnnSCngST6gsghmzO6dqK0&txnid='.$txnid.'');
				$json=json_decode($str,true);
				//$json['statuscode']="TXN";

				//echo $json['message'];

				if($json['statuscode']=="TXN")
				{
					$this->Recharge_Model->updatecouponstatus($txnid);

					if(true)
					{
						echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;".$json['message'].".
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
					}

					else
					{
						echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
					}

				}

				else
				{
					echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;".$json['message'].".
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
				}


			}

			function getRealIpAddr()
				{
					    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
					    {
					      $ip=$_SERVER['HTTP_CLIENT_IP'];
					    }
					    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
					    {
					      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
					    }
					    else
					    {
					      $ip=$_SERVER['REMOTE_ADDR'];
					    }
					    return $ip;
				}



				public function loginhistory()
				{
					$data['records']=$this->Recharge_Model->loginhistorydetails();
					$this->load->view('loginhistory',$data);
				}



				public function couponorderid()
				{
					$this->db->select('*')
         			 ->from('utipancouponbuy')
         			 //->where('accountid',$_SESSION['accountid'])
         			 ->order_by('id','DESC')
         			 ->limit(1);


         			$querycx = $this->db->get();
			
					$datanormf= $querycx->row();

					$orderidv=($datanormf->orderid)+1;

					return $orderidv;
				}



				public function utipsaagentregistery()
				{
					$name=$_GET['name'];
					$data['record']=$name;
					$this->load->view('utipsaagentregistery',$data);
				}



				public function servicestatus()
				{
					$data=$this->Recharge_Model->servicestatus($_SESSION['accountid']);

					$picdata=$data->row();

					$duration=date('Y-m-d', strtotime($picdata->datex.$picdata->duration));

					return $duration;

					



				}


				public function servicestatusupdate()
				{
					$data=$this->Recharge_Model->servicestatus($_SESSION['accountid']);

					$picdata=$data->row();

					$duration=date('Y-m-d', strtotime($picdata->datex.$picdata->duration));

					$date2=date('Y-m-d');

					$durationdate=strtotime($duration);

					$today=strtotime($date2);

					$orderid=$picdata->orderid;

					if($today>$durationdate)
					{
						$this->Recharge_Model->servicestatusupdate($orderid);
					}

				}



				public function myservices()
				{
					$accountid=$_POST['accountid'];
					$query_comission=$this->db->get_where("setcomission",array("accountid"=>$accountid));
					//$data['records']=$query->result();
					$data['recordc']=$query_comission->result();

					$this->load->view('myservices',$data);
				}


				public function mybilling()
				{
					$accountid=$_POST['accountid'];
					$query_comission=$this->Recharge_Model->mybilling($accountid);
					//$data['records']=$query->result();
					$data['records']=$query_comission->result();

					$this->load->view('mybilling',$data);
				}


				public function addnewsuppliers()
				{
					$this->load->view('addnewsuppliers');
				}

				public function newsupplierinst()
				{
					$x1=rand(10000,99999);
			 		$x2=rand(10000,$x1);
			 		$x3=rand($x2,99999);
			 		$suppid=rand($x2,$x3);
					$data=array('supplierid'=>$suppid,
							'vname'=>$_POST['vendorname'],
							'location'=>$_POST['location'],
							'contact'=>$_POST['contact'],
							'phone'=>$_POST['phone'],
							'gstin'=>$_POST['gstin'],
							'sales'=>$_POST['sales'],
							'datex'=>date('d-M-Y'),
							'mrp'=>$_POST['mrp'],
							'costprice'=>$_POST['cp'],
							'profit'=>$_POST['profit']);

					$this->Recharge_Model->newsupplierinst($data);
					if(true)
					{
						echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}	
				}


				public function suppliermanager()
				{
					$supplierid=$_POST['supplierid'];
					$query_comission=$this->Recharge_Model->suppliermanager($supplierid);
					$data['record']=$query_comission->result();
					$this->load->view('suppliermanager',$data);
				}

				public function updatesupplierinst()
				{

					$supplierid=$_POST['supplierid'];
							$data=array(
							'vname'=>$_POST['vendorname'],
							'location'=>$_POST['location'],
							'contact'=>$_POST['contact'],
							'phone'=>$_POST['phone'],
							'gstin'=>$_POST['gstin'],
							'sales'=>$_POST['sales'],
							'datex'=>date('d-M-Y'),
							'mrp'=>$_POST['mrp'],
							'costprice'=>$_POST['cp'],
							'profit'=>$_POST['profit']);

							$this->Recharge_Model->updatesupplierinst($data,$supplierid);

							if(true)
					{
						echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}
				}









						//-----------//------------------SOCIAL MEDIA-----------//-----------------------//





			public function createnewuser()
			{
				$x1=rand(10000000,99999999);
				$x2=rand(10000000,$x1);
			 	$x3=rand($x2,99999999);
			 	$accountid=rand($x3,$x2);

			 	$x1c=rand(1000,9999);
			 	$x2c=rand(1000,$x1c);
			 	$x3c=rand($x2c,9999);
			 	$otp=rand($x2c,$x3c);
			 	$timex=time();
			 	$statusc=0;

				$fname=$_POST['fname'];
				$lname=$_POST['lname'];
				$name=$fname." ".$lname;
				$email=$_POST['email']."@ezyone.in";
				$altemail=$_POST['altemail'];
				$mobile=$_POST['mobile'];
				$pass=$_POST['pass'];

				$_SESSION['mobile']=$mobile;
				$_SESSION['accountid']=$accountid;
				$_SESSION['fname']=$fname;
				$_SESSION['fullname']=$name;



				$query=$this->db->get_where("user",array('email'=>$email,'phone'=>$mobile));
				
				if($query->num_rows()>0)
				{
					echo "Account Already Exists";
				}

				else
				{
					$data=array('accountid'=>$accountid,'name'=>$name,'email'=>$email,
					'altemail'=>$altemail,'phone'=>$mobile,'datec'=>date('d-M-Y'),'pass'=>$pass);

					$this->Recharge_Model->userinst($data);
 
				
						if(true)
						{
							$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$statusc);
							$this->Recharge_Model->otpinsert($otpdata);

							if(true)
							{
								$message = urlencode('Your OTP is ');
					 			$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$mobile.'&text='.$message.$otp.'&senderid=EZYONE&route_id=2&Unicode=0');
								echo "success";
							}
							
						}

						else
						{
							echo "fail";
						}

				}



				
				
			}


			public function otpvaliduser()

			{
				$timex_otp='';
				$this->load->model('Recharge_Model');
				$data=array('otp'=>$this->input->post('otp'),'timex'=>$this->input->post('timex'));
				$query=$this->db->get_where("otptable",array("otp"=>$data['otp'] ));
				
				if($query->num_rows()>0)
				{

				foreach ($query->result() as $row)

				 {
					$timex_otp=$row->timex;

				}


				$otp_id= $data['otp'];

				if($data['timex']<=($timex_otp+60))

				{
					$status=1;
					$this->Recharge_Model->otpupdate($otp_id);

					if (true)
					 {
					 	$this->Recharge_Model->updateusermobile($_SESSION['accountid']);
					 	echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Mobile has been verified.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						//echo  $_SESSION['mobile_no'];
					}

					


				}


				if($data['timex']>($timex_otp+60))

				{
					echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;OTP Expired.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
				}

				

			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Invalid OTP.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
			}





			}


			public function homepage()
			{
				$this->load->view('homepage.php');
			}


			public function loginuservalidate()

				{
					$email=$_POST['email'];
					$password=$_POST['password'];

					if(is_numeric($email))
					{
						$query=$this->db->get_where("user",array('phone'=>$email,'pass'=>$password));
				
						if($query->num_rows()>0)
						{
							$datanorm= $query->row();

							$_SESSION['accountid']=$datanorm->accountid;
							$_SESSION['fullname']=$datanorm->name;

							$name=explode( " " , $_SESSION['fullname']);

							$_SESSION['fname']=$name[0];

							echo "success";
						}

						else
						{
							echo "Account Doesnot Exists";
						}
					}

					else
					{
						$query=$this->db->get_where("user",array('email'=>$email,'pass'=>$password));
				
						if($query->num_rows()>0)
						{
							$datanorm= $query->row();

							$_SESSION['accountid']=$datanorm->accountid;
							$_SESSION['fullname']=$datanorm->name;

							$name=explode( " " , $_SESSION['fullname']);

							$_SESSION['fname']=$name[0];

							echo "success";
						}

						else
						{
							echo "Account Doesnot Exists";
						}
					}


				}	


				public function services()
				{
					$this->load->view('servicesocial.php');
				}

				public function addpost()
				{
					$x1=rand(10000,99999);
					$x2=rand(10000,$x1);
			 		$x3=rand($x2,99999);
			 		$postid=rand($x3,$x2);

			 		$descriptionposte=$_POST['descriptpost'];

			 		$data=array('postid'=>$postid,'fullname'=>$_SESSION['fullname'],'accountid'=>$_SESSION['accountid'],'descriptonfc'=>$descriptionposte,'datex'=>date('d-M-Y'),'timex'=>date('h:i:s A'),
			 					);

			 		$this->Recharge_Model->userpost($data);

			 		if(true)
			 		{
			 			echo "success";
			 			$this->fetchuserpost();
			 		}

			 		else
			 		{
			 			echo "fail";
			 		}

				}


				public function fetchuserpost()
				{
					$datarecord=$this->Recharge_Model->fetchuserpost($_SESSION['accountid']);

					echo json_encode($datarecord);
						
				}

				public function fetchuserpostxx()
				{
					$datarecord=$this->Recharge_Model->fetchuserpostxx($_SESSION['accountid']);

					
					if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						$data=  json_decode(json_encode($datapost),true);			
						for($x = 0; $x < count($data); $x++) {
							    print_r("<div class='post-bar'>
											<div class='post_topbar'>
												<div class='usy-dt'>
													<img src='spanel/images/resources/avatar.png'  width='50'>
													<div class='usy-name'>
														<h3>".$_SESSION['fullname']."</h3>
														<span><img src='spanel/images/clock.png'>".$data[$x]['datex']." ".$data[$x]['timex']."</span>
													</div>
												</div>

												<div class='ed-opts'>
													<a href='#'  class='ed-opts-open'><i class='la la-ellipsis-v'></i></a>
													<ul class='ed-options'>
														<li><a href='#' title>Edit Post</a></li>
														<li><a href='#' title>Unsaved</a></li>
														<li><a href='#' title>Unbid</a></li>
														<li><a href='#' title>Close</a></li>
														<li><a href='#' title>Hide</a></li>
													</ul>
												</div>

												</div>

												<div class='job_descp'>
												<p>".$data[$x]['descriptonfc']."</p></div>
												</div>") ;
							    echo "<br>";
							}
					}

					else
					{
						echo "<div id='nopostee'>Start Posting....<img src='spanel/images/resources/post-it.png' width='30'></div>";
					}

					

				}


				public function profile()
				{
					$data['record']=$this->Recharge_Model->profiledetails($_SESSION['accountid']);
					$this->load->view('myprofile.php',$data);
				}


				public function updatecoverimg()
				{
					$target_dir = "./procover/";
					$accountid=$_POST['accountid'];
					$top=$_POST['top'];
					$fileinfo = @getimagesize($_FILES["input-image-hidden"]["tmp_name"]);
					$width = $fileinfo[0];
    				$height = $fileinfo[1];
    				$imgname=$_POST['imgname'];


    				if ($width < "1200" && $height < "1000" )
    				 {

    				 	echo "Please provide image with 1920 X 1080 demension.";
       
						}

					

				else
				{
					$id=rand(9999,1000);
							//$status=0;
							$media_basename=basename($id."_mezyone_".$_FILES["input-image-hidden"]["name"]);
							$target_file_media = $target_dir . $media_basename;
							move_uploaded_file($_FILES["input-image-hidden"]["tmp_name"], $target_file_media);

							$data=array('proimg'=>$media_basename,'procord'=>$top);

							$this->Recharge_Model->updatecoverimg($data,$accountid);
							

							if(true)
							{
								echo "Cover Picture uploaded successfully";
							}

							else
							{
								echo "Temporary error try again";
							}
				}
			
				}







		//-----------//------------------EZYWALLET-----------//-----------------------//




				public function addmember()
				{
					$x1=rand(10000000,99999999);
					$x2=rand(10000000,$x1);
				 	$x3=rand($x2,99999999);

				 	$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
				 	$otp=rand($x2c,$x3c);
				 	$timex=time();
				 	$statusc=0;

				 	$accountid=rand($x3,$x2);
					$fullname=$_POST['fullname'];
					$email=$_POST['email'];
					$phone=$_POST['mobile'];
					$dob=$_POST['dobreg'];
					$documentper=$_POST['govid'];
					$docid=$_POST['govidnum'];
					$pass=substr(str_shuffle('123456789') , 0 , 4 );
					



					$result=$this->Recharge_Model->checkmemberemail($email);

					if($result->num_rows()>0)
					{
						echo "Account Exists For Email";
					}


					else
					{
						$resulte=$this->Recharge_Model->checkmemberphone($phone);
						if($resulte->num_rows()>0)
							{
								echo "Account Exists For Phone";
							}

							else
							{
								$data=array('fullname'=>$fullname,'cdate'=>date('d-M-Y'),'ctime'=>date('H:m:s'),'accountid'=>$accountid,'usertype'=>'2','email'=>$email,'phone'=>$phone,'pass'=>$pass,'birth'=>$dob,'documentper'=>$documentper,'docid'=>$docid);

						$this->Recharge_Model->addmember($data);

						if(true)
						{
							
									$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$statusc);
								$this->Recharge_Model->otpinsert($otpdata);
								$message = urlencode('EZYONE One Time Password (OTP) is ');
								$messaged=urlencode(' Do not share it with anyone We do not call/email you to verify OTP  OTP is valid for 15mins');
								$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$phone.'&text='.$message.$otp.$messaged.'&senderid=EZYONE&route_id=2&Unicode=0');
							 			$_SESSION['phone']=$phone;
										$_SESSION['accountid']=$accountid;
										$_SESSION['fullname']=$fullname;

										echo "success";
					
							//echo "success";
						}
						else
						{
							session_destroy();
							echo "Fail";
						}
							}
					}
				}


				public function otpvalidmember()
					{
					$otp=$_POST['otpxc'];
					$timex_otp=time();
						$query=$this->db->get_where("otptable",array('otp'=>$otp));
				
						if($query->num_rows()>0)
						{
							$otpdata=$query->row();
							$datatime=$otpdata->timex;
							if($datatime<=($timex_otp+60))
							{
								$status=1;
								$this->Recharge_Model->otpupdate($otp);
								if(true)
								{
									echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Mobile has been verified.
					                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
					                     <span aria-hidden='true'>×</span>
					                     </button>
					                </div>";
								}
							}
							else
							{
								session_destroy();
								echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;OTP Expired.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
							}
						}
						else
						{
							session_destroy();
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;OTP not Valid.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>"	;
						}


					}

				public function otpvalidmemberx()
				{
					$otp=$_POST['otp'];
					if(empty($otp))
					{

					}
					else
					{

					}
					$timex_otp=time();
						$query=$this->db->get_where("otptable",array('otp'=>$otp));
				
						if($query->num_rows()>0)
						{
							$otpdata=$query->row();
							$datatime=$otpdata->timex;
							if($datatime<=($timex_otp+60))
							{
								$status=1;
								$this->Recharge_Model->otpupdate($otp);
								if(true)
								{
									echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Mobile has been verified.
					                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
					                     <span aria-hidden='true'>×</span>
					                     </button>
					                </div>";
								}
							}
							else
							{
								session_destroy();
								echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;OTP Expired.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
							}
						}
						else
						{
							session_destroy();
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;OTP not Valid.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>"	;
						}
				}

			public function loginmembervalidate()

				{
					$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
				 	$otp=rand($x2c,$x3c);
				 	$timex=time();
				 	$statusc=0;

						

					$email=$_POST['emailw'];
					$password=$_POST['passwordc'];

					if(is_numeric($email))
					{
						$query=$this->db->get_where("member",array('phone'=>$email,'pass'=>$password));
				
						if($query->num_rows()>0)
						{
							$datanorm= $query->row();
							if($datanorm->usertype==1)
							{
								$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$statusc);
								$this->Recharge_Model->otpinsert($otpdata);
								$message = urlencode('EZYONE One Time Password (OTP) is ');
								$messaged=urlencode(' Do not share it with anyone We do not call/email you to verify OTP  OTP is valid for 15mins');
								$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$email.'&text='.$message.$otp.$messaged.'&senderid=EZYONE&route_id=2&Unicode=0');
								if(true)
								{
									$_SESSION['accountid']=$datanorm->accountid;
									$_SESSION['fullname']=$datanorm->fullname;
									$_SESSION['usertype']=$datanorm->usertype;
									$_SESSION['mobile']=$datanorm->phone;
									$_SESSION['profilestatus']=$datanorm->profilestatus;
									$_SESSION['profiletype']=$datanorm->profiletype;
									echo $_SESSION['usertype'];
								}
								else
								{
									return "Fail";
								}
							}

							if($datanorm->usertype==11)
							{
								$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$statusc);
								$this->Recharge_Model->otpinsert($otpdata);
								$message = urlencode('EZYONE One Time Password (OTP) is ');
								$messaged=urlencode('  Do not share it with anyone We do not call/email you to verify OTP  OTP is valid for 15mins');
								$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$email.'&text='.$message.$otp.$messaged.'&senderid=EZYONE&route_id=2&Unicode=0');
								if(true)
								{
									$_SESSION['accountid']=$datanorm->accountid;
									$_SESSION['fullname']=$datanorm->fullname;
									$_SESSION['usertype']=$datanorm->usertype;
									$_SESSION['mobile']=$datanorm->phone;
									$_SESSION['profilestatus']=$datanorm->profilestatus;
									$_SESSION['profiletype']=$datanorm->profiletype;
									echo $_SESSION['usertype'];
								}
								else
								{
									return "Fail";
								}
							}

							if($datanorm->usertype==13 || $datanorm->usertype==12 || $datanorm->usertype==14 || $datanorm->usertype==15 || $datanorm->usertype==16)
							{
								if($datanorm->profiletype=='corporate' && $datanorm->profilestatus=='0')
								{
									$_SESSION['accountid']=$datanorm->accountid;
									echo "corporateform";
								}
								if($datanorm->profiletype=='corporate' && $datanorm->profilestatus=='1')
								{
									$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$statusc);
									$this->Recharge_Model->otpinsert($otpdata);
									$message = urlencode('EZYONE One Time Password (OTP) is ');
									$messaged=urlencode('  Do not share it with anyone We do not call/email you to verify OTP  OTP is valid for 15mins');
									$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$email.'&text='.$message.$otp.$messaged.'&senderid=EZYONE&route_id=2&Unicode=0');
									$_SESSION['accountid']=$datanorm->accountid;
									$_SESSION['fullname']=$datanorm->fullname;
									$_SESSION['usertype']=$datanorm->usertype;
									$_SESSION['mobile']=$datanorm->phone;
									$_SESSION['profilestatus']=$datanorm->profilestatus;
									$_SESSION['profiletype']=$datanorm->profiletype;
									echo "corporateprofile";
								}
							}

							if($datanorm->usertype==2)
							{
								$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$statusc);
								$this->Recharge_Model->otpinsert($otpdata);
								$message = urlencode('EZYONE One Time Password (OTP) is ');
								$messaged=urlencode('  Do not share it with anyone We do not call/email you to verify OTP  OTP is valid for 15mins');
								$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$email.'&text='.$message.$otp.$messaged.'&senderid=EZYONE&route_id=2&Unicode=0');
								if(true)
								{
									$_SESSION['accountid']=$datanorm->accountid;
									$_SESSION['fullname']=$datanorm->fullname;
									$_SESSION['usertype']=$datanorm->usertype;
									$_SESSION['mobile']=$datanorm->phone;
									$_SESSION['profilestatus']=$datanorm->profilestatus;
									$_SESSION['profiletype']=$datanorm->profiletype;
									echo $_SESSION['usertype'];
								}
								else
								{
									return "Fail";
								}
							}

							if($datanorm->usertype==4 || $datanorm->usertype==5 || $datanorm->usertype==6 || $datanorm->usertype==9 || $datanorm->usertype==7 || $datanorm->usertype==8  || $datanorm->usertype==10 || $datanorm->usertype==11)
							{
								$otpdata=array('otp'=>$otp,'timex'=>$timex,'status'=>$statusc);
								$this->Recharge_Model->otpinsert($otpdata);
								$message = urlencode('EZYONE One Time Password (OTP) is ');
								$messaged=urlencode('  Do not share it with anyone We do not call/email you to verify OTP  OTP is valid for 15mins ');
								$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$email.'&text='.$message.$otp.$messaged.'&senderid=EZYONE&route_id=2&Unicode=0');
								if(true)
								{
									$_SESSION['accountid']=$datanorm->accountid;
									$_SESSION['fullname']=$datanorm->fullname;
									$_SESSION['usertype']=$datanorm->usertype;
									$_SESSION['mobile']=$datanorm->phone;
									$_SESSION['profilestatus']=$datanorm->profilestatus;
									$_SESSION['profiletype']=$datanorm->profiletype;
									echo $_SESSION['usertype'];
								}
								else
								{
									return "Fail";
								}
							}
							
						}
						else
						{
							echo "Fail";
						}
					}

					else
					{
						$query=$this->db->get_where("member",array('email'=>$email,'pass'=>$password));
				
						if($query->num_rows()>0)
						{
							$datanorm= $query->row();

							$_SESSION['accountid']=$datanorm->accountid;
							$_SESSION['fullname']=$datanorm->fullname;
							$_SESSION['usertype']=$datanorm->usertype;


							//$name=explode( " " , $_SESSION['fullname']);

							//$_SESSION['fname']=$name[0];

							//echo "Creditials Verified";
							echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Creditials Verified
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Account Doesnot Exists.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";

						}
					}


				
				}	

				public function memberwallet()
				{

					$query=$this->db->get_where("apiwallet",array("accountid"=>$_SESSION['accountid']));
					$ret=$query->row();
					$balance=$ret->balance;
					return $balance;
				} 

				public function admindashboard()
				{
					$this->load->view('admindashboard');
				}

				public function managecustomer()
				{
					$data['records']=$this->Recharge_Model->usermember();
					$this->load->view('managecustomer',$data);
				}

				public function settings()
				{
					$data['records']=$this->Recharge_Model->bannerdetails();
					$this->load->view('settings',$data);
				}

				public function edituser()
				{
					$accountid=$_GET['accountid'];
					$data['records']=$this->Recharge_Model->edituser($accountid);
					$this->load->view('edituser',$data);
				}

				public function updateuser()
				{
					$accountid=$_POST['accountid'];
					$fullname=$_POST['fullname'];
					$email=$_POST['email'];
					$phone=$_POST['mobile'];
					$profilestatus=$_POST['acctstatus'];
					$mobilevstatus=$_POST['mobilevstatus'];
					$data=array('fullname'=>$fullname,'email'=>$email,'phone'=>$phone,
								 'profilestatus'=>$profilestatus,'validatemobile'=>$mobilevstatus);
					$this->Recharge_Model->updateuser($accountid,$data);

					if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}


				}

				public function uploadbanner()
				{
					$target_dir = "./probanner/";
					$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
					$id=rand($x3c,$x1c);
					$photo_basename=basename($id."_banner_".$_FILES["banner"]["name"]);
					$target_file_photo = $target_dir . $photo_basename;
					move_uploaded_file($_FILES["banner"]["tmp_name"], $target_file_photo);
					$data=array('img'=>$photo_basename,'datev'=>date('d-M-Y'));
					$this->Recharge_Model->uploadbanner($data);
					if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}
				}


				public function userprofile()
				{
					$accountid=$_GET['id'];
					$data['recordc']=$this->Recharge_Model->selectstate();
					$data['recordv']=$this->Recharge_Model->selectdist();
					$data['records']=$this->Recharge_Model->edituser($accountid);
					$data['recordmenu']=$this->Recharge_Model->groupmenu();
					$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
					$data['recordwallet']=$this->Recharge_Model->mywalletsummary($accountid);
					$this->load->view('memberprofile',$data);
				}

				public function adminprofile()
				{
					$accountid=$_GET['id'];
					$data['recordc']=$this->Recharge_Model->selectstate();
					$data['recordv']=$this->Recharge_Model->selectdist();
					$data['records']=$this->Recharge_Model->edituser($accountid);
					$this->load->view('adminprofile',$data);
				}


				public function statemanager()
				{
					$data['records']=$this->Recharge_Model->selectstate();
					$data['recordc']=$this->Recharge_Model->selectdist();
					$data['recordt']=$this->Recharge_Model->selectterri();
					$this->load->view('statemanager',$data);
				}

				public function addstate()
				{
					$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
				 	$state_id=rand($x2c,$x3c);
				 	$state_name=$_POST['state'];
				 	$data=array('state_id'=>$state_id,'state_name'=>$state_name,'datex'=>date('d-M-Y'));
				 	$this->Recharge_Model->addstate($data);
				 	if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}
				}

				public function adddistrict()
				{
					$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
				 	$district_id=rand($x2c,$x3c);
				 	$district_name=$_POST['district'];
				 	$state_dt=explode('/', $_POST['dist_state']);
				 	$state_id=$state_dt[0];
				 	$state_name=$state_dt[1];

				 	$data=array('district_id'=>$district_id,'district_name'=>$district_name,
				 				'state_name'=>$state_name,'state_id'=>$state_id,'datex'=>date('d-M-Y'));

				 	$this->Recharge_Model->adddistrict($data);

				 	if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}


				}


				public function addterritory()
				{
					$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
				 	$territory_id=rand($x2c,$x3c);
				 	$territory_name=$_POST['territory'];
				 	$dist_name=explode('/', $_POST['dist_name']);
				 	$dist_id=$dist_name[0];
				 	$distname=$dist_name[1];
				 	$pincode=$_POST['pincode'];
				 	$state_id=$_POST['dist_stid'];
				 	foreach( $territory_name as $key => $n ) 
						{
							$territory_namec=$territory_name[$key].','.$territory_namec;
						}


				 	$data=array('territory_id'=>$territory_id,'territory_name'=>$territory_namec,
				 				'district_name'=>$distname,'district_id'=>$dist_id,'datex'=>date('d-M-Y'),'pincode'=>$pincode,'state_id'=>$state_id);

				 	$this->Recharge_Model->addterritory($data);

				 	if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}


				}

				public function updateprofile()
				{
					$accountid=$_SESSION['accountid'];
					$fullname=$_POST['fullname'];
					$mobile=$_POST['mobile'];
					$datepicker=$_POST['datepicker'];
					$email=$_POST['email'];
					$mname=$_POST['mname'];
					$gender=$_POST['gender'];
					$address=$_POST['address'];
					$state=$_POST['state'];
					$dist=$_POST['dist'];
					$city=$_POST['city'];
					$pincode=$_POST['pincode'];
					$adhar=$_POST['adhar'];
					$pan=$_POST['pan'];
					$landmark=$_POST['landmark'];

					$data=array('fullname'=>$fullname,'mothername'=>$mname,'email'=>$email,'phone'=>$mobile,'birth'=>$datepicker,'gender'=>$gender,'address'=>$address,'pincode'=>$pincode,'dist'=>$dist,'state'=>$state,'city'=>$city,'landmark'=>$landmark,'pan'=>$pan,'adhar'=>$adhar);
					$this->Recharge_Model->updateprofile($data,$accountid);

					if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

				}


				public function recharge()
				{
					$data['record']=$this->Recharge_Model->vendordetails();
					$this->load->view('recharge',$data);
				}

				public function apisettings()
				{
					$data['records']=$this->Recharge_Model->groupdetails();
					$data['recordopt']=$this->Recharge_Model->operatordetails();
					$data['recordvent']=$this->Recharge_Model->vendordetails();
					$data['recordapi']=$this->Recharge_Model->apicodedetails();
					$this->load->view('apisettings',$data);
				}

				public function uploadgroup()
				{
					$groupname=$_POST['groupname'];
					$groupid=$_POST['groupid'];
					$nopt=$_POST['nopt'];
					$urlname=$_POST['urlname'];
					$target_dir = "./headericon/";
					$img_basename=basename($groupid."_icon_".$_FILES["hdicon"]["name"]);
					$target_file_img = $target_dir . $img_basename;
					move_uploaded_file($_FILES["hdicon"]["tmp_name"], $target_file_img);

					$data=array('groupname'=>$groupname,'groupid'=>$groupid,'nopt'=>$nopt,'url'=>$urlname,'icon'=>$img_basename);
					$this->Recharge_Model->group($data);
					if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

				}

				public function uploadopt()
				{
					$operatorname=$_POST['operatorname'];
					$groupnameemt=$_POST['groupnameemt'];
					$operatorid=$_POST['operatorid'];
					$minamt=$_POST['minamt'];
					$maxamt=$_POST['maxamt'];
					$noption=$_POST['noption'];
					
					$target_dir = "./operatorimg/";
					$img_basename=basename($operatorid."_optimg_".$_FILES["imageopt"]["name"]);
					$target_file_img = $target_dir . $img_basename;
					move_uploaded_file($_FILES["imageopt"]["tmp_name"], $target_file_img);
			
					$data=array('operator_id'=>$operatorid,'group_name'=>$groupnameemt,'operator_name'=>$operatorname,'min_amt'=>$minamt,'max_amt'=>$maxamt,'nopt'=>$noption,'operator_img'=>$img_basename);
					$this->Recharge_Model->uploadopt($data);
					if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

				}

				public function uploadvendor()
				{
					$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
				 	$vendor_id=rand($x2c,$x3c);
				 	$vendorname=$_POST['vendorname'];
				 	$mobile=$_POST['mobile'];
				 	$email=$_POST['email'];
				 	$loc=$_POST['loc'];
				 	$gst=$_POST['gst'];
				 	$datex=date('d-M-Y');
				 	$data=array('vendor_id'=>$vendor_id,'vendor_name'=>$vendorname,'mobile'=>$mobile,'email'=>$email,
				 					'location'=>$loc,'gstin'=>$gst,'datex'=>$datex);
				 	$this->Recharge_Model->uploadvendor($data);
				 	if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}
				}

			public function apicode()
			{
				$operatorname=$_GET['operatorname'];
				$operatorid=$_GET['operatorid'];
				$vendorname=$_GET['vendorname'];
				$groupname=$_GET['groupname'];
				$vendorapicode=$_GET['vendorapicode'];
				$margintype=$_GET['margintype'];
				$margin=$_GET['margin'];
				$apistatus=$_GET['apistatus'];

				//echo $operatorname.$operatorid.$vendorname.$vendorapicode.$margintype.$margin;

				$data=array('vendor_name'=>$vendorname,'operator_id'=>$operatorid,'operator_name'=>$operatorname,'vendor_optr_id'=>$vendorapicode,'margin_type'=>$margintype,'margin'=>$margin,'group_name'=>$groupname,'apistatus'=>$apistatus);

				$this->Recharge_Model->apicode($data);

				if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}


								
			}	

			public function groupcode()
			{
				$group_name=$_GET['code'];
				$datarecord=$this->Recharge_Model->groupcode($group_name);
				echo "<div id='resultgrouppdata'></div><div id='supernova' class='table table-striped table-bordered table-sm'>
						<div class='thead'>
							<div class='tr'>
								<div class='td'>SRL</div>
								<div class='td' style='width:110px'>Operator ID</div>
								<div class='td' >Operator Name</div>
								<div class='td' >API Code</div>
								<div class='td'>Margin Type</div>
								<div class='td'>Margin</div>
								<div class='td'>Action</div>

							</div>
						</div><div class='tbody'>";
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;			
						foreach($datapost as $datamorph)
						 {
						 	//echo $data[$x]['operator_id'];
						 	//echo $data[$x]['group_name'];
						 	//echo $data[$x]['operator_name'];

						 	echo "<form class='tr'>";
							echo "<div class='td'>$count <input type='text' name='vendor_name_code' id='vendor_name_code' style='display: none' ><input type='text' name='group_name_code' id='group_name_code' style='display: none' ></div>";
							echo "<div class='td'><input type='text' class='form-control' name='operator_id_apicode_$count' id='operator_id_apicode_$count' value='$datamorph->operator_id' disabled></div>";
							echo "<div class='td'><input type='text' class='form-control' name='operator_name_apicode_$count' id='operator_name_apicode_$count' value='$datamorph->operator_name' disabled></div>";
						 	echo "<div class='td'><td><input type='text' class='form-control' name='vendor_optr_id_apicode_$count' id='vendor_optr_id_apicode_$count' placeholder='Enter API Code'></div>";
							echo "<div class='td'><select class='form-control' name='margin_type_apicode_$count' id='margin_type_apicode_$count'>
						 		<option value='0'> Choose Option</option>
						 		<option value='percentage'> Percentage</option>
						 		<option value='cash'> Cash</option>

						 	</select></div>";
						 	echo "<div class='td'><input type='text' class='form-control' name='margin_apicode_$count' id='margin_apicode_$count' placeholder='Enter Margin' ></div>";
						 	echo "<div class='td'><button type='button'  class='btn btn-success btn-round btn-sm' onclick='edit_$count(this);'>Save</button></div>";
							echo "</form>";
						 	
						 	$count++;
						}

						
					}
					
					
			}


			public function vendormergecode()
			{
				$supplier_name=$_GET['code'];
				$groupcode=$_GET['groupcode'];
				$dataarray=array('supplier_name'=>$supplier_name,'groupcode'=>$groupcode);
				$datarecord=$this->Recharge_Model->groupcodedc($dataarray);						
				$datarecord_supp=$this->Recharge_Model->vendormergecode($dataarray);
				$operatornamearray = array();
				echo "<div id='resultgrouppdata'></div><div id='supernova' class='table table-striped table-bordered table-sm'>
	<div class='thead'>
		<div class='tr'>
			<div class='td'>SRL</div>
			<div class='td' style='width:110px'>Operator ID</div>
			<div class='td' >Operator Name</div>
			<div class='td' >API Code</div>
			<div class='td'>Margin Type</div>
			<div class='td'>Margin</div>
			<div class='td'>API Status</div>
			<div class='td'>Action</div>

		</div>
	</div><div class='tbody'>";
				if($datarecord_supp->num_rows()>0)
					{
						$datapost_supp=$datarecord_supp->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;			
						foreach($datapost_supp as $datamorph_supp)
						 {
						 	//echo $data[$x]['operator_id'];
						 	//echo $data[$x]['group_name'];
						 	//echo $data[$x]['operator_name'];

						 	echo "<form class='tr'>";
							echo "<div class='td'>$count <input type='text' name='vendor_name_code' id='vendor_name_code' style='display: none ' value='$supplier_name'><input type='text' name='group_name_code' id='group_name_code' style='display: none' value='$groupcode'></div>";
							echo "<div class='td'><input type='text' class='form-control' name='operator_id_apicode_$count' id='operator_id_apicode_$count' value='$datamorph_supp->operator_id' disabled></div>";
							echo "<div class='td'><input type='text' class='form-control' name='operator_name_apicode_$count' id='operator_name_apicode_$count' value='$datamorph_supp->operator_name' disabled></div>";
						 	echo "<div class='td'><td><input type='text' class='form-control' name='vendor_optr_id_apicode_$count' id='vendor_optr_id_apicode_$count' placeholder='Enter API Code' value='$datamorph_supp->vendor_optr_id'></div>";
							echo "<div class='td'><select class='form-control' name='margin_type_apicode_$count' id='margin_type_apicode_$count'>
						 		<option value='0'> Choose Option</option>
						 		<option value='percentage'> Percentage</option>
						 		<option value='cash'> Cash</option>

						 	</select></div>";
						 	echo "<div class='td'><input type='text' class='form-control' name='margin_apicode_$count' id='margin_apicode_$count' placeholder='Enter Margin' value='$datamorph_supp->margin'></div>";
						 	echo "<div class='td'><input type='checkbox' class='form-control' name='apistatus_apicode_$count' id='apistatus_apicode_$count'  value='1'></div>";
						 	echo "<div class='td'><button type='button'  class='btn btn-success btn-round btn-sm' onclick='edit_$count(this);'>Save</button></div>";
							echo "</form>";
						 	array_push($operatornamearray, $datamorph_supp->operator_name);
							//$operatorname_array+=$datamorph_supp->operator_name.',';
						 	//$this->otheroptionpt($datamorph_supp->operator_name,$count,$groupcode,$supplier_name);
						 	$count++;

						}
						//$operatorname_op='AirTel Digital Tv,Videocon D2H';
						$this->otheroptionpt($operatornamearray,$count,$groupcode,$supplier_name);
					}

					else
					{
						$datarecord=$this->Recharge_Model->groupcode($groupcode);
						if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;			
						foreach($datapost as $datamorph)
						 {
						 	//echo $data[$x]['operator_id'];
						 	//echo $data[$x]['group_name'];
						 	//echo $data[$x]['operator_name'];

						 	echo "<form class='tr'>";
							echo "<div class='td'>$count <input type='text' name='vendor_name_code' id='vendor_name_code' style='display: none' value='$supplier_name'><input type='text' name='group_name_code' id='group_name_code' style='display: none' value='$groupcode'></div>";
							echo "<div class='td'><input type='text' class='form-control' name='operator_id_apicode_$count' id='operator_id_apicode_$count' value='$datamorph->operator_id' disabled></div>";
							echo "<div class='td'><input type='text' class='form-control' name='operator_name_apicode_$count' id='operator_name_apicode_$count' value='$datamorph->operator_name' disabled></div>";
						 	echo "<div class='td'><td><input type='text' class='form-control' name='vendor_optr_id_apicode_$count' id='vendor_optr_id_apicode_$count' placeholder='Enter API Code'></div>";
							echo "<div class='td'><select class='form-control' name='margin_type_apicode_$count' id='margin_type_apicode_$count'>
						 		<option value='0'> Choose Option</option>
						 		<option value='percentage'> Percentage</option>
						 		<option value='cash'> Cash</option>

						 	</select></div>";
						 	echo "<div class='td'><input type='text' class='form-control' name='margin_apicode_$count' id='margin_apicode_$count' placeholder='Enter Margin' ></div>";
						 	echo "<div class='td'><input type='checkbox' class='form-control' name='apistatus_apicode_$count' id='apistatus_apicode_$count'  value='1'></div>";
						 	echo "<div class='td'><button type='button'  class='btn btn-success btn-round btn-sm' onclick='edit_$count(this);'>Save</button></div>";
							echo "</form>";
						 	
						 	$count++;
						}

						
					}
					}

						

				
			}

			public function otheroptionpt($operator,$count,$group,$supplier_name)
			{
				$operator_name=$operator;
				$count_srl=$count;
				$group_name=$group;
				$supplier_name=$supplier_name;
				$dataarray=array('operator_name'=>$operator_name,'group_name'=>$group_name);
				$datarecord=$this->Recharge_Model->FilterbyGroup($dataarray);

				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=$count_srl;			
						foreach($datapost as $datamorph)
						 {
						 	//echo $data[$x]['operator_id'];
						 	//echo $data[$x]['group_name'];
						 	//echo $data[$x]['operator_name'];

						 	echo "<form class='tr'>";
							echo "<div class='td'>$count <input type='text' name='vendor_name_code' id='vendor_name_code' style='display:none ' value='$supplier_name'><input type='text' name='group_name_code' id='group_name_code' style='display:none' value='$group_name'></div>";
							echo "<div class='td'><input type='text' class='form-control' name='operator_id_apicode_$count' id='operator_id_apicode_$count' value='$datamorph->operator_id' disabled></div>";
							echo "<div class='td'><input type='text' class='form-control' name='operator_name_apicode_$count' id='operator_name_apicode_$count' value='$datamorph->operator_name' disabled></div>";
						 	echo "<div class='td'><td><input type='text' class='form-control' name='vendor_optr_id_apicode_$count' id='vendor_optr_id_apicode_$count' placeholder='Enter API Code'></div>";
							echo "<div class='td'><select class='form-control' name='margin_type_apicode_$count' id='margin_type_apicode_$count'>
						 		<option value='0'> Choose Option</option>
						 		<option value='percentage'> Percentage</option>
						 		<option value='cash'> Cash</option>

						 	</select></div>";
						 	echo "<div class='td'><input type='text' class='form-control' name='margin_apicode_$count' id='margin_apicode_$count' placeholder='Enter Margin' ></div>";
						 	echo "<div class='td'><input type='checkbox' class='form-control' name='apistatus_apicode_$count' id='apistatus_apicode_$count'  value='1'></div>";
						 	echo "<div class='td'><button type='button'  class='btn btn-success btn-round btn-sm' onclick='edit_$count(this);'>Save</button></div>";
							echo "</form>";
						 	
						 	++$count;
						}

						
					}	

			}


			public function groupcodeapiswitch()
			{
				$groupname=$_GET['code'];
				$datarecord=$this->Recharge_Model->groupcodeapiswitch($groupname);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;			
						 foreach ($datapost as $key ) 
                      {
                         echo"<tr>";
                         echo "<td>$count</td>";
                         echo "<td>$key->operator_id</td>";
                         echo "<td>$key->operator_name</td>";
                        if($key->status==0)
                        {
                          echo "<td align='center'><span class='label label-danger'>Inactive</span></td>";
                        }

                        elseif($key->status==1)
                        {
                        echo "<td align='center' ><span class='label label-success'>Active</span></td>";
                      }
                         echo "<td>$key->margin</td>";
                         echo "<td align='center'><button class='btn btn-info btn-sm' style='padding: 4px;font-size: 12px;width: 100px;' data-toggle='modal' data-target='#apiswitch_$key->id'>change</button></td>";
                         echo"</tr>";
                         $count++;
                      }
					}

			}


			public function apicodestatusupdate()
			{
				$apicodeid=$_GET['id'];
				$apicodestatus=$_GET['status'];

				//$data=array('apicodeid'=>$apicodeid,'apicodestatus'=>$apicodestatus);
				$this->Recharge_Model->apicodestatusupdate($apicodeid,$apicodestatus);

				if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

			}


			public function updateopt()
			{
					$operatorid=$_POST['editoperatorid'];
					$groupname=$_POST['editgroupnameemt'];
					$operator_name=$_POST['editoperatorname'];
					$min_amt=$_POST['editminamt'];
					$max_amt=$_POST['editmaxamt'];
					$editnoption=$_POST['editnoption'];
					$editselectnoption=$_POST['editselectnoption'];
					$editidrow=$_POST['editidrow'];

					$target_dir = "./operatorimg/";

					if(empty($_FILES["editimageopt"]["name"]))
					{
				
						$data=array('operator_id'=>$operatorid,'group_name'=>$groupname,'operator_name'=>$operator_name,'min_amt'=>$min_amt,'max_amt'=>$max_amt,'nopt'=>$editnoption,'selectopt'=>$editselectnoption);
						$this->Recharge_Model->updateopt($data,$editidrow);
						if(true)
						{
							echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}

							else
							{
								echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}
					}

					else
					{
						$img_basename=basename($operatorid."_editoptimg_".$_FILES["editimageopt"]["name"]);
						$target_file_img = $target_dir . $img_basename;
						move_uploaded_file($_FILES["editimageopt"]["tmp_name"], $target_file_img);

						$data=array('operator_img'=>$img_basename);

						
						$this->Recharge_Model->updateopt($data,$editidrow);
						if(true)
						{
							echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}

							else
							{
								echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}
					}

					

			}


			public function prepaidrecg()
			{

				 	if(empty($_SESSION['accountid']))
						{
							echo "INVSESSION";
							$_SESSION['mobileNumber']=$_POST['mobileNumber'];
							$_SESSION['operatorName']=$_POST['operatorName'];
							$_SESSION['amount']=$_POST['amount'];
							$_SESSION['circleCode']=$_POST['circleCode'];
							$_SESSION['ptg']=1;
							$walletblc=$this->walletblce();
							$datatxn=$this->Recharge_Model->rechargetb();
							$ret=$datatxn->row();
							if($datatxn->num_rows()<0)
							{
								$admNo = EA2018201900000;
								//$usertxn = ++$admNo;
							}

							else
							{
								$admNo=$ret->orderid;
								//$admNo = EA2018201900000;
								 $usertxn = ++$admNo;
								//$_SESSION['usertxn']=$usertxn;
								$_SESSION['usertxn']=$usertxn;
							}
							//$usertxn=($ret->txnid)+1;
							//$_SESSION['usertxn']=$usertxn;
						}
						else
						{

						$mobileNumber=$_POST['mobileNumber'];
						$operatorName=$_POST['operatorName'];
						$amount=$_POST['amount'];
						$circleCode=$_POST['circleCode'];
						$datatxn=$this->Recharge_Model->rechargetb();
						$ret=$datatxn->row();
						if($datatxn->num_rows()<0)
							{
								$usertxn = EA2018201900000;
								//$usertxn = ++$admNo;
							}

							else
							{
								 $admNo=$ret->orderid;
								//$admNo = EA2018201900000;
								 $usertxn = ++$admNo;
								 $_SESSION['usertxn']=$usertxn;
								//$_SESSION['usertxn']=$usertxn;
							}
						//$usertxn=($ret->txnid)+1;
						echo $mobileNumber.",".$operatorName.",".$amount.",".$circleCode.","."WALLETOPEN".",".$usertxn;
						}
				 	

				
				

			}

			public function prepaidrecgpop()
			{
				$mobileNumber=$_POST['mobileNumberpop'];
				$operatorName=$_POST['operatorNamepop'];
				$amount=$_POST['amountpop'];
				$circleCode=$_SESSION['circleCode'];
				$walletblc=$this->walletblce();
				if($walletblc<$amount)
				{
					echo "<div class='alert alert-solid alert-danger'  id='added'><i class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Recharge Fail. Insufficient Wallet Bal.<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span> </button></div>";
				}

				else
				{
				$vendor_name='Click-E-Charge';
				$dataopt=array('vendor_name'=>$vendor_name,'operator_name'=>$operatorName);
				$query=$this->db->get_where("apicode",array('vendor_name'=>$vendor_name,'operator_name'=>$operatorName));
				$ret=$query->row();

				$vendorcode=$ret->vendor_optr_id;
				$servicetype="MOBILE";
				$username='20034202';
				$password='ca1670b90c5a68f2b828';
				$datatxn=$this->Recharge_Model->rechargetb();
				$ret=$datatxn->row();
				$usertxn=($ret->txnid)+1;
				$str = file_get_contents('http://99-604-99-605.com/api/recharge.php?userid='.$username.'&key='.$password.'&type='.$servicetype.'&operator='.$vendorcode.'&number='.$mobileNumber.'&amount='.$amount.'&usertxn='.$usertxn.'');

				$status=explode(',', $str);
				
				$statustype=$status[0];
				$datamodel=array('txnid'=>$usertxn,'operatorname'=>$operatorName,'circlecode'=>$circleCode,'mobile'=>$mobileNumber,'amount'=>$amount,'accountid'=>$_SESSION['accountid'],'datex'=>date('d-M-Y'),'timex'=>date('H:m:s'),'apistatus'=>$str);
				$this->Recharge_Model->rechargetbdetails($datamodel);
				if($statustype=='FAILURE')
						{
							unset($_SESSION['ptg']);
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Recharge Fail. Try Again.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}

							elseif($statustype=='SUCCESS')
							{
								unset($_SESSION['ptg']);
								echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Recharge successful.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}

							else
							{
								unset($_SESSION['ptg']);
								echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Recharge Fail. Try Again.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}
				}
				
			}

			public function autofillprepaidbox()
			{
				$mobile=$_GET['mobile'];
				$str = file_get_contents('http://api.rechapi.com/mob_details.php?format=json&token=YcFzYBTBwE2FpLW2a7PutZYh1WjfBp&mobile='.$mobile.'');

				$json=json_decode($str,true);				
				echo $json['data']['service'].",".$json['data']['location'];
			}

			public function fetchplan()
			{
				$circle=$_GET['circle'];

				//echo $circle;
			}

			public function testapi()
			{
				$this->load->view('testapi');
			}

			public function rechargeprepaid()
			{
				$mobileNumber=$_POST['mobileNumberr'];
				$operatorName=$_POST['operatorNamer'];
				$amount=$_POST['amountr'];
				$circleCode=$_POST['circleCoder'];
				$walletblc=$this->walletblce();
				$apiwallet=$this->Recharge_Model->apiwallet($_SESSION['accountid']);
				if($walletblc<$amount)
				{
					$orderid=$_SESSION['usertxn'];
					$datamodel=array('orderid'=>$_SESSION['usertxn'],'optname'=>$operatorName,'circlecode'=>$circleCode,'mobile'=>$mobileNumber,'amount'=>$amount,'accountid'=>$_SESSION['accountid'],'datex'=>date('d-M-Y'),'timex'=>date('H:m:s'),'apistatus'=>'Null' );
					$this->Recharge_Model->rechargetbdetails($datamodel);
					$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$amount,'transtype'=>$operatorName." Prepaid",'transc'=>'Fail','oblnc'=>$walletblc,'cblnc'=>$walletblc,'transid'=>$orderid,'description'=>'Recharge fail due to insufficient wallet blc','mobile'=>$mobileNumber);
					$this->walletsummary($walletsummary);
					echo "<div class='alert alert-solid alert-danger' style='background: #dc3545!important;
  color: white!important;'  id='added'><i class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Recharge Fail. Insufficient Wallet Bal.<button type='button' class='close pull-right' data-dismiss='modal' onclick='unsetrst()'>&times;</button></div>";
				}

				else
				{
					$vendor_name='Click-E-Charge';
					$dataopt=array('vendor_name'=>$vendor_name,'operator_name'=>$operatorName);
					$query=$this->db->get_where("apicode",array('vendor_name'=>$vendor_name,'operator_name'=>$operatorName));
					$ret=$query->row();
					$vendorcode=$ret->vendor_optr_id;
					$servicetype="MOBILE";
					$username='20034202';
					$password='ca1670b90c5a68f2b828';
					$str = file_get_contents('http://99-604-99-605.com/api/recharge.php?userid='.$username.'&key='.$password.'&type='.$servicetype.'&operator='.$vendorcode.'&number='.$mobileNumber.'&amount='.$amount.'&usertxn='.$_SESSION['usertxn'].'');
					$status=explode(',', $str);
					$statustype=trim($status[0]);
					$apitransid=$status[1];
					$optref=$status[5];

					$datamodel=array('orderid'=>$_SESSION['usertxn'],'optname'=>$operatorName,'circlecode'=>$circleCode,'mobile'=>$mobileNumber,'amount'=>$amount,'accountid'=>$_SESSION['accountid'],'datex'=>date('d-M-Y'),'timex'=>date('H:m:s'),'apistatus'=>$str,'optref'=>$optref,'rctype'=>'Topup','suppname'=>$vendor_name,'apitransno'=>$apitransid,'status'=>$statustype );
					$this->Recharge_Model->rechargetbdetails($datamodel);

					if(strcmp($statustype,'FAILURE')==0)
					{
						
						$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$amount,'transtype'=>$operatorName." Prepaid",'transc'=>'Fail','oblnc'=>$walletblc,'cblnc'=>$walletblc,'transid'=>$_SESSION['usertxn'],'description'=>'Recharge Fail' ,'mobile'=>$mobileNumber);
					$this->walletsummary($walletsummary);											

						echo "<div class='modal-header' style='background: #dc3545!important;
  color: white!important;'><div class='row' style='width: 100%;'><div class='col-sm-10'><h4 class='modal-title'><i class='fa fa-times-circle'></i> Recharge Failure</h4></div><div class='col-sm-2'><button type='button' class='close pull-right' data-dismiss='modal' onclick='unsetrst()'>&times;</button></div></div></div>";
					}

					elseif(strcmp($statustype,'SUCCESS')==0)
					{

						if($apiwallet->num_rows()>0)
												{
													$balance=$apiwallet->row();
													$closingblc=($balance->balance)-$amount;
													$walletdata=array('accountid'=>$_SESSION['accountid'],'balance'=>$closingblc);
													$this->Recharge_Model->apiwalletupdate($walletdata);	
												}

											else
												{
													$walletdata=array('accountid'=>$_SESSION['accountid'],'balance'=>$amount);
													$this->Recharge_Model->apiwalletinst($walletdata);					

												}


						$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$amount,'transtype'=>$operatorName." Prepaid",'transc'=>'Debit','oblnc'=>$balance->balance,'cblnc'=>$closingblc,'transid'=>$_SESSION['usertxn'],'description'=>'Recharge Successful','mobile'=>$mobileNumber);
					$this->walletsummary($walletsummary);



						echo "<div class='modal-header' style='background: #28a745!important;
  color: white!important;'><div class='row' style='width: 100%;'><div class='col-sm-10'><h4 class='modal-title'><i class='fa fa-check-circle'></i> Recharge Successful</h4></div><div class='col-sm-2'><button type='button' class='close pull-right' data-dismiss='modal' onclick='unsetrst()'>&times;</button></div></div></div>";
					}

					elseif(strcmp($statustype,'ERROR')==0)
					{
						$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$amount,'transtype'=>$operatorName." Prepaid",'transc'=>'Fail','oblnc'=>$walletblc,'cblnc'=>$walletblc,'transid'=>$_SESSION['usertxn'],'description'=>'Recharge Fail','mobile'=>$mobileNumber);
					$this->walletsummary($walletsummary);
						echo "<div class='modal-header' style='background: #dc3545!important;
  color: white!important;'><div class='row' style='width: 100%;'><div class='col-sm-10'><h4 class='modal-title'><i class='fa fa-times-circle'></i> Recharge Fail</h4></div><div class='col-sm-2'><button type='button' class='close pull-right' data-dismiss='modal' onclick='unsetrst()'>&times;</button></div></div></div>";
					}
					
				}

			}


			function get_token($length)
				{
				    $token = '';
				    $codeAlphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
				    $codeAlphabet .= 'abcdefghijklmnopqrstuvwxyz';
				    $codeAlphabet .= '0123456789';
				    for ($i = 0; $i < $length; $i++) {
				        $token .= $codeAlphabet[crypto_rand_secure(0, strlen($codeAlphabet))];
				    }
				    return $token;
				}


			public function rechargeDTH()
			{
				$_SESSION['group_name']='DTH';
				$data['recordmenu']=$this->Recharge_Model->groupmenu();	
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordopt']=$this->Recharge_Model->operatordetailsdth();
				//$data['recordoptr']=$this->Recharge_Model->operatordetailspostpaid();
				$this->load->view('rechargeDTH',$data);
			}	


			public function rechargeLandline()
			{
				$_SESSION['group_name']='Landline';
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordopt']=$this->Recharge_Model->operatordetailslandline();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();	
				//$data['recordoptr']=$this->Recharge_Model->operatordetailspostpaid();
				$this->load->view('rechargeLandline',$data);
			}

			public function rechargeBroadband()
			{
				$_SESSION['group_name']='Broadband';
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordopt']=$this->Recharge_Model->operatordetailsBroadband();
				$this->load->view('rechargeBroadband',$data);
			}

			public function rechargeElectricity()
			{
				$_SESSION['group_name']='Electricity';
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordopt']=$this->Recharge_Model->operatordetailsElectricity();
				$this->load->view('rechargeElectricity',$data);
			}

			public function rechargeGAS()
			{
				$_SESSION['group_name']='GAS';
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordopt']=$this->Recharge_Model->operatordetailsGAS();
				$this->load->view('rechargeGAS',$data);
			}

			public function rechargeWater()
			{
				$_SESSION['group_name']='Water';
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordopt']=$this->Recharge_Model->operatordetailsWater();
				$this->load->view('rechargeWater',$data);
			}

			public function rechargeWIFI()
			{
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordopt']=$this->Recharge_Model->operatordetailsWIFI();
				$this->load->view('rechargeWIFI',$data);
			}

			public function LoanPayment()
			{
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordopt']=$this->Recharge_Model->operatordetailsEMI();
				$this->load->view('LoanPayment',$data);
			}

			public function EMIPayment()
			{
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordopt']=$this->Recharge_Model->operatordetailsEMI();
				$this->load->view('EMIPayment',$data);
			}

			public function MetroPayment()
			{
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordopt']=$this->Recharge_Model->operatordetailsMetro();
				$this->load->view('MetroPayment',$data);
			}

			public function FlightBook()
			{
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$this->load->view('FlightBook',$data);
			}

			public function Flightbookiframe()
			{
				$this->load->view('flightbookiframe');		
			}

			public function groupcodeprm()
			{
				$groupcode=$_GET['code'];
				$_SESSION['groupcodeprm']=$groupcode;
				$groupcodeprmsession=$_SESSION['groupcodeprm'];
				$datarecord=$this->Recharge_Model->operatordetailsprm($groupcode);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;
						echo "<select class='form-control' name='operatorcodeprm' id='operatorcodeprm' style='background:#ffb23f;color: white;border: 3px solid #e59703;'' onchange='choose_operatorprm(this.value)'>";
                  			echo "<option value='0'>Choose Operator</option>";
						 foreach ($datapost as $key ) 
                      {
                         echo "<option value='$key->operator_name'>$key->operator_name</option>";
                  	   }

                	echo "</select>";
                        
					  }
			}


			public function operatorcodeprm()
			{
				$operatorcode=$_GET['code'];
				$_SESSION['operatorcodeprm']=$operatorcode;
				$datarecord=$this->Recharge_Model->operatoroptionprm($operatorcode);
				//$datapost=$datarecord->result();
				$ret=$datarecord->row();
				$nooption=$ret->nopt;
				$selectoption=$ret->selectopt;
				$operatorcodeid=$ret->operator_id;
				$groupcodeprmname=$ret->group_name;
				$count=1;
				for($i=0;$i<$nooption;$i++)
				{
					echo"<div class='row' style='margin: 34px 49px 19px 7px;'>";
					echo "<input  type='hidden' name='operatorprmname' placeholder='Operator Name' id='operatorprmname' value='$operatorcode' >";
					echo "<input type='hidden' name='groupcodeprmname' placeholder='Group Name' id='groupcodeprmname' value='$groupcodeprmname' >";
					echo "<input type='hidden' name='operatorprmid' placeholder='Operator ID'  id='operatorprmid' value='$operatorcodeid' >";
					echo "<div class='col-sm-2'><input type='text' class='form-control' name='inputfieldsid[]' placeholder='Input Field ID' id='inputfieldsid' ></div>";
					echo "<div class='col-sm-2'><input class='form-control' type='text' name='inputfieldsname[]' placeholder='Input Field Name' id='inputfieldsname' ></div>";
					echo "<div class='col-sm-2'><input class='form-control' type='text' name='inputfieldslen[]' placeholder='Input Field Length' id='inputfieldslen' ></div>";
					echo "<div class='col-sm-2'><input class='form-control' type='text' name='selectoptionname[]' placeholder='Input Option Name' id='selectoptionname' ></div>";
					echo "<div class='col-sm-2'><input class='form-control' type='text' name='selectoptionvalue[]' placeholder='Input Option Value' id='selectoptionvalue' ></div>";
					echo "<div class='col-sm-1' style='padding: 1px;text-align: center;'><input class='form-control' type='checkbox' name='operatorstatus[]'  id='operatorstatus[]' value='1'>Status</div>";
					//echo "<input type='text' name='inputfieldsid[]' placeholder='Input Field ID' id='inputfieldsid' >";
					//echo "<input type='text' name='inputfieldsname[]' placeholder='Input Field Name' id='inputfieldsname' >";
					//echo "<input type='checkbox' name='operatorstatus[]'  id='operatorstatus[]' value='1'> Status";

					echo "</div>";
					
					
				}

				

				echo "<input style='margin: 12px 0px 3px 24px;'  type='submit' name='submit' class='btn btn-primary btn-sm' id='submit' value='Upload'>";
				

			}

			public function operatorprmset()
			{
				$inputfieldsid=$_POST['inputfieldsid'];
				$operatorprmname=$_POST['operatorprmname'];
				$groupcodeprmname=$_POST['groupcodeprmname'];
				$operatorprmid=$_POST['operatorprmid'];
				$inputfieldsname=$_POST['inputfieldsname'];
				$operatorstatus=$_POST['operatorstatus'];
				$inputfieldslen=$_POST['inputfieldslen'];
				$selectoptionname=$_POST['selectoptionname'];
				$selectoptionvalue=$_POST['selectoptionvalue'];
				//$apistatus=$_POST['apistatus'];
				foreach( $inputfieldsid as $key => $n ) 
				{
				  
					$data=array('inputfieldsid'=>$inputfieldsid[$key],'inputfieldsname'=>$inputfieldsname[$key],'groupname'=>$groupcodeprmname,'optid'=>$operatorprmid,'operatorname'=>$operatorprmname,'status'=>$operatorstatus[$key],'fieldlength'=>$inputfieldslen[$key],'selectoptname'=>$selectoptionname[$key],'selectoptvalue'=>$selectoptionvalue[$key]);						
					$this->Recharge_Model->operatorprmset($data);
				}
				
			}

			public function operatorparameterfieldset()
			{
				$operatorName=$_GET['code'];
				$groupname=$_SESSION['group_name'];
				$data=array('groupname'=>$groupname,'operatorname'=>$operatorName);
				$datarecord=$this->Recharge_Model->operatorparameterfieldset($data);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;
						 foreach ($datapost as $key ) 
                      {
                      		if($key->inputfieldsid=='amount')
                      		{
                      			echo "<div class='form-group input-group'>";
                      			echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-inr'></i></span></div>";
                         		echo "<input type='text' class='form-control' data-bv-field='number' name='$key->inputfieldsid' id='$key->inputfieldsid' required placeholder='Enter $key->inputfieldsname'>";
                         		echo "</div>";
                      		}

                      		else
                      		{
                      			if(!empty($key->selectoptname))
                      			{
                      				echo "<div class='form-group'>";
                      				$arr=$key->selectoptname;
                      				$arr_value=$key->selectoptvalue;
									$selectname=explode(",",$arr);
									$selectvalue=explode(",",$arr_value);
									$count=0;
									echo "<select class='form-control'>" ;
									echo"<option value='0'> Choose ".$key->inputfieldsname."</option>";	
										foreach($selectname as $var)
										{
										 echo"<option value='$selectvalue[$count]'>".$var."</option>";
										 $count++;
										}  
									echo "</select>";	      		
	                         		echo "</div>";
                      			}
                      			else
                      			{
                      				echo "<div class='form-group'>";
	                         		echo "<input type='text' class='form-control' data-bv-field='number' name='$key->inputfieldsid' id='$key->inputfieldsid' required placeholder='Enter $key->inputfieldsname' maxlength='$key->fieldlength'>";
	                         		echo "</div>";
                      			}
                      		}
                  	  }

					  }
			}


			public function edituploadgroup()
			{
					$groupname=$_POST['editgroupname'];
					$groupid=$_POST['editgroupid'];
					$nopt=$_POST['editnopt'];
					$urlname=$_POST['editurlname'];
					$editstid=$_POST['editstid'];
					$target_dir = "./headericon/";
					if(empty($_FILES["edithdicon"]["name"]))
					{
					  $img_basename=$_POST['edithdiconname'];
					  $data=array('groupname'=>$groupname,'groupid'=>$groupid,'nopt'=>$nopt,'url'=>$urlname,'icon'=>$img_basename);
					  $this->Recharge_Model->editgroup($data,$editstid);
					  if(true)
						{
							echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}

							else
							{
								echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}
					}
					else
					{
					   $img_basename=basename($groupid."_icon_".$_FILES["edithdicon"]["name"]);
					   $target_file_img = $target_dir . $img_basename;
					   move_uploaded_file($_FILES["edithdicon"]["tmp_name"], $target_file_img);
					   $data=array('groupname'=>$groupname,'groupid'=>$groupid,'nopt'=>$nopt,'url'=>$urlname,'icon'=>$img_basename);
					   $this->Recharge_Model->editgroup($data,$editstid);
					   if(true)
						{
							echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}

							else
							{
								echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}
					}
					//$target_file_img = $target_dir . $img_basename;
					//move_uploaded_file($_FILES["edithdicon"]["tmp_name"], $target_file_img);
					//echo $edithdiconname;
					
			}

			public function groupmenu()
			{
				
				$this->load->view('groupmenu',$data);
			}


			public function billviewallops()
			{
				$operatorName=$_POST['operatorName'];
				$query=$this->db->get_where("apicode",array('vendor_name'=>'Mobikwik','operator_name'=>$operatorName));
				$ret=$query->row();
				$vendorcode=$ret->vendor_optr_id;
				$apistatus=$ret->apistatus;

				if($apistatus==1)
					{
					$dataparam=$this->Recharge_Model->billviewallopsparam($operatorName);
					if($dataparam->num_rows()>0)
					{
						$datapost=$dataparam->result();
						$count=0;
						 foreach ($datapost as $key ) 
		                      {
		                      	$cnp= $key->inputfieldsid;
		                      	$count++;
		                      }
		                    
		                    //echo $_POST[$cnp];

		                    $article = new stdClass();
							$article->cn = $_POST[$cnp];
							$article->op = $vendorcode;

							$json_data = json_encode($article);

							$post = file_get_contents('https://rapi.mobikwik.com/retailer/v2/viewbill',null,stream_context_create(array(
							    'http' => array(
							        'method'           => 'POST',
							        'header'           => "Content-type: application/json\r\n".
							                              "X-MClient:14\r\n",
							        'content'          => $json_data,
							    ),
							)));

							if ($post) {
								$book = json_decode($post, true);
    							   echo "<div id='electricitymsgalert' class='modal fade' role='dialog'>
  <div class='modal-dialog'>
    <div class='modal-content'>
      <div class='modal-header'>
        <div class='row' style='width: 100%;'>
          <div class='col-sm-10'>
            <h4 class='modal-title'>Bill View</h4>
          </div>
          <div class='col-sm-2'>
             <button type='button' class='close pull-right' data-dismiss='modal' onclick='unsetrst()'>&times;</button>
          </div>
        </div>
      </div>
      <div class='modal-body'>
        <div class='row'>
        	<div class='col-sm-9'>
        	<h6>1 Bill Found</h6>
        	  <ul style='list-style-type: none!important;margin-left: -39px;font-size: 12px;line-height: 17px;'>
        	  	<li>".$book['data'][0]['cellNumber']."</li>
        	  	<li>".$operatorName."</li>
        	  	<li>".$book['data'][0]['userName']."</li>
        	  </ul>	
        	</div>
        	<div class='col-sm-3'>
        	<img src='headericon/BBPS_Logo.png' width='65' class='pull-right'>
        	</div>
        </div>
        <div class='row'>
        	<div class='col-sm-8'>
        		<ul style='list-style-type: none!important;margin-left: -39px;line-height: 28px;'>
        			<li><b>Due Date</b></li>
        			<li><b>Bill amount</b></li>
        		</ul>
        	</div>
        	<div class='col-sm-4'>
        	<ul style='list-style-type: none!important;line-height: 28px;'>
        			<li>".date('d M Y', strtotime($book['data'][0]['dueDate']))."</li>
        			<li><i class='fas fa-inr' style='font-size:13px'></i> ".$book['data'][0]['billnetamount']."</li>
        		</ul>
        	</div>
        </div>
        <div class='row'>
        	<div class='col-sm-7'>
        		
        	</div>
        	<div class='col-sm-4'>
        		<button class='btn btn-sm btn-primary pull-right'>Continue</button
        	</div>
      </div>

      <div class='row'>
      	<div class='col-sm-10'>
      		<ul style='    list-style-type: none!important;
    line-height: 19px;
    font-size: 12px;
    margin-left: -26px;
    margin-top: 25px;'>
        			<li> 1. Wallet amount added from credit card is not applicable for electricity bill payments.</li>
        			<li> 2. The service provider at times may take up to 72 hours to process your bill.</li>
        		</ul>
      	</div>
      </div>
    </div>

  </div>
</div>";
							} else {
							    echo "POST failed";
							}
						}

					     // echo 
	                }
			

				else
				{
						echo "Timed Out";
				}

				
			}



			public function operatorparameterfieldsetmobile()
			{
				$operatorName=$_GET['code'];
				$_SESSION['group_name']="Prepaid";
				$groupname=$_SESSION['group_name'];

				$data=array('groupname'=>$groupname,'operatorname'=>$operatorName);
				$datarecord=$this->Recharge_Model->operatorparameterfieldset($data);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;
						 foreach ($datapost as $key ) 
                      {
                      		if($key->inputfieldsid=='amount')
                      		{
                      			echo "<div class='form-group input-group'>";
                      			echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-inr'></i></span></div>";
                         		echo "<input type='text' class='form-control' data-bv-field='number' name='$key->inputfieldsid' id='$key->inputfieldsid' required placeholder='Enter $key->inputfieldsname' maxlength='$key->fieldlength'>";
                         		echo "</div>";
                      		}

                      		else
                      		{
                      			if(!empty($key->selectoptname))
                      			{
                      				echo "<div class='form-group'>";
                      				$arr=$key->selectoptname;
                      				$arr_value=$key->selectoptvalue;
									$selectname=explode(",",$arr);
									$selectvalue=explode(",",$arr_value);
									$count=0;
									echo "<select class='form-control'>" ;
									echo"<option value='0'> Choose ".$key->inputfieldsname."</option>";	
										foreach($selectname as $var)
										{
										 echo"<option value='$selectvalue[$count]'>".$var."</option>";
										 $count++;
										}  
									echo "</select>";	      		
	                         		echo "</div>";
                      			}
                      			else
                      			{
                      				echo "<div class='form-group'>";
	                         		echo "<input type='text' class='form-control' data-bv-field='number' name='$key->inputfieldsid' id='$key->inputfieldsid' required placeholder='Enter $key->inputfieldsname' maxlength='$key->fieldlength'>";
	                         		echo "</div>";
                      			}
                      		}
                  	  }

					  }
				
			}

			
     public function createvoucher()
     {
     	$vname=$_POST['vname'];
     	$vdes=$_POST['vdes'];
     	$vtime=$_POST['vtime'];
     	$owner=$_SESSION['accountid'].'('.$_SESSION['fullname'].')';
     	$date=date('d M Y');
     	$timex=date('h:m:s');
     	//$rand_1=rand(99999999999999,1000000000000);
     	//$rand_2=rand($rand_1,1000000000000);
     	//$rand_3=rand(9999999999999,$rand_2);
     	$voucherid=$this->randomNumber(14);;
     	$vtime=$_POST['vtime'];
     	$duration=date('d M Y', strtotime($date. ' + '.$vtime.' days'));
     	$amount=$_POST['amount'];
     	$data=array('vid'=>$voucherid,'owner'=>$owner,'vname'=>$vname,'vdescription'=>$vdes,'datex'=>$date,'timex'=>$timex,'duration'=>$duration,'amount'=>$amount); 

     	$this->Recharge_Model->vouchercreate($data);

     	if(true)
						{
							echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}

							else
							{
								echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
							}
     }


				 	public function randomNumber($length)
				 	{
				 		 $result = '';
						    for($i = 0; $i < $length; $i++) {
						        $result .= mt_rand(0, 9);
						    }
				    	return $result;
				 	}


				 	public function vouchercoderedeem()
				 	{
				 		$owner=$_SESSION['accountid'];
				     	$date=date('d M Y');
				     	$timex=date('h:m:s');
				     	$v_code=$_POST['v_code'];
				     	$datarecord=$this->Recharge_Model->reedemvoucher($v_code);
				     	$apiwallet=$this->Recharge_Model->apiwallet($owner);
				     	$orderid=rand(100000,rand(999999,10000));
						if($datarecord->num_rows()>0)
							{
								$datapost=$datarecord->result();
									 foreach ($datapost as $key ) 
			                      		{
			                      			$vdes=$key->vdescription;
			                      			$vname=$key->vname;
			                      			$amount=$key->amount;
			                      		}
			                      $_SESSION['vtopamt']=$amount;	
			                   	  $data=array('vid'=>$v_code,'owner'=>$_SESSION['accountid'],'datex'=>$date,
			                 			 'timex'=>$timex,'amount'=>$amount,'vdes'=>$vdes,'vname'=>$vname);  
			                 	  $this->Recharge_Model->reedemvoucherinst($data);
			                 	  if($apiwallet->num_rows()>0)
												{
													$balance=$apiwallet->row();
													$closingblc=($balance->balance)+$amount;
													$walletdata=array('accountid'=>$owner,'balance'=>$closingblc);
													$this->Recharge_Model->apiwalletupdate($walletdata);	
													//$dataxx=array('accountid'=>$accountid,'datex'=>date('d M Y'));
													//$this->Recharge_Model->walletsummary($dataxx);
												}

											else
												{
													$walletdata=array('accountid'=>$owner,'balance'=>$amount);
													$this->Recharge_Model->apiwalletinst($walletdata);					

												} 
												
												if(true)
									{
										$walletsummary=array('accountid'=>$_SESSION['accountid'],'amount'=>$amount,'transtype'=>'Vocher Redeem','transc'=>'Credit','oblnc'=>$balance->balance,'cblnc'=>$closingblc,'transid'=>$v_code,'description'=>'Voucher Redeem Success','mobile'=>'0');
										$this->walletsummary($walletsummary);
										//$this->walletsummary($walletsummary);


										$this->Recharge_Model->voucherupdate($v_code);
										echo " <div class='row'>
											<div class='col-sm-2'>
											<img src='newassets/images/giftbox.png' width='100'>
											</div>
											<div class='col-sm-8'>
												<div class='alert alert-solid alert-success'>
         				<h6>Congratulation! ".$_SESSION['fullname']."</h6>
                    <p>Your Wallet has been credited with <i class='fa fa-inr'></i>".$_SESSION['vtopamt']."</p>
                    <p>Your New Wallet balance is  <i class='fa fa-inr'></i>".$closingblc."</p></div>
											</div>
										</div> ";
										}

										else
										{
											echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
							                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
							                     <span aria-hidden='true'>×</span>
							                     </button>
							                </div>";
										}

			                 								
								   }

			              else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Voucher already reedemed or does'not exists.
							                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
							                     <span aria-hidden='true'>×</span>
							                     </button>
							                </div>";
						}	      		

				 	}


			public function invoicegridview()	
				{
					$orderid=$_POST['orderid'];
					$this->Recharge_Model->walletsummary();
				} 	



			public function	utipage()
			{
				$accountid=$_SESSION['accountid'];
				$data['records']=$this->Recharge_Model->psaagentview($accountid);
				$this->load->view('utipage',$data);
			}



			public function rechargehistory()
			{
				$data['records']=$this->Recharge_Model->rechargehistory();
				$this->load->view('rechargehistorymod',$data);
			}

			public function rechargedetails()
			{
				$transid=$_GET['id'];
				$data['records']=$this->Recharge_Model->rechargedetails($transid);
				$this->load->view('rechargedetails',$data);
			}

			public function serachcriteriadt()
			{
				$todate=date('d-M-Y', strtotime($_POST['todate']));
				$fordate=date('d-M-Y', strtotime($_POST['fordate']));

				$datarecord=$this->Recharge_Model->serachcriteriadt($todate,$fordate);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;			
						 foreach ($datapost as $key ) 
                      {
                         echo "<tr>";
            echo "<td align='center' style='font-size: 12px;border-right: 1px solid #ffffff00;'>$key->datex $key->timex</td>";
            echo "<td align='center' style='font-size: 12px;border-right: 1px solid #ffffff00;'>$key->orderid</td>";
            echo "<td align='center' style='font-size: 12px;border-right: 1px solid #ffffff00;'>$key->accountid</td>";
            echo "<td align='center' style='font-size: 12px;border-right: 1px solid #ffffff00;'>$key->optname</td>";
            echo "<td align='center' style='font-size: 12px;border-right: 1px solid #ffffff00;'>$key->mobile</td>";
            echo "<td align='center' style='font-size: 12px;border-right: 1px solid #ffffff00;'>$key->amount</td>";
            if($key->status=='SUCCESS')
                  {
                    echo "<td align='center' style='font-size: 17px;border-right: 1px solid #ffffff00;' ><i class=' fa fa-check-circle' style='color:#389c40'  title='Recharge Success'></i></td>";
                  }
                  elseif($key->status=='FAILURE')
                  {
                    echo "<td align='center' style='font-size: 17px;border-right: 1px solid #ffffff00;'><i class=' fa fa-times-circle' style='color:#dc3545'  title='Recharge Failure'></i></td>";
                  }
                  elseif($key->status=='ERROR')
                  {
                    echo "<td align='center' style='font-size: 17px;border-right: 1px solid #ffffff00;'><i class=' fa fa-exclamation-triangle' style='color:#ffc107'  title='Recharge Error'></i></td>";
                  }  

            echo "<td align='center' style='font-size: 12px;border-right: 1px solid #ffffff00;'>$key->optref</td>";
            echo "<td align='center' style='font-size: 12px;    border-right: 1px solid #e9ecef;'><span style='color:#0071cc'><a href=".base_url()."rechargedetails?id=$key->orderid><i class='fa fa-pencil-square-o'  title='View Details'></i></a></span></td>";
            echo "</tr>";
                      }
					}

			}


			public function voucher()
			{
				$data['records']=$this->Recharge_Model->voucherhistory();
				$this->load->view('voucher',$data);
			}

			public function voucherreedem()

			{
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
					$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
					$data['recordwallet']=$this->Recharge_Model->mywalletsummary($accountid);
				$this->load->view('voucherreedem',$data);
			}	 	


			public function passbook()
			{
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['records']=$this->Recharge_Model->userwalletsummary($_SESSION['accountid']);
				$this->load->view('passbook',$data);
			}


			public function managebranchemployee()
			{
				$utype=4;
				$data['records']=$this->Recharge_Model->ManageBM($utype);
				$this->load->view('managebranchemployee',$data);
			}

			public function addbranchmanager()
			{

				$this->load->view('addbranchmanager');
			}

			public function manageassistantbm()
			{
				$utype=5;
				$data['records']=$this->Recharge_Model->ManageBM($utype);
				$this->load->view('manageassistantbm',$data);
			}

			public function managecrm()
			{
				$utype=10;
				$data['records']=$this->Recharge_Model->ManageBM($utype);
				$this->load->view('managecrm',$data);
			}

			public function managecustomersupport()
			{
				$utype=11;
				$data['records']=$this->Recharge_Model->ManageBM($utype);
				$this->load->view('managecustomersupport',$data);
			}

			public function managebdo()
			{
				$utype=6;
				$data['records']=$this->Recharge_Model->ManageBM($utype);
				$this->load->view('managebdo',$data);
			}


			public function addassistantbm()
			{

				$this->load->view('addassistantbm');
			}

			public function managesalesmanager()
			{
				$utype=7;
				$data['records']=$this->Recharge_Model->ManageBM($utype);
				$this->load->view('managesalesmanager',$data);
			}

			public function manageterritory()
			{
				$utype=8;
				$data['records']=$this->Recharge_Model->ManageBM($utype);
				$this->load->view('manageterritory',$data);
			}

			public function managestoreincharge()
			{
				$utype=9;
				$data['records']=$this->Recharge_Model->ManageBM($utype);
				$this->load->view('managestoreincharge',$data);
			}



			public function empmap()
			{
				$data['records']=$this->Recharge_Model->empmap();
				$this->load->view('empmap',$data);
			}

			public function addmanagers()
			{
				$data['recordstate']=$this->Recharge_Model->selectstate();
				$data['recordarea']=$this->Recharge_Model->selectarea();
				$this->load->view('addmanagers',$data);
			}

			public function memberlinetype()
			{
				$usertype=$_GET['id'];
				
				if($usertype==13 || $usertype==12)
				{
					$upperdata=8;
				}
				elseif($usertype==16)
				{
					$upperdata=14;
				}
				else
				{
					$upperdata=$usertype-1;
				}
				$datarecord=$this->Recharge_Model->memberlinetype($upperdata);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						if($usertype==12 || $usertype==16 || $usertype==14)
						{
							$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;
						echo "<div class='form-group input-group'>";
                  		echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-users'></i></span> </div>";
						echo "<select class='form-control' name='uppline' id='uppline'>";
                  		echo "<option value='0'>Choose Uppline</option>";
						 foreach ($datapost as $key ) 
                      	{
                         echo "<option value='$key->accountid'>$key->fullname ($key->accountid)</option>";
                  	  	 }

                		echo "</select>";
                		echo "</div>";
						}

						else
						{
							$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;
						echo "<div class='form-group input-group'>";
                  		echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-users'></i></span> </div>";
						echo "<select class='form-control' name='uppline' id='uppline' onchange='selectmapdismember(this.value)'>";
                  		echo "<option value='0'>Choose Uppline</option>";
						 foreach ($datapost as $key ) 
                      	{
                         echo "<option value='$key->accountid'>$key->fullname ($key->accountid)</option>";
                  	  	 }

                		echo "</select>";
                		echo "</div>";
						}
                        
					  }

					  else
					  {
					  	echo "null";
					  }
			}

			public function corporatedashboard()
			{
				$this->load->view('corporatedashboard');
			} 

			public function distributortable()
			{
				$data['records']=$this->Recharge_Model->distributor();
				$this->load->view('distributortable',$data);
			}

			public function fostable()
			{
				$accountid=$_GET['id'];
				$usertype=14;
				$data['records']=$this->Recharge_Model->fostable($accountid);
				$this->load->view('fostable',$data);
			}

			public function retailertable()
			{
				$accountid=$_GET['id'];
				$usertype=16;
				$data['records']=$this->Recharge_Model->retailertable($accountid);
				$this->load->view('retailertable',$data);
			}


			public function calldist()
			{
				$stateid=$_GET['id'];
				$datarecord=$this->Recharge_Model->calldist($stateid);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;
						echo "<div class='form-group mg-b-10-force'>";
                  		echo "<label class='form-control-label'>Select City<span class='tx-danger'>*</span></label>";
						echo "<select class='form-control' name='dist_name' id='dist_name'>";
                  		echo "<option value='0'>Choose City</option>";
						 foreach ($datapost as $key ) 
                      	{
                         echo "<option value='$key->district_id / $key->district_name'>$key->district_name</option>";
                  	  	 }

                		echo "</select>";
                		echo "</div>";
                        
					  }

					  else
					  {
					  	 	echo "<span style='color:red'>Not District Added</span>";
					  }
			}

			public function memberlinetypeemp($data)
			{
				$usertype=$_GET['id'];
				
				if($usertype==11 || $usertype==9 )
				{
					$upperdata=6;
				}
				else
				{
					$upperdata=$usertype-1;
				}
				$datarecord=$this->Recharge_Model->memberlinetypeemp($upperdata);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;
						echo "<div class='form-group input-group'>";
                  	echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-user'></i></span> </div>";
						echo "<select class='form-control' name='uppline' id='uppline' onchange='selectmapdis(this.value)'>";
                  		echo "<option value='0'>Choose Uppline</option>";
						 foreach ($datapost as $key ) 
                      	{
                         echo "<option value='$key->accountid'>$key->fullname ($key->accountid)</option>";
                  	  	 }

                		echo "</select>";
                		echo "</div>";
                        
					  }

					  else
					  {
					  	echo "null";
					  }
			}


			public function employeedash()
			{
				$data['records']=$this->Recharge_Model->probannerdetails();
				$data['recordmenulest']=$this->Recharge_Model->recordmenulest();
				$data['recordmenu']=$this->Recharge_Model->groupmenu();
				$data['recordopt']=$this->Recharge_Model->operatordetailsEMI();
				$this->load->view('employeedash');
			}

			public function distforemp()
			{
				$bstate=$_GET['id'];
				$uid=$_GET['uid'];
				$uppid=$_GET['uppid'];
				if($uid==4)
				{
					$selectdistmap=$this->Recharge_Model->selectdistmap($bstate);
					if($selectdistmap->num_rows()>0)
					{	
						$selectdist=$selectdistmap->result();
						echo "<div class='form-group mg-b-10-force'>";
                  		echo "<label class='form-control-label'>Branch District<span class='tx-danger'>*</span></label>";
						echo "<select class='form-control' name='bdist[]' id='bdist[]' multiple>";
                  		echo "<option value='0'>Choose District</option>";
						 foreach ($selectdist as $key ) 
                      	{
                         echo "<option value='$key->district_name'>$key->district_name</option>";
                  	  	 }

                		echo "</select>";
                		echo "</div>";
					}

					else
					{

					}
				}

				else
				{
					//echo $uppid;
				}
			}

			public function distempselect()
			{

					$query=$this->db->get_where("member",array("accountid"=>$_GET['id']));
					//$dome=$query->result();
				if($query->num_rows()>0)

				{
					$spill=$query->row();
					$dist = explode(",", $spill->dist);
					echo "<div class='form-group mg-b-10-force'>";
                  		echo "<label class='form-control-label'>Branch District<span class='tx-danger'>*</span></label>";
						echo "<select class='form-control' name='bdist[]' id='bdist[]' multiple>";
                  		echo "<option value='0'>Choose District</option>";
						foreach($dist as $key) {
					    $key = trim($key);
					    if(empty($key))
					    {

					    }
					    else
					    {
					    		 $categories .= "<option value='$key'>" . $key . "</option>\n";
					    }
					   
					}
						echo $categories;
                		echo "</select>";
                		echo "</div>";
					
				}

				else
				{
					echo "fail";
				}
			}


			public function circlecode()
			{
				$data['records']=$this->Recharge_Model->selectstate();
				$data['recordc']=$this->Recharge_Model->selectdist();
				$data['recordt']=$this->Recharge_Model->selectterri();
				$this->load->view('circlecode',$data);
			}

			public function calldistrt()
			{
				$stateid=$_GET['id'];
				$datarecord=$this->Recharge_Model->calldistrt($stateid);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;
						echo "<div class='form-group mg-b-10-force'>";
                  		echo "<label class='form-control-label'>Select District<span class='tx-danger'>*</span></label>";
						echo "<select  class='form-control' name='dist_name[]' id='dist_name[]' onchange='pincode(this.value,i)'>";
                  		echo "<option value='0'>Choose District</option>";
						 foreach ($datapost as $key ) 
                      	{
                         echo "<option value='$key->district_id'>$key->district_name</option>";
                  	  	 }

                		echo "</select>";
                		echo "</div>";
                        
					  }

					  else
					  {
					  	 	echo "<span style='color:red'>Not District Added</span>";
					  }
			}


			public function pincodefind()
			{
				$distid=$_GET['id'];

				$datarecord=$this->Recharge_Model->pincodefin($distid);
				//$this->load->view('apisettings',$data);
				if($datarecord->num_rows()>0)
					{
						$datapost=$datarecord->result();
						//$data=  json_decode(json_encode($datapost),true);
						$count=1;
						echo "<div class='form-group mg-b-10-force'>";
                  		echo "<label class='form-control-label'>Select Pincode<span class='tx-danger'>*</span></label>";
						echo "<select multiple class='form-control' name='pincode[]' id='pincode[]'>";
                  		echo "<option value='0'>Choose Pincode</option>";
						 foreach ($datapost as $key ) 
                      	{
                         echo "<option value='$key->pincode'>$key->pincode</option>";
                  	  	 }

                		echo "</select>";
                		echo "</div>";
                        
					  }

					  else
					  {
					  	 	echo "<span style='color:red'>Not Pincode Added</span>";
					  }
			}

			public function circleinst()
			{
				$circlename=$_POST['circlename'];
				$dist_stid=$_POST['dist_stid'];
				$dist_name=$_POST['dist_name'];
				$pincode=$_POST['pincode'];
				$circlecode=rand(1000,9999);
				foreach( $dist_stid as $key => $n ) 
				{
					$dist_stidc=$dist_stid[$key].','.$dist_stidc;
				}

				foreach( $dist_name as $key => $n ) 
				{
					$dist_namec=$dist_name[$key].','.$dist_namec;
				}
				//echo $dist_namec;

				foreach( $pincode as $key => $n ) 
				{
					$pincodex=$pincode[$key].','.$pincodex;
				}

				//echo $pincodex;


				$data=array('circlecode'=>$circlecode,'cirname'=>$circlename,'state'=>$dist_stidc,'district'=>$dist_namec,'pincode'=>$pincodex);

				$this->Recharge_Model->circleinst($data);

				if(true)
				{	
					echo "Success";
				}

				else
				{
					echo "Fail";
				}
			}

			public function CircleManage()
			{
				$data['records']=$this->Recharge_Model->CircleManage();
				$data['recordstate']=$this->Recharge_Model->StateCircle();
				$this->load->view('CircleManage',$data);
			}


			public function circleempselect()
			{

					$query=$this->db->get_where("member",array("accountid"=>$_GET['id']));
					//$dome=$query->result();
				if($query->num_rows()>0)

				{
					$spill=$query->row();
					$dist = explode(",", $spill->bpincode);
					echo "<div class='col-sm-12'>";
					echo "<div class='form-group input-group'>";
                  	echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-map-marker'></i></span> </div>";
                  	echo "<input type='text' value='$spill->circlename' name='bstatename' id='bstatename' class='form-control'>";
                  	echo "<input type='hidden' value='$spill->circlecode' name='bstateid' id='bstateid' class='form-control'>";

                  	echo "</div>";
                	echo "</div>";

					echo "<div class='col-sm-12'>";
					echo "<div class='form-group input-group'>";
                  	echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-map-marker'></i></span> </div>";
						echo "<select class='form-control' name='bdist[]' id='bdist[]' multiple>";
                  		echo "<option value='0'>Choose Area Code</option>";
						foreach($dist as $key) {
					    $key = trim($key);
					    if(empty($key))
					    {

					    }
					    else
					    {
					    		 $categories .= "<option value='$key'>" . $key . "</option>\n";
					    }
					   
					}
						echo $categories;
                		echo "</select>";
                		echo "</div>";
                		echo "</div>";
					
				}

				else
				{
					echo "fail";
				}
			}



			public function circleempselectmember()
			{

					$query=$this->db->get_where("member",array("accountid"=>$_GET['id']));
					//$dome=$query->result();
				if($query->num_rows()>0)

				{
					$spill=$query->row();
					$dist = explode(",", $spill->bpincode);
					echo "<div class='col-sm-12'>";
					echo "<div class='form-group input-group'>";
                  	echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-map-marker'></i></span> </div>";
                  	echo "<input type='text' value='$spill->circlename' name='bstatename' id='bstatename' class='form-control'>";
                  	echo "<input type='hidden' value='$spill->circlecode' name='bstateid' id='bstateid' class='form-control'>";

                  	echo "</div>";
                	echo "</div>";

					echo "<div class='col-sm-12'>";
					echo "<div class='form-group input-group'>";
                  	echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-map-marker'></i></span> </div>";
						echo "<select class='form-control' name='bdist' id='bdist' onchange='pincodemap(this.value)'>";
                  		echo "<option value='0'>Choose PinCode</option>";
						foreach($dist as $key) {
					    $key = trim($key);
					    if(empty($key))
					    {

					    }
					    else
					    {
					    		 $categories .= "<option value='$key'>" . $key . "</option>\n";
					    }
					   
					}
						echo $categories;
                		echo "</select>";
                		echo "</div>";
                		echo "</div>";
					
				}

				else
				{
					echo "fail";
				}
			}

			public function pincodemap()
			{
				$pincode=$_GET['id'];
				$query=$this->db->get_where("territory",array("pincode"=>$pincode));
					//$dome=$query->result();
				if($query->num_rows()>0)

				{
					$spill=$query->row();
					//$dist = explode(",", $spill->bpincode);
					echo "<div class='col-sm-12'>";
					echo "<div class='form-group input-group'>";
                  	echo "<div class='input-group-prepend'> <span class='input-group-text'><i class='fa fa-map-marker'></i></span> </div>";
                  	echo "<input type='text' value='$spill->territory_name' name='terriname' id='terriname' class='form-control'>";
                  	echo "</div>";
                  	echo "</div>";
				}
				else
				{
					echo "No Record";
				}
			}


			public function userforminputdist()

			{

				$x1=rand(10000000,99999999);
				 $x2=rand(10000000,$x1);
				 $x3=rand($x2,99999999);	

				$fullname=$_POST['fullname'];
				$dob=$_POST['dob'];
				$address=$_POST['address'];
				$city=$_POST['city'];
				$email=$_POST['emailid'];
				$passwords=substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') , 0 , 6 );
				$accountid=rand($x1,$x2);
				$phone=$_POST['phone'];
				//$sname=$_POST['bname'];
				$zipcode=$_POST['zipcode'];
				$state=$_POST['state'];
				//$bstate=$_POST['bstate'];
				//$adhar=$_POST['adharnum'];
				$state=$_POST['state'];
				$status=0;
				$usertype=$_POST['usertype'];
				$cdate=date('d-m-Y');
				//$manager=$_POST['manager'];
				$gender=$_POST['gender'];
				//$rdate=date('d-m-Y', strtotime($duration));
				$profiletype='corporate';
				$pancard=$_POST['pancard'];
				$documentper=$_POST['documentper'];
				$docid=$_POST['docid'];
				$marital=$_POST['marital'];

				if($usertype==13)
				{
					$bstatename=$_POST['bstatename'];
					$bstateid=$_POST['bstateid'];
					$terriname=$_POST['terriname'];
					$bdist=$_POST['bdist'];
				}

				else
				{
					$bstatename=0;
					$bstateid=0;
					$terriname=0;
					$bdist=0;

				}

				$data=array('fullname'=>$fullname,
				//'lname'=>$lname,
				'birth'=>$dob,
				'address'=>$address,
				'city'=>$city,
				'email'=>$email,
				'pass'=>$passwords,
				'accountid'=>$accountid,
				'cdate'=>$cdate,
				//'rdate'=>$rdate,
				'phone'=>$phone,
				//'sname'=>$sname,
				'pincode'=>$zipcode,
				//'pan'=>$pan,
				//'adhar'=>$adhar,
				'state'=>$state,
				//'duration'=>$duration,
				'status'=>$status,
				'usertype'=>$usertype,
				'gender'=>$gender,
				'profiletype'=>'corporate',
				//'bstate'=>'0',
				//'dist'=>$datadistt
				'bpincode'=>$bdist,
				'circlecode'=>$bstateid,
				'circlename'=>$bstatename,
				'pancard'=>$pancard,
				'documentper'=>$documentper,
				'docid'=>$docid,
				'marital'=>$marital,
				'terriname'=>$terriname
				
				);

				$query=$this->db->get_where("member",array("phone"=>$phone));
				$ret=$query->row();

					

 					if($query->num_rows()>0)
		     			{
		     				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Account already exists.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
		     			}

		     			else
		     			{
		     				$this->Recharge_Model->addmember($data);
							$walletdata=array('accountid'=>$accountid,'balance'=>0);
							$this->Recharge_Model->apiwalletinst($walletdata);
							$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$phone.'&text='.$message.'&senderid=EZYONE&route_id=2&Unicode=0');
						

						if($usertype==13)
							{
								$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
								if($datarest->num_rows()>0)
										{
											$usermember=$datarest->row();
											$accdmid=$usermember->accdmid;
											$bmid=$usermember->bmid;
											$smid=$usermember->smid;
											$sicid=$usermember->sicid;
											$crsid=$usermember->accountid;
											
										}
								$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid,'smid'=>$smid,'sicid'=>$sicid,'crsid'=>$crsid);
								$this->Recharge_Model->empdatamap($datamap);

								if(empty($_POST['retailertype']) || empty($_POST['businessname']) || empty($_POST['gstnumber']) )
								{
									$datae=array('accountid'=>$accountid,'phone'=>$phone,'fname'=>$fullname,
					            'dob'=>$dob,'emailid'=>$email,'paddress'=>$address,
					            'city'=>$city,'state'=>$state,'zipcodex'=>$zipcode,'profiletype'=>$usertype,'appdt'=>date('d M Y'));
								$this->Recharge_Model->corporateprofileinst($datae);

								}

								else
								{
									
										$target_dirpan = "./empdata/";
										$x1pan=rand(1000,9999);
									 	$x2pan=rand(1000,$x1pan);
									 	$x3pan=rand($x2pan,9999);
										$id=rand($x3pan,$x1pan);
										$bpan_basename=basename($id."_corporatefile_".$_FILES["bpancard"]["name"]);
										$target_file_photo = $target_dirpan . $bpan_basename;
										move_uploaded_file($_FILES["bpancard"]["tmp_name"], $target_file_photo);
										$target_dirbadhar = "./empdata/";
										$x1badhar=rand(1000,9999);
									 	$x2badhar=rand(1000,$x1badhar);
									 	$x3badhar=rand($x2badhar,9999);
										$id=rand($x3badhar,$x1badhar);
										$badhar_basename=basename($id."_corporatefile_".$_FILES["badhar"]["name"]);
										$target_file_photo = $target_dirbadhar . $badhar_basename;
										move_uploaded_file($_FILES["badhar"]["tmp_name"], $target_file_photo);
										$target_dirfadhar = "./empdata/";
										$x1fadhar=rand(1000,9999);
									 	$x2fadhar=rand(1000,$x1fadhar);
									 	$x3fadhar=rand($x2fadhar,9999);
										$id=rand($x3fadhar,$x1fadhar);
										$fadhar_basename=basename($id."_corporatefile_".$_FILES["fadhar"]["name"]);
										$target_file_photo = $target_dirfadhar . $fadhar_basename;
										move_uploaded_file($_FILES["fadhar"]["tmp_name"], $target_file_photo);

									$datae=array('accountid'=>$accountid,'phone'=>$phone,'fname'=>$fullname,
					            'dob'=>$dob,'emailid'=>$email,'paddress'=>$address,
					            'city'=>$city,'state'=>$state,'zipcodex'=>$zipcode,'cmpname'=>$_POST['businessname'],
					            'cmpnat'=>$_POST['retailertype'],'baddress'=>$_POST['baddress'],
					            'bstate'=>$_POST['bsstate'],'gstinid'=>$_POST['gstnumber'],'bcity'=>$_POST['bscity'],'bzipcode'=>$_POST['bszipcode'],'profiletype'=>$usertype,'appdt'=>date('d M Y'),'docpan'=>$bpan_basename);

					            $this->Recharge_Model->corporateprofileinst($datae);
								}
								//echo $_POST['ifsccode'];
								if(empty($_POST['ifsccode']) || empty($_POST['acctnumber']))
								{
									$bankdata=array('accountid'=>$accountid,'fullname'=>$fullname);
									$this->Recharge_Model->bankinstinst($bankdata);
								}

								else
								{	
									

									$target_dir = "./empdata/";
									$x1c=rand(1000,9999);
								 	$x2c=rand(1000,$x1c);
								 	$x3c=rand($x2c,9999);
									$id=rand($x3c,$x1c);
									$photo_basename=basename($id."_bankfile_".$_FILES["acctcheck"]["name"]);
									$target_file_photo = $target_dir . $photo_basename;
									move_uploaded_file($_FILES["acctcheck"]["tmp_name"], $target_file_photo);
									$bankdata=array('accountid'=>$accountid,'fullname'=>$fullname,'ifsc'=>$_POST['ifsccode'],'bankname'=>$_POST['bankname'],'branch'=>$_POST['branch'],'acctname'=>$_POST['acctname'],'bankacct'=>$_POST['acctnumber'],'cancelcheck'=>$photo_basename);
									$this->Recharge_Model->bankinstinst($bankdata);
								}



							}	

							if($usertype==12)
							{
								$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
								if($datarest->num_rows()>0)
										{
											$usermember=$datarest->row();
											$accdmid=$usermember->accdmid;
											$bmid=$usermember->bmid;
											$smid=$usermember->smid;
											$sicid=$usermember->sicid;
											$crsid=$usermember->accountid;
											
										}
								$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid,'smid'=>$smid,'sicid'=>$sicid,'crsid'=>$crsid);
								$this->Recharge_Model->empdatamap($datamap);

								if(empty($_POST['retailertype']) || empty($_POST['businessname']) || empty($_POST['gstnumber']) )
								{
									$datae=array('accountid'=>$accountid,'phone'=>$phone,'fname'=>$fullname,
					            'dob'=>$dob,'emailid'=>$email,'paddress'=>$address,
					            'city'=>$city,'state'=>$state,'zipcodex'=>$zipcode,'profiletype'=>$usertype,'appdt'=>date('d M Y'));
								$this->Recharge_Model->corporateprofileinst($datae);

								}

								else
								{
									
										$target_dirpan = "./empdata/";
										$x1pan=rand(1000,9999);
									 	$x2pan=rand(1000,$x1pan);
									 	$x3pan=rand($x2pan,9999);
										$id=rand($x3pan,$x1pan);
										$bpan_basename=basename($id."_corporatefile_".$_FILES["bpancard"]["name"]);
										$target_file_photo = $target_dirpan . $bpan_basename;
										move_uploaded_file($_FILES["bpancard"]["tmp_name"], $target_file_photo);
										$target_dirbadhar = "./empdata/";
										$x1badhar=rand(1000,9999);
									 	$x2badhar=rand(1000,$x1badhar);
									 	$x3badhar=rand($x2badhar,9999);
										$id=rand($x3badhar,$x1badhar);
										$badhar_basename=basename($id."_corporatefile_".$_FILES["badhar"]["name"]);
										$target_file_photo = $target_dirbadhar . $badhar_basename;
										move_uploaded_file($_FILES["badhar"]["tmp_name"], $target_file_photo);
										$target_dirfadhar = "./empdata/";
										$x1fadhar=rand(1000,9999);
									 	$x2fadhar=rand(1000,$x1fadhar);
									 	$x3fadhar=rand($x2fadhar,9999);
										$id=rand($x3fadhar,$x1fadhar);
										$fadhar_basename=basename($id."_corporatefile_".$_FILES["fadhar"]["name"]);
										$target_file_photo = $target_dirfadhar . $fadhar_basename;
										move_uploaded_file($_FILES["fadhar"]["tmp_name"], $target_file_photo);

									$datae=array('accountid'=>$accountid,'phone'=>$phone,'fname'=>$fullname,
					            'dob'=>$dob,'emailid'=>$email,'paddress'=>$address,
					            'city'=>$city,'state'=>$state,'zipcodex'=>$zipcode,'cmpname'=>$_POST['businessname'],
					            'cmpnat'=>$_POST['retailertype'],'baddress'=>$_POST['baddress'],
					            'bstate'=>$_POST['bsstate'],'gstinid'=>$_POST['gstnumber'],'bcity'=>$_POST['bscity'],'bzipcode'=>$_POST['bszipcode'],'profiletype'=>$usertype,'appdt'=>date('d M Y'),'docpan'=>$bpan_basename);

					            $this->Recharge_Model->corporateprofileinst($datae);
								}
								//echo $_POST['ifsccode'];
								if(empty($_POST['ifsccode']) || empty($_POST['acctnumber']))
								{
									$bankdata=array('accountid'=>$accountid,'fullname'=>$fullname);
									$this->Recharge_Model->bankinstinst($bankdata);
								}

								else
								{	
									

									$target_dir = "./empdata/";
									$x1c=rand(1000,9999);
								 	$x2c=rand(1000,$x1c);
								 	$x3c=rand($x2c,9999);
									$id=rand($x3c,$x1c);
									$photo_basename=basename($id."_bankfile_".$_FILES["acctcheck"]["name"]);
									$target_file_photo = $target_dir . $photo_basename;
									move_uploaded_file($_FILES["acctcheck"]["tmp_name"], $target_file_photo);
									$bankdata=array('accountid'=>$accountid,'fullname'=>$fullname,'ifsc'=>$_POST['ifsccode'],'bankname'=>$_POST['bankname'],'branch'=>$_POST['branch'],'acctname'=>$_POST['acctname'],'bankacct'=>$_POST['acctnumber'],'cancelcheck'=>$photo_basename);
									$this->Recharge_Model->bankinstinst($bankdata);
								}


							}


							if($usertype==14)
							{
								$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
								if($datarest->num_rows()>0)
										{
											$usermember=$datarest->row();
											$accdmid=$usermember->accdmid;
											$bmid=$usermember->bmid;
											$smid=$usermember->smid;
											$sicid=$usermember->sicid;
											$crsid=$usermember->crsid;
											$distid=$usermember->accountid;
											
										}
								$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid,'smid'=>$smid,'sicid'=>$sicid,'crsid'=>$crsid,'distri'=>$distid);
								$this->Recharge_Model->empdatamap($datamap);


								if(empty($_POST['retailertype']) || empty($_POST['businessname']) || empty($_POST['gstnumber']) )
								{
									$datae=array('accountid'=>$accountid,'phone'=>$phone,'fname'=>$fullname,
					            'dob'=>$dob,'emailid'=>$email,'paddress'=>$address,
					            'city'=>$city,'state'=>$state,'zipcodex'=>$zipcode,'profiletype'=>$usertype,'appdt'=>date('d M Y'));
								$this->Recharge_Model->corporateprofileinst($datae);

								}

								else
								{
									
										$target_dirpan = "./empdata/";
										$x1pan=rand(1000,9999);
									 	$x2pan=rand(1000,$x1pan);
									 	$x3pan=rand($x2pan,9999);
										$id=rand($x3pan,$x1pan);
										$bpan_basename=basename($id."_corporatefile_".$_FILES["bpancard"]["name"]);
										$target_file_photo = $target_dirpan . $bpan_basename;
										move_uploaded_file($_FILES["bpancard"]["tmp_name"], $target_file_photo);
										$target_dirbadhar = "./empdata/";
										$x1badhar=rand(1000,9999);
									 	$x2badhar=rand(1000,$x1badhar);
									 	$x3badhar=rand($x2badhar,9999);
										$id=rand($x3badhar,$x1badhar);
										$badhar_basename=basename($id."_corporatefile_".$_FILES["badhar"]["name"]);
										$target_file_photo = $target_dirbadhar . $badhar_basename;
										move_uploaded_file($_FILES["badhar"]["tmp_name"], $target_file_photo);
										$target_dirfadhar = "./empdata/";
										$x1fadhar=rand(1000,9999);
									 	$x2fadhar=rand(1000,$x1fadhar);
									 	$x3fadhar=rand($x2fadhar,9999);
										$id=rand($x3fadhar,$x1fadhar);
										$fadhar_basename=basename($id."_corporatefile_".$_FILES["fadhar"]["name"]);
										$target_file_photo = $target_dirfadhar . $fadhar_basename;
										move_uploaded_file($_FILES["fadhar"]["tmp_name"], $target_file_photo);

									$datae=array('accountid'=>$accountid,'phone'=>$phone,'fname'=>$fullname,
					            'dob'=>$dob,'emailid'=>$email,'paddress'=>$address,
					            'city'=>$city,'state'=>$state,'zipcodex'=>$zipcode,'cmpname'=>$_POST['businessname'],
					            'cmpnat'=>$_POST['retailertype'],'baddress'=>$_POST['baddress'],
					            'bstate'=>$_POST['bsstate'],'gstinid'=>$_POST['gstnumber'],'bcity'=>$_POST['bscity'],'bzipcode'=>$_POST['bszipcode'],'profiletype'=>$usertype,'appdt'=>date('d M Y'),'docpan'=>$bpan_basename);

					            $this->Recharge_Model->corporateprofileinst($datae);
								}

								if(empty($_POST['ifsccode']) || empty($_POST['acctnumber']))
								{
									$bankdata=array('accountid'=>$accountid,'fullname'=>$fullname);
									$this->Recharge_Model->bankinstinst($bankdata);
								}

								else
								{	
									$target_dir = "./empdata/";
									$x1c=rand(1000,9999);
								 	$x2c=rand(1000,$x1c);
								 	$x3c=rand($x2c,9999);
									$id=rand($x3c,$x1c);
									$photo_basename=basename($id."_bankfile_".$_FILES["acctcheck"]["name"]);
									$target_file_photo = $target_dir . $photo_basename;
									move_uploaded_file($_FILES["acctcheck"]["tmp_name"], $target_file_photo);
									$bankdata=array('accountid'=>$accountid,'fullname'=>$fullname,'ifsc'=>$_POST['ifsccode'],'bankname'=>$_POST['bankname'],'branch'=>$_POST['branch'],'acctname'=>$_POST['acctname'],'bankacct'=>$_POST['acctnumber'],'cancelcheck'=>$photo_basename);
									$this->Recharge_Model->bankinstinst($bankdata);
								}



							}


							if($usertype==16)
							{
								$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
								if($datarest->num_rows()>0)
										{
											$usermember=$datarest->row();
											$accdmid=$usermember->accdmid;
											$bmid=$usermember->bmid;
											$smid=$usermember->smid;
											$sicid=$usermember->sicid;
											$crsid=$usermember->crsid;
											$distri=$usermember->distri;
											$fos=$usermember->accountid;

											
										}
								$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid,'smid'=>$smid,'sicid'=>$sicid,'crsid'=>$crsid,'distri'=>$distri,'fos'=>$fos);
								$this->Recharge_Model->empdatamap($datamap);
							}


						}

						echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been added successfully.
			                   <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                    </button>
			               </div>";

			
					}




		public function bankmanager()
		{
			$data['records']=$this->Recharge_Model->selectbank();
			$data['recordc']=$this->Recharge_Model->selectbankbranch();
			//$data['recordt']=$this->Recharge_Model->selectterri();
			//$this->load->view('statemanager',$data);
			$this->load->view('bankmanager',$data);
		}

		public function addbank()
		{
			$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
				 	$bank_id=rand($x2c,$x3c);
				 	$bank_name=$_POST['bankname'];
				 	$data=array('bnkid'=>$bank_id,'bankname'=>$bank_name,'datex'=>date('d-M-Y'));
				 	$this->Recharge_Model->addbank($data);
				 	if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}
		}


		public function addbankbranch()
		{
					$x1c=rand(1000,9999);
				 	$x2c=rand(1000,$x1c);
				 	$x3c=rand($x2c,9999);
				 	$branchid=rand($x2c,$x3c);
				 	$ifsccode=$_POST['ifsccode'];
				 	$location=$_POST['location'];
				 	$bank_dt=explode('/', $_POST['bankname']);
				 	$bnkid=$bank_dt[0];
				 	$bankname=$bank_dt[1];

				 	$data=array('branchid'=>$branchid,'bnkid'=>$bnkid,
				 				'bankname'=>$bankname,'ifsccode'=>$ifsccode,'datex'=>date('d-M-Y'),'location'=>$location);

				 	$this->Recharge_Model->addbankbranch($data);

				 	if(true)
					{
						echo "<div class='alert alert-solid alert-success '  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been updated successfully.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}

						else
						{
							echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
			                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			                     <span aria-hidden='true'>×</span>
			                     </button>
			                </div>";
						}
		}	


		public function bprofilemanage()
		{
			$this->load->view('bprofilemanage');
		}		
}

