<?php

 $str = file_get_contents('http://api.openweathermap.org/data/2.5/weather?q=Kolkata,IN&APPID=ede766f84a7999d40055f7c2508dc09d');




      $json=json_decode($str,true);

      $statuscode=$json['weather'];
      //$status=$json['statuscode'];

      echo $statuscode;



?>