$x1=rand(10000000,99999999);
			 $x2=rand(10000000,$x1);
			 $x3=rand($x2,99999999);	

			$fullname=$_POST['fullname'];
			$dob=$_POST['dob'];
			$address=$_POST['address'];
			$city=$_POST['city'];
			$email=$_POST['emailid'];
			$passwords=substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') , 0 , 6 );
			$accountid=rand($x1,$x2);
			$phone=$_POST['phone'];
			//$sname=$_POST['bname'];
			$zipcode=$_POST['zipcode'];
			$state=$_POST['state'];
			//$bstate=$_POST['bstate'];
			//$adhar=$_POST['adharnum'];
			$state=$_POST['state'];
			$status=0;
			$usertype=$_POST['usertype'];
			$cdate=date('d-m-Y');
			//$manager=$_POST['manager'];
			$gender=$_POST['gender'];
			//$rdate=date('d-m-Y', strtotime($duration));
			$profiletype='corporate';
			$message=urlencode('Please Login www.ezyone.in User ID: '.$phone.' Password: '.$passwords.' Please change your Password for sequrity reason. Thank you for EZYONE.');
			//$message1=urlencode(', Your password : ');

			//$bcirclecode=

			if($usertype==13 || $usertype==14 || $usertype==15 || $usertype==16)
			{
					$datadistt='0';
					$bstate='0';
			}


			if($usertype==4)
			{
				//$ddistrict=$_POST['bdist'];
				//foreach( $ddistrict as $key => $n ) 
				//{
				  
				//	$datadistt=$ddistrict[$key].','.$datadistt;
				//}
				$datadistt='0';
				$bstate='0';
				$circlesd=$_POST['bstate'];
				$querybstate=$this->db->get_where("circlecode",array("circlecode"=>$circlesd));
				$retbstate=$querybstate->row();

					

 					if($querybstate->num_rows()>0)
		     			{
		     				$pincode=$retbstate->pincode;
		     			}
			}

			else
			{
				//$ddistrict=$_POST['bdist'];
				//foreach( $ddistrict as $key => $n ) 
				//{
				  
					//$datadistt=$ddistrict[$key].','.$datadistt;
				//}
			}

			$data=array('fullname'=>$fullname,
				//'lname'=>$lname,
				'birth'=>$dob,
				'address'=>$address,
				'city'=>$city,
				'email'=>$email,
				'pass'=>$passwords,
				'accountid'=>$accountid,
				'cdate'=>$cdate,
				//'rdate'=>$rdate,
				'phone'=>$phone,
				//'sname'=>$sname,
				'pincode'=>$zipcode,
				//'pan'=>$pan,
				//'adhar'=>$adhar,
				'state'=>$state,
				//'duration'=>$duration,
				'status'=>$status,
				'usertype'=>$usertype,
				'gender'=>$gender,
				'profiletype'=>'corporate',
				'bstate'=>$bstate,
				//'dist'=>$datadistt
				'bpincode'=>$bpincode,
				'circlecode'=>$circlesd
				
				);

			$query=$this->db->get_where("member",array("phone"=>$phone,"usertype"=>$usertype));
			$ret=$query->row();

					

 					if($query->num_rows()>0)
		     			{
		     				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Account already exists.
				                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				                     <span aria-hidden='true'>×</span>
				                     </button>
				                </div>";
		     			}

		     			else
		     			{
		     				$this->Recharge_Model->addmember($data);
							$walletdata=array('accountid'=>$accountid,'balance'=>0);
							$this->Recharge_Model->apiwalletinst($walletdata);


			
			//$this->Recharge_Model->

			//http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$number.'&text='.$message.$otp.'&senderid=EZYONE&route_id=2&Unicode=0

			//http://182.18.143.11/api/mt/SendSMS?APIKEY=0eGkG5Ic5Ea50ArMMvBjIA&senderid=EZYONE&channel=Trans&DCS=0&flashsms=0&number='.$phone.'&text='.$message.'&route=32

			$str=file_get_contents('http://198.24.149.4/API/pushsms.aspx?loginID=ezyone1&password=Admin@123&mobile='.$phone.'&text='.$message.'&senderid=EZYONE&route_id=2&Unicode=0');



			if(true)
			{
				if(empty($_POST['uppline']))
				{
					$datamap=array('accountid'=>$accountid,'fname'=>$fullname,'appdt'=>date('d M Y'));
					$this->Recharge_Model->corporateprofileinst($datamap);
					
				}
				if(!empty($_POST['uppline']))
				{
					if($usertype==13)
					{
						$datamap=array('accountid'=>$accountid,'fname'=>$fullname,'appdt'=>date('d M Y'));
						$this->Recharge_Model->corporateprofileinst($datamap);

						$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
						if($datarest->num_rows()>0)
							{
								$usermember=$datarest->row();
								$accdmid=$usermember->accdmid;
								$bmid=$usermember->bmid;
								$smid=$usermember->smid;
								$sicid=$usermember->accountid;
								$crsid=$usermember->crsid;
								
							}
					$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid,'smid'=>$smid,'sicid'=>$sicid,'crsid'=>$crsid);
					$this->Recharge_Model->empdatamap($datamap);
						
					}
					if($usertype==14)
					{
						$datamap=array('accountid'=>$accountid,'uppdist'=>$_POST['uppline'],'fname'=>$fullname,'appdt'=>date('d M Y'));
						$this->Recharge_Model->corporateprofileinst($datamap);
					}

					if($usertype==16 || $usertype==15)
					{
						$distributor=$this->Recharge_Model->finddist($_POST['uppline']);

							if($distributor->num_rows()>0)
							{
								$usermember=$distributor->row();
								$distaccountid=$usermember->uppdist;
					
							}

						$datamap=array('accountid'=>$accountid,'uppfos'=>$_POST['uppline'],'uppdist'=>$distaccountid,'fname'=>$fullname,'appdt'=>date('d M Y'));
						$this->Recharge_Model->corporateprofileinst($datamap);
					}
				}
				if($usertype==4)
				{
					$datamap=array('accountid'=>$accountid);
					$this->Recharge_Model->empdatamap($datamap);
				}

				if($usertype==5)
				{
					$datamap=array('accountid'=>$accountid,'bmid'=>$_POST['uppline']);
					$this->Recharge_Model->empdatamap($datamap);
				}

				if($usertype==6)
				{
					$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
					if($datarest->num_rows()>0)
							{
								$usermember=$datarest->row();
								$accdmid=$usermember->accountid;
								$bmid=$usermember->bmid;
					
							}
					$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid);
					$this->Recharge_Model->empdatamap($datamap);
				}

				if($usertype==11 || $usertype==7)
				{
					$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
					if($datarest->num_rows()>0)
							{
								$usermember=$datarest->row();
								$accdmid=$usermember->accdmid;
								$bmid=$usermember->bmid;
								$smid=$usermember->accountid;
								
							}
					$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid,'smid'=>$smid);
					$this->Recharge_Model->empdatamap($datamap);
				}

				

				if($usertype==8)
				{
					$datarest=$this->Recharge_Model->upperlistempmap($_POST['uppline']);
					if($datarest->num_rows()>0)
							{
								$usermember=$datarest->row();
								$accdmid=$usermember->accdmid;
								$bmid=$usermember->bmid;
								$smid=$usermember->smid;
								$sicid=$usermember->accountid;
								
							}
					$datamap=array('accountid'=>$accountid,'bmid'=>$bmid,'accdmid'=>$accdmid,'smid'=>$smid,'sicid'=>$sicid);
					$this->Recharge_Model->empdatamap($datamap);
				}


				
			echo "<div class='alert alert-solid alert-success'  id='added'><i  class='fa fa-check-circle' style='font-size: 16px'></i> &nbsp;Data has been added successfully.
                   <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                    </button>
               </div>";
				
			}

			else
			{
				echo "<div class='alert alert-solid alert-danger'  id='added'><i  class='fa fa-times-circle' style='font-size: 16px'></i> &nbsp;Fail , please try again.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                     <span aria-hidden='true'>×</span>
                     </button>
                </div>";
			}
		}