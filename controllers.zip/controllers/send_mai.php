<?php 
	date_default_timezone_set('Asia/Kolkata');
	require('mailer_config/vendor/autoload.php');
	$SG_UNAME = 'testotp';
	$SG_PASS = 'Avijit$123';
	$FROM = 'lobo@king.com';
	$FROM_NAME = 'PAN verfication';
	$DOMAIN = 'http://rechargehubs.com/';

	
function send_email($email,$mail_HTML,$subject,$form="",$cc="",$replyto="",$cc1=""){
	global $SG_UNAME;
	global $SG_PASS;
	global $FROM;
	global $FROM_NAME;
	$sendgrid = new SendGrid($SG_UNAME,$SG_PASS);
	$semail = new SendGrid\Email();
	$semail->addTo($email);
	if(!empty($cc))
		$semail->addCc($cc);
	if(!empty($replyto))
		$semail->addBcc($replyto);

	if(!empty($cc1))
		$semail->addCc($cc1);

	if(!empty($form))
    	$semail->setFrom($form);
    else
    	$semail->setFrom($FROM);
    
    $semail->setSubject($subject);
    $semail->setHtml($mail_HTML);
	$semail->setFromName($FROM_NAME);
	$sendgrid->send($semail);
}

function send_email_bcc($email,$mail_HTML,$subject){
	global $SG_UNAME;
	global $SG_PASS;
	global $FROM;
	global $FROM_NAME;
	$sendgrid = new SendGrid($SG_UNAME,$SG_PASS);
	$semail = new SendGrid\Email();
	$semail->addTo($email);
	$semail->addBcc('lobo@king.com');
    $semail->setFrom($FROM);
    $semail->setSubject($subject);
    $semail->setHtml($mail_HTML);
	$semail->setFromName($FROM_NAME);
	$sendgrid->send($semail);
}	
?>