$lastdrawn=$lastblc->balance;
				$_SESSION['balance']=$lastdrawn;

				$openingbalance=$this->db->get_where("openingblc",array("accountid"=>$_SESSION['accountid'],"datet"=>$openingdate));
				

				if($openingbalance->num_rows()>0)
		     	{
		     		$opngblc=$openingbalance->row();
					$lastblc=$opngblc->blc;
		     		$_SESSION['lastblc']=$lastblc;

		     		echo "success";
		     	}

		     	else
		     	{


				$data=array('accountid'=>$_SESSION['accountid'],'datet'=>$openingdate,'blc'=>$_SESSION['balance']);
				$this->Recharge_Model->openingblcinst($data);
				if(true)
				{

					$openingbalancex=$this->db->get_where("openingblc",array("accountid"=>$_SESSION['accountid'],"datet"=>$openingdate));
					$opngblc=$openingbalancex->row();
					$lastblc=$opngblc->blc;
					$_SESSION['lastblc']=$lastblc;
			     	echo "success";
		    	 }

		     	}